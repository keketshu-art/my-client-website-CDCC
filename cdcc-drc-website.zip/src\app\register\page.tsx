'use client';

import React, { useState } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import {
  UserCheck,
  Globe2,
  CheckCircle2,
  Building2,
  ShieldCheck,
  Sparkles,
  ArrowRight,
} from 'lucide-react';
import { provincesData } from '@/components/ProvinceMap';

export default function RegisterPage() {
  const { lang, t } = useLanguage();
  const [tab, setTab] = useState<'general' | 'diaspora'>('diaspora');

  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    country: 'South Africa',
    province: 'Haut-Katanga',
    sector: 'Mining & Minerals',
    company: '',
    message: '',
  });

  const [loading, setLoading] = useState(false);
  const [refCode, setRefCode] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          type: tab,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setRefCode(data.refCode);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setRefCode(null);
    setFormData({
      fullName: '',
      email: '',
      phone: '',
      country: 'South Africa',
      province: 'Haut-Katanga',
      sector: 'Mining & Minerals',
      company: '',
      message: '',
    });
  };

  return (
    <div className="pt-32 pb-24 space-y-16">
      {/* Header */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-center space-y-4">
        <div className="inline-flex items-center gap-2.5 rounded-full border border-amber-400/40 bg-amber-400/10 px-4 py-1.5 text-[11px] font-bold text-amber-400 uppercase tracking-widest">
          <UserCheck className="h-3.5 w-3.5" />
          <span>Official Registration Portal</span>
        </div>

        <h1 className="text-4xl sm:text-5xl font-extrabold text-white font-display">
          {t('registerPageTitle')}
        </h1>

        <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto font-light leading-relaxed">
          {t('registerPageSub')}
        </p>
      </section>

      {/* Main Registration Card */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-3xl mx-auto">
        <div className="rounded-3xl border border-white/15 bg-[#06122A] p-8 sm:p-12 shadow-2xl relative overflow-hidden">
          <div className="flag-stripe h-[3px]" aria-hidden="true" />

          {/* Registration Type Selector Tabs */}
          <div className="flex items-center gap-2 rounded-2xl border border-white/10 bg-[#020914] p-1.5 mb-8">
            <button
              type="button"
              onClick={() => setTab('diaspora')}
              className={`flex-1 rounded-xl py-3 text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 ${
                tab === 'diaspora'
                  ? 'bg-amber-400 text-slate-950 shadow-lg'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Globe2 className="h-4 w-4" />
              <span>{t('tabDiasporaMember')}</span>
            </button>
            <button
              type="button"
              onClick={() => setTab('general')}
              className={`flex-1 rounded-xl py-3 text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 ${
                tab === 'general'
                  ? 'bg-[#007DC5] text-white shadow-lg'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Building2 className="h-4 w-4" />
              <span>{t('tabGeneralMember')}</span>
            </button>
          </div>

          {refCode ? (
            <div className="py-12 text-center space-y-6 animate-fadeIn">
              <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shadow-xl">
                <CheckCircle2 className="h-12 w-12" />
              </div>

              <h2 className="text-3xl font-extrabold text-white font-display">
                {t('registrationSuccessTitle')}
              </h2>

              <p className="text-sm text-slate-300 max-w-md mx-auto">
                {t('registrationSuccessSub')}
              </p>

              <div className="inline-block rounded-2xl border border-amber-400/40 bg-amber-400/10 px-6 py-3 text-2xl font-extrabold font-mono text-amber-400 tracking-widest shadow-inner">
                {refCode}
              </div>

              <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">
                Confirmation dispatched to <strong>info@cdcc.africa</strong> and your email address. Our delegation team will review your application.
              </p>

              <button
                onClick={handleReset}
                className="mt-4 rounded-xl bg-white/10 border border-white/20 px-8 py-3 text-xs font-bold text-white hover:bg-white/20 transition-all"
              >
                Register Another Member
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Full Name */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-2 uppercase tracking-wider">
                  {t('formFullName')} *
                </label>
                <input
                  type="text"
                  required
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  placeholder="e.g. Honorable Jean-Luc Tshisekedi"
                  className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3.5 text-sm text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none"
                />
              </div>

              {/* Email & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-2 uppercase tracking-wider">
                    {t('formEmail')} *
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="official@enterprise.cd"
                    className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3.5 text-sm text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-2 uppercase tracking-wider">
                    {t('formPhone')} *
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="+27 78 042 6523"
                    className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3.5 text-sm text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none"
                  />
                </div>
              </div>

              {/* Country of Residence & Province */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-2 uppercase tracking-wider">
                    {t('formCountryResidence')} *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.country}
                    onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                    placeholder="e.g. South Africa / France / USA / Belgium"
                    className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3.5 text-sm text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-2 uppercase tracking-wider">
                    {t('formProvinceOrigin')} *
                  </label>
                  <select
                    value={formData.province}
                    onChange={(e) => setFormData({ ...formData, province: e.target.value })}
                    className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3.5 text-sm text-white focus:border-amber-400 focus:outline-none"
                  >
                    {provincesData.map((p) => (
                      <option key={p.id} value={p.name}>
                        {p.name} ({p.capital})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Sector & Company */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-2 uppercase tracking-wider">
                    {t('formSectorInterest')} *
                  </label>
                  <select
                    value={formData.sector}
                    onChange={(e) => setFormData({ ...formData, sector: e.target.value })}
                    className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3.5 text-sm text-white focus:border-amber-400 focus:outline-none"
                  >
                    <option value="Mining & Minerals">{t('selectSectorMining')}</option>
                    <option value="Energy & Hydroelectricity">{t('selectSectorEnergy')}</option>
                    <option value="Agribusiness & Forestry">{t('selectSectorAgriculture')}</option>
                    <option value="Technology & Telecom">{t('selectSectorTech')}</option>
                    <option value="Infrastructure & Logistics">{t('selectSectorInfrastructure')}</option>
                    <option value="Banking & Financial Services">{t('selectSectorFinance')}</option>
                    <option value="Other Services">{t('selectSectorOther')}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-2 uppercase tracking-wider">
                    {t('formCompany')}
                  </label>
                  <input
                    type="text"
                    value={formData.company}
                    onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                    placeholder="e.g. Katanga Energy Corp SARL"
                    className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3.5 text-sm text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none"
                  />
                </div>
              </div>

              {/* Message */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-2 uppercase tracking-wider">
                  {t('formMessage')}
                </label>
                <textarea
                  rows={4}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Outline your commercial interests, provincial investment plans, or mentorship requirements..."
                  className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3.5 text-sm text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none"
                />
              </div>

              {/* Submit Button */}
              <div className="pt-4">
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full rounded-xl font-display py-4 text-sm font-bold text-slate-950 shadow-xl transition-all hover:brightness-110 disabled:opacity-50"
                  style={{ background: 'linear-gradient(120deg, #F7D618 0%, #FFD750 55%, #F59E0B 100%)' }}
                >
                  {loading ? 'Submitting to Database...' : t('submitRegistrationBtn')}
                </button>
              </div>
            </form>
          )}

        </div>
      </section>
    </div>
  );
}
