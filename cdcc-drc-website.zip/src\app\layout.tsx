import type { Metadata } from 'next';
import './globals.css';
import { LanguageProvider } from '@/context/LanguageContext';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { MobileNav } from '@/components/MobileNav';

export const metadata: Metadata = {
  metadataBase: new URL('https://cdcc.africa'),
  title: 'CDCC — Chambre de Commerce · R.D. Congo',
  description: 'The official Chamber of Commerce of the DRC — promoting membership, investment, events, and enterprise growth across all 26 provinces.',
  keywords: ['CDCC', 'DRC Chamber of Commerce', 'Chambre de Commerce RDC', 'DRC business', 'Kinshasa investment', 'DRC trade', 'Democratic Republic of Congo business network'],
  openGraph: {
    title: 'CDCC — Chambre de Commerce · R.D. Congo',
    description: 'The official Chamber of Commerce of the DRC — promoting membership, investment, events, and enterprise growth across all 26 provinces.',
    url: 'https://cdcc.africa',
    siteName: 'CDCC DRC Chamber of Commerce',
    images: [
      {
        url: '/images/cdcc-logo.png',
        width: 800,
        height: 600,
        alt: 'CDCC Logo',
      },
    ],
    locale: 'en_US',
    type: 'website',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="scroll-smooth">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;700;800;900&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Plus+Jakarta+Sans:ital,wght@0,400..800;1,400..800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-[#F2F5FA] text-slate-800 min-h-screen flex flex-col font-sans selection:bg-[#007DC5] selection:text-white pb-14 lg:pb-0">
        <LanguageProvider>
          <Header />
          <main id="main" className="flex-1 w-full focus:outline-none">
            {children}
          </main>
          <Footer />
          <MobileNav />
        </LanguageProvider>
      </body>
    </html>
  );
}
