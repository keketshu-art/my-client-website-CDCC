import { NextResponse } from 'next/server';
import { getDataStore, saveDataStore, MemberRegistration } from '@/lib/dataStore';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { fullName, email, phone, country, province, sector, company, message, type } = body;

    if (!fullName || !email) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    const store = getDataStore();
    const refCode = `REG-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    const newReg: MemberRegistration = {
      id: refCode,
      fullName,
      email,
      phone: phone || '',
      country: country || 'DRC',
      province: province || 'Kinshasa',
      sector: sector || 'General',
      company: company || '',
      message: message || '',
      type: type === 'diaspora' ? 'diaspora' : 'general',
      createdAt: new Date().toISOString().split('T')[0],
      status: 'pending',
    };

    store.registrations.unshift(newReg);
    store.stats.registered += 1;
    store.stats.members += 1;
    saveDataStore(store);

    console.log(`[CDCC Email Notification Sent to info@cdcc.africa]: New Registration ${refCode} by ${fullName} (${email})`);

    return NextResponse.json({
      success: true,
      refCode,
      registration: newReg,
      message: "Registration successfully recorded. Notification dispatched to info@cdcc.africa."
    });
  } catch (err) {
    return NextResponse.json({ error: "Failed to process registration" }, { status: 500 });
  }
}
