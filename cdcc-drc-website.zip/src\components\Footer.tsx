'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useLanguage } from '@/context/LanguageContext';
import { MapPin, Mail, Phone, Facebook, Linkedin, Twitter, Instagram, Send, ShieldCheck } from 'lucide-react';

export const Footer: React.FC = () => {
  const { lang, t } = useLanguage();
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail) {
      setSubscribed(true);
      setNewsletterEmail('');
    }
  };

  return (
    <footer className="relative bg-[#05005B] text-slate-300 border-t border-blue-900/50">
      {/* Top Flag Stripe Accent */}
      <div className="flag-stripe h-[3px]" aria-hidden="true" />

      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">

          {/* Col 1: Brand Statement */}
          <div className="space-y-4">
            <Link href="/" className="inline-block">
              <div className="flex items-center gap-3">
                <img
                  src="/images/cdcc-logo.png"
                  alt="CDCC Logo"
                  className="h-9 w-auto object-contain brightness-125"
                  style={{ height: '36px', maxHeight: '36px', width: 'auto' }}
                />
                <span className="font-display font-black text-white text-base tracking-tight">
                  CDCC <span className="text-[#CE1126]">RDC</span>
                </span>
              </div>
            </Link>

            <p className="text-xs leading-relaxed text-slate-300">
              {lang === 'fr'
                ? "Chambre de Commerce Officielle de la République Démocratique du Congo, promouvant l'entreprise depuis 1960."
                : "Official Chamber of Commerce of the Democratic Republic of the Congo, promoting enterprise since 1960."}
            </p>

            <div className="inline-flex items-center gap-2 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 text-[10px] font-bold text-emerald-400">
              <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-emerald-400" />
              <span>{t('footerTagline')}</span>
            </div>

            <div className="pt-2 flex gap-2.5">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Facebook"
                className="flex h-8 w-8 items-center justify-center rounded-lg border border-blue-900/60 bg-[#00017A]/80 text-slate-300 hover:border-[#FED701] hover:text-[#FED701] transition-all"
              >
                <Facebook className="h-3.5 w-3.5" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noreferrer"
                aria-label="LinkedIn"
                className="flex h-8 w-8 items-center justify-center rounded-lg border border-blue-900/60 bg-[#00017A]/80 text-slate-300 hover:border-[#FED701] hover:text-[#FED701] transition-all"
              >
                <Linkedin className="h-3.5 w-3.5" />
              </a>
              <a
                href="https://x.com"
                target="_blank"
                rel="noreferrer"
                aria-label="X Twitter"
                className="flex h-8 w-8 items-center justify-center rounded-lg border border-blue-900/60 bg-[#00017A]/80 text-slate-300 hover:border-[#FED701] hover:text-[#FED701] transition-all"
              >
                <Twitter className="h-3.5 w-3.5" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Instagram"
                className="flex h-8 w-8 items-center justify-center rounded-lg border border-blue-900/60 bg-[#00017A]/80 text-slate-300 hover:border-[#FED701] hover:text-[#FED701] transition-all"
              >
                <Instagram className="h-3.5 w-3.5" />
              </a>
            </div>
          </div>

          {/* Col 2: Navigation Links */}
          <div>
            <h3 className="text-[11px] font-black uppercase tracking-wider text-[#FED701] mb-4 font-display">
              {lang === 'fr' ? 'NAVIGATION' : 'NAVIGATION'}
            </h3>
            <ul className="space-y-2.5 text-xs text-slate-300">
              <li>
                <Link href="/" className="hover:text-white transition-colors">
                  {t('navHome')}
                </Link>
              </li>
              <li>
                <Link href="/membership" className="hover:text-white transition-colors">
                  {t('navMembership')}
                </Link>
              </li>
              <li>
                <Link href="/events" className="hover:text-white transition-colors">
                  {t('navEvents')}
                </Link>
              </li>
              <li>
                <Link href="/community" className="hover:text-white transition-colors">
                  {t('navCommunity')}
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-white transition-colors">
                  {t('navAbout')}
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-white transition-colors font-medium">
                  {lang === 'fr' ? 'Contact' : 'Contact Us'}
                </Link>
              </li>
              <li>
                <Link href="/register" className="hover:text-[#FED701] transition-colors font-bold">
                  {t('navRegisterCTA')}
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 3: Services */}
          <div>
            <h3 className="text-[11px] font-black uppercase tracking-wider text-[#FED701] mb-4 font-display">
              {lang === 'fr' ? 'SERVICES OFFICIELS' : 'SERVICES'}
            </h3>
            <ul className="space-y-2.5 text-xs text-slate-300">
              <li>
                <Link href="/services/diaspora-registration" className="hover:text-white transition-colors">
                  {lang === 'fr' ? 'Guichet Diaspora & Investissement' : 'Diaspora & Investment Desk'}
                </Link>
              </li>
              <li>
                <Link href="/services/trade-facilitation" className="hover:text-white transition-colors">
                  {lang === 'fr' ? 'Facilitation du Commerce & Export' : 'Trade & Export Facilitation'}
                </Link>
              </li>
              <li>
                <Link href="/services/business-certification" className="hover:text-white transition-colors">
                  {lang === 'fr' ? 'Certification & Visas d\'Affaires' : 'Business Certification & Visas'}
                </Link>
              </li>
              <li>
                <Link href="/services/market-intelligence" className="hover:text-white transition-colors">
                  {lang === 'fr' ? 'Veille Économique & Études Sectorielles' : 'Market Intelligence & Analytics'}
                </Link>
              </li>
              <li>
                <Link href="/services/policy-advocacy" className="hover:text-white transition-colors">
                  {lang === 'fr' ? 'Plaidoyer & Arbitrage Commercial' : 'Policy Advocacy & Arbitration'}
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 4: Official Contact & Newsletter */}
          <div className="space-y-4">
            <h3 className="text-[11px] font-black uppercase tracking-wider text-[#FED701] mb-4 font-display">
              {lang === 'fr' ? 'CONTACT OFFICIEL' : 'OFFICIAL CONTACT'}
            </h3>
            <ul className="space-y-2 text-xs text-slate-300">
              <li className="flex items-start gap-2">
                <MapPin className="h-4 w-4 text-[#FED701] shrink-0 mt-0.5" />
                <span>949 Pierneef Street, Villiera, Pretoria, 0186 · South Africa</span>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="h-4 w-4 text-sky-400 shrink-0 mt-0.5" />
                <span>Siège Kinshasa: Boulevard du 30 Juin, Gombe, RDC</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-slate-400 shrink-0" />
                <a href="mailto:info@cdcc.africa" className="hover:text-white">info@cdcc.africa</a>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-slate-400 shrink-0" />
                <a href="tel:+27780426523" className="hover:text-white">+27 78 042 6523 / +243 810 000 000</a>
              </li>
            </ul>

            {/* Newsletter Subscription Box */}
            <div className="pt-2">
              <span className="text-[11px] font-bold text-slate-300 block mb-1.5">
                {lang === 'fr' ? 'Veille Économique Mensuelle' : 'Monthly Economic Digest'}
              </span>
              {subscribed ? (
                <div className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-2.5 text-[11px] text-emerald-400 font-medium flex items-center gap-2">
                  <ShieldCheck className="h-4 w-4" />
                  <span>{lang === 'fr' ? 'Abonnement confirmé !' : 'Subscribed successfully!'}</span>
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="flex items-center gap-1.5">
                  <input
                    type="email"
                    required
                    value={newsletterEmail}
                    onChange={(e) => setNewsletterEmail(e.target.value)}
                    placeholder={lang === 'fr' ? 'Votre email...' : 'Your email...'}
                    className="w-full rounded-xl border border-blue-900/60 bg-[#00017A]/80 px-3 py-2 text-xs text-white placeholder-slate-400 focus:border-[#FED701] focus:outline-none"
                  />
                  <button
                    type="submit"
                    className="rounded-xl bg-[#151EA6] hover:bg-blue-700 px-3.5 py-2 text-xs font-bold text-white shrink-0"
                  >
                    <Send className="h-3.5 w-3.5" />
                  </button>
                </form>
              )}
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="mt-12 border-t border-blue-900/50 pt-6 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-400 gap-4">
          <p>© 2026 Chambre de Commerce de la République Démocratique du Congo. Tous droits réservés.</p>
          <div className="flex gap-4">
            <span className="hover:text-white cursor-pointer">Mentions Légales</span>
            <span className="hover:text-white cursor-pointer">Registre de Commerce</span>
            <span className="hover:text-white cursor-pointer">Conformité OHADA</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
