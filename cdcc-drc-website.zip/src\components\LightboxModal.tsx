'use client';

import React, { useState } from 'react';
import { X, ChevronLeft, ChevronRight, Calendar, Camera } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';

interface LightboxModalProps {
  isOpen: boolean;
  onClose: () => void;
  photos: string[];
  title: string;
  date?: string;
}

export const LightboxModal: React.FC<LightboxModalProps> = ({
  isOpen,
  onClose,
  photos,
  title,
  date,
}) => {
  const { lang, t } = useLanguage();
  const [currentIndex, setCurrentIndex] = useState(0);

  if (!isOpen || !photos || photos.length === 0) return null;

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? photos.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === photos.length - 1 ? 0 : prev + 1));
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-md p-4 sm:p-6 animate-fadeIn">
      {/* Close Button */}
      <button
        onClick={onClose}
        className="absolute top-5 right-5 z-[110] rounded-full border border-white/20 bg-white/10 p-2.5 text-white hover:bg-white/20 hover:scale-110 transition-all focus:outline-none"
        aria-label="Close Lightbox"
      >
        <X className="h-6 w-6" />
      </button>

      <div className="relative w-full max-w-5xl overflow-hidden rounded-3xl border border-white/15 bg-[#03091A] shadow-2xl">
        {/* Flag Stripe Top Accent */}
        <div className="flag-stripe h-[3px]" />

        <div className="relative aspect-[16/10] sm:aspect-[16/9] bg-black flex items-center justify-center overflow-hidden">
          <img
            src={photos[currentIndex]}
            alt={title}
            className="max-h-full max-w-full object-contain transition-all duration-300"
          />

          {/* Previous / Next Controls */}
          {photos.length > 1 && (
            <>
              <button
                onClick={handlePrev}
                className="absolute left-4 top-1/2 -translate-y-1/2 rounded-full border border-white/20 bg-black/60 p-3 text-white hover:bg-amber-400 hover:text-slate-950 transition-all focus:outline-none"
                aria-label="Previous photo"
              >
                <ChevronLeft className="h-6 w-6" />
              </button>
              <button
                onClick={handleNext}
                className="absolute right-4 top-1/2 -translate-y-1/2 rounded-full border border-white/20 bg-black/60 p-3 text-white hover:bg-amber-400 hover:text-slate-950 transition-all focus:outline-none"
                aria-label="Next photo"
              >
                <ChevronRight className="h-6 w-6" />
              </button>
            </>
          )}

          {/* Photo Counter Badge */}
          {photos.length > 1 && (
            <div className="absolute bottom-4 right-4 rounded-full border border-white/20 bg-black/70 px-3.5 py-1 text-xs font-semibold text-white backdrop-blur-md">
              {currentIndex + 1} / {photos.length}
            </div>
          )}
        </div>

        {/* Modal Footer Info */}
        <div className="p-6 bg-[#06122A] flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-t border-white/10">
          <div className="space-y-1">
            <h3 className="text-base sm:text-lg font-bold text-white font-display leading-snug">
              {title}
            </h3>
            {date && (
              <div className="flex items-center gap-2 text-xs text-amber-400 font-medium">
                <Calendar className="h-3.5 w-3.5" />
                <span>{date}</span>
              </div>
            )}
          </div>

          {/* Thumbnails if multiple photos */}
          {photos.length > 1 && (
            <div className="flex items-center gap-2 shrink-0 overflow-x-auto py-1">
              {photos.map((imgUrl, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentIndex(idx)}
                  className={`h-12 w-16 overflow-hidden rounded-lg border-2 transition-all shrink-0 ${
                    idx === currentIndex ? 'border-amber-400 scale-105' : 'border-white/10 opacity-50 hover:opacity-100'
                  }`}
                >
                  <img src={imgUrl} alt="" className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
