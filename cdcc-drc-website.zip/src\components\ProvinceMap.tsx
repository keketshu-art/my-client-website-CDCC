'use client';

import React, { useState } from 'react';
import { MapPin, Building2, Pickaxe, Zap, TreePine, Ship, Sparkles, Gem, ArrowRight, ShieldCheck, Factory, CheckCircle2 } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';

export interface ProvinceInfo {
  id: string;
  name: string;
  capital: string;
  regionEn: string;
  regionFr: string;
  sectorEn: string;
  sectorFr: string;
  keyAssetsEn: string;
  keyAssetsFr: string;
  status: 'Full Office' | 'Regional Hub' | 'Focal Point';
  companiesCount: number;
  icon: 'mining' | 'zap' | 'ship' | 'tree' | 'building' | 'diamond';
}

export const provincesData: ProvinceInfo[] = [
  {
    id: 'kinshasa',
    name: 'Kinshasa',
    capital: 'Kinshasa',
    regionEn: 'Capital Metropolitan District · Lower Congo River',
    regionFr: 'District Métropolitain de la Capitale · Bas-Congo',
    sectorEn: 'National Financial Services, Telecoms, Central Government, FMCG Manufacturing & International Logistics Desk',
    sectorFr: 'Services financiers nationaux, Télécoms, Gouvernement Central, Industrie Agroalimentaire & Logistique Internationale',
    keyAssetsEn: 'National Stock Exchange, Gombe Business Quarter, Port of N\'Djili, Commercial Banking Hub',
    keyAssetsFr: 'Bourse Nationale, Quartier d\'Affaires Gombe, Port de N\'Djili, Hub Bancaire Commercial',
    status: 'Full Office',
    companiesCount: 680,
    icon: 'building',
  },
  {
    id: 'haut-katanga',
    name: 'Haut-Katanga',
    capital: 'Lubumbashi',
    regionEn: 'SADC Copperbelt Corridor · Southern DRC',
    regionFr: 'Corridor Copperbelt SADC · Sud de la RDC',
    sectorEn: 'Copper Smelting, High-Grade Cobalt Extraction, Heavy Industrial Equipment & Rail Logistics to SADC Ports',
    sectorFr: 'Fonderie de cuivre, Extraction de cobalt de haute qualité, Équipement industriel lourd & Logistique ferroviaire vers les ports SADC',
    keyAssetsEn: 'Tenke Fungurume Mining, Ruashi Mines, SNCC Rail Junction, Kasumbalesa Border Post',
    keyAssetsFr: 'Mines de Tenke Fungurume, Ruashi Mining, Jonction Ferroviaire SNCC, Poste Frontière de Kasumbalesa',
    status: 'Full Office',
    companiesCount: 380,
    icon: 'mining',
  },
  {
    id: 'lualaba',
    name: 'Lualaba',
    capital: 'Kolwezi',
    regionEn: 'Global Battery Minerals Capital · Southern DRC',
    regionFr: 'Capitale Mondiale des Minerais de Batterie · Sud RDC',
    sectorEn: 'World Largest Cobalt Reserve, High-Tech Battery Material Refining, Copper Mining & Mining Hydropower Grid',
    sectorFr: 'Plus grande réserve mondiale de cobalt, Raffinage de matériaux pour batteries, Mines de cuivre & Réseau hydroélectrique minier',
    keyAssetsEn: 'Kamoa-Kakula Complex (Ivanhoe/Zijin), Mutanda Mine (Glencore), KCC Kolwezi, Busanga Dam (240MW)',
    keyAssetsFr: 'Complexe Kamoa-Kakula (Ivanhoe/Zijin), Mine de Mutanda (Glencore), KCC Kolwezi, Barrage de Busanga (240MW)',
    status: 'Full Office',
    companiesCount: 240,
    icon: 'mining',
  },
  {
    id: 'kongo-central',
    name: 'Kongo Central',
    capital: 'Matadi',
    regionEn: 'Atlantic Ocean Maritime Estuary · Western DRC',
    regionFr: 'Estuaire Maritime de l\'Océan Atlantique · Ouest RDC',
    sectorEn: 'Deep-Sea Maritime Freight Ports, Inga I & II Hydroelectric Complex (40,000MW potential), Offshore Petroleum & Cement Manufacturing',
    sectorFr: 'Ports maritimes de hauts-fonds, Complexe hydroélectrique d\'Inga I & II (potentiel 40 000MW), Pétrole offshore & Cimenteries',
    keyAssetsEn: 'Port of Matadi, Port of Boma, Banana Deepwater Port Infrastructure, Inga Dam Grid, Cimenterie de Lukala (CILU)',
    keyAssetsFr: 'Port de Matadi, Port de Boma, Infrastructures du Port en Eau Profonde de Banana, Réseau Inga, Cimenterie de Lukala (CILU)',
    status: 'Full Office',
    companiesCount: 195,
    icon: 'ship',
  },
  {
    id: 'nord-kivu',
    name: 'Nord-Kivu',
    capital: 'Goma',
    regionEn: 'East African Community (EAC) Trade Hub · Great Lakes',
    regionFr: 'Hub Commercial de la Communauté d\'Afrique de l\'Est (EAC) · Grands Lacs',
    sectorEn: 'Cross-Border EAC Commerce, Volcanic Specialty Arabica Coffee, Methane Gas Power (Lake Kivu) & Agro-Processing',
    sectorFr: 'Commerce transfrontalier EAC, Café Arabica d\'altitude, Gaz méthane du Lac Kivu & Transformation agroalimentaire',
    keyAssetsEn: 'Lake Kivu Methane Extraction (500MW potential), Goma International Airport Corridor, Virunga Renewable Hydro',
    keyAssetsFr: 'Extraction du gaz méthane du Lac Kivu (potentiel 500MW), Corridor de l\'Aéroport International de Goma, Énergie Virunga',
    status: 'Regional Hub',
    companiesCount: 155,
    icon: 'zap',
  },
  {
    id: 'sud-kivu',
    name: 'Sud-Kivu',
    capital: 'Bukavu',
    regionEn: 'Great Lakes Economic Zone · Eastern DRC',
    regionFr: 'Zone Économique des Grands Lacs · Est de la RDC',
    sectorEn: '3T Mineral Processing (Tin, Tantalum, Tungsten), Specialty Tea & Coffee Agriculture, Lake Water Logistics & Eco-Tourism',
    sectorFr: 'Traitement des minerais 3T (Étain, Tantalite, Tungstène), Agriculture spécialisée de thé & café, Logistique lacustre & Éco-tourisme',
    keyAssetsEn: 'Twangiza Gold Mine (Banro), Bukavu-Uvira Freight Corridor, Lake Tanganyika Port of Kalundu',
    keyAssetsFr: 'Mine d\'Or de Twangiza (Banro), Corridor de Fret Bukavu-Uvira, Port Lacustre de Kalundu (Uvira)',
    status: 'Regional Hub',
    companiesCount: 135,
    icon: 'tree',
  },
  {
    id: 'tshopo',
    name: 'Tshopo',
    capital: 'Kisangani',
    regionEn: 'Upper Congo River Transit Hub · North-Central DRC',
    regionFr: 'Hub de Transit du Haut-Congo · Nord-Centre RDC',
    sectorEn: 'Congo River Intermodal Barging Hub, Sustainable FSC Forest Operations, Commercial Rice & Palm Oil Mills',
    sectorFr: 'Hub de batellerie intermodale du Fleuve Congo, Exploitation forestière durable FSC, Riziculture commerciale & Huileries',
    keyAssetsEn: 'Port of Kisangani (River Terminus to Kinshasa), Boyoma Falls Hydroelectric Station, Tshopo Tropical Hardwood Reserve',
    keyAssetsFr: 'Port de Kisangani (Terminus fluvial vers Kinshasa), Centrale Hydroélectrique des Chutes Boyoma, Réserve de bois tropical de la Tshopo',
    status: 'Regional Hub',
    companiesCount: 105,
    icon: 'ship',
  },
  {
    id: 'equateur',
    name: 'Équateur',
    capital: 'Mbandaka',
    regionEn: 'Congo Basin Carbon Sink & Peatland Zone · Northwest DRC',
    regionFr: 'Bassin du Congo & Zone de Puits de Carbone · Nord-Ouest RDC',
    sectorEn: 'Global Carbon Offset Credits, Sustainable Forestry Management, Rubber Plantations & River Transport',
    sectorFr: 'Crédits carbone mondiaux, Gestion forestière durable, Plantations de hévéa & Transport fluvial',
    keyAssetsEn: 'Mbandaka Congo River Port, Cuvette Centrale Peatland Carbon Reserve (30 Billion Tons CO2), Busira Rubber Estates',
    keyAssetsFr: 'Port Fluvial de Mbandaka, Réserve de Torbières de la Cuvette Centrale (30 Milliards de Tonnes CO2), Domaines d\'Hévéa de Busira',
    status: 'Focal Point',
    companiesCount: 75,
    icon: 'tree',
  },
  {
    id: 'kasai-oriental',
    name: 'Kasaï-Oriental',
    capital: 'Mbuji-Mayi',
    regionEn: 'South-Central Diamond Mineral Basin',
    regionFr: 'Bassin Minier Diamantifère du Centre-Sud',
    sectorEn: 'Industrial & Gem-Quality Diamond Mining, Regional Commerce, Maize Granary & Solar Mini-Grids',
    sectorFr: 'Extraction de diamants industriels & joaillerie, Commerce régional, Grenier de maïs & Mini-réseaux solaires',
    keyAssetsEn: 'MIBA (Société Minière de Bakwanga), Mbuji-Mayi Airport Logistics Hub, Tubitembo Solar Station',
    keyAssetsFr: 'MIBA (Société Minière de Bakwanga), Hub Logistique de l\'Aéroport de Mbuji-Mayi, Centrale Solaire de Tubitembo',
    status: 'Regional Hub',
    companiesCount: 120,
    icon: 'diamond',
  },
  {
    id: 'kasai-central',
    name: 'Kasaï-Central',
    capital: 'Kananga',
    regionEn: 'Central Rail-Road Transportation Axis',
    regionFr: 'Axe de Transport Ferroviaire & Routier du Centre',
    sectorEn: 'SNCC Railway Distribution Junction (Ilebo-Lubumbashi line), Agricultural Processing, Cattle Ranches & Trade',
    sectorFr: 'Jonction de distribution ferroviaire SNCC (ligne Ilebo-Lubumbashi), Transformation agricole, Élevage bovin & Commerce',
    keyAssetsEn: 'Kananga Rail Yards, Katende Hydroelectric Project (64MW), Luiza Border Trade Corridor',
    keyAssetsFr: 'Gares Ferroviaires de Kananga, Projet Hydroélectrique de Katende (64MW), Corridor Commercial de Luiza',
    status: 'Focal Point',
    companiesCount: 80,
    icon: 'building',
  },
  {
    id: 'ituri',
    name: 'Ituri',
    capital: 'Bunia',
    regionEn: 'Albertine Rift Mineral & Oil Basin · Northeast DRC',
    regionFr: 'Bassin Aurifère & Pétrolier du Rift Albertin · Nord-Est RDC',
    sectorEn: 'High-Grade Gold Belts, Lake Albert Oil Exploration Blocks, Cattle Livestock & East African EAC Logistics',
    sectorFr: 'Ceintures aurifères à haute teneur, Blocs pétroliers du Lac Albert, Élevage bovin & Logistique EAC',
    keyAssetsEn: 'Kilo-Moto Gold Fields, Mongbwalu Concessions, Lake Albert Petroleum Exploration Block 1 & 2',
    keyAssetsFr: 'Gisements Aurifères de Kilo-Moto, Concessions de Mongbwalu, Blocs Pétroliers 1 & 2 du Lac Albert',
    status: 'Regional Hub',
    companiesCount: 95,
    icon: 'mining',
  },
  {
    id: 'tanganyika',
    name: 'Tanganyika',
    capital: 'Kalemie',
    regionEn: 'Lake Tanganyika EAC Gateway · Southeast DRC',
    regionFr: 'Porte EAC du Lac Tanganyika · Sud-Est RDC',
    sectorEn: 'Intermodal Rail-Lake Shipping to Kigoma (Tanzania), Hard Rock Lithium Mining (Manono Deposit), Commercial Fisheries',
    sectorFr: 'Transport intermodal fer-lac vers Kigoma (Tanzanie), Mines de lithium de roche dure (Gisement de Manono), Pêche industrielle',
    keyAssetsEn: 'Manono Lithium Project (AVZ Minerals), Port of Kalemie Modernization, Lake Tanganyika Trade Route',
    keyAssetsFr: 'Projet Lithium de Manono (AVZ Minerals), Modernisation du Port de Kalemie, Route Commerciale du Lac Tanganyika',
    status: 'Focal Point',
    companiesCount: 70,
    icon: 'ship',
  },
  {
    id: 'kwilu',
    name: 'Kwilu',
    capital: 'Bandundu',
    regionEn: 'Western Agricultural Basket · Kwango-Kwilu River Basin',
    regionFr: 'Grenier Agricole de l\'Ouest · Bassin Kwango-Kwilu',
    sectorEn: 'Kinshasa Primary Food Supply Chain, Industrial Palm Oil Refineries, Cassava Milling & River Barging',
    sectorFr: 'Chaîne d\'approvisionnement alimentaire de Kinshasa, Raffineries d\'huile de palme, Minoteries de manioc & Batellerie',
    keyAssetsEn: 'Kikwit Commercial Agro-Hub, Plantations et Huileries du Congo (PHC Kikwit), Bandundu River Port',
    keyAssetsFr: 'Hub Agro-Commercial de Kikwit, Plantations et Huileries du Congo (PHC Kikwit), Port Fluvial de Bandundu',
    status: 'Focal Point',
    companiesCount: 65,
    icon: 'tree',
  },
  {
    id: 'kwango',
    name: 'Kwango',
    capital: 'Kenge',
    regionEn: 'Southwest Border Agricultural & Livestock Zone',
    regionFr: 'Zone Agricole & Élevage de la Frontière Sud-Ouest',
    sectorEn: 'Angolan Cross-Border Trade (Popokabaka/Kenge Highway), Cattle Farming, Maize & Hardwood Timber',
    sectorFr: 'Commerce transfrontalier angolais (Route Kenge-Popokabaka), Élevage bovin, Maïs & Bois durs',
    keyAssetsEn: 'RN1 Kinshasa-Kenge Commercial Corridor, Popokabaka Border Customs Post, Kenge Agro-Ranches',
    keyAssetsFr: 'Corridor Commercial RN1 Kinshasa-Kenge, Poste Douanier Frontalier de Popokabaka, Ranches Agricoles de Kenge',
    status: 'Focal Point',
    companiesCount: 48,
    icon: 'tree',
  },
  {
    id: 'mai-ndombe',
    name: 'Maï-Ndombe',
    capital: 'Inongo',
    regionEn: 'Lake Maï-Ndombe & Forested Wetlands',
    regionFr: 'Lac Maï-Ndombe & Zone Humide Forestière',
    sectorEn: 'REDD+ Carbon Conservation Projects, Certified Commercial Timber, Inland Lake Fisheries & Eco-tourism',
    sectorFr: 'Projets de conservation carbone REDD+, Bois commercial certifié, Pêche lacustre & Éco-tourisme',
    keyAssetsEn: 'Inongo Lake Freight Port, Wildlife Works REDD+ Carbon Project, Nioki Timber Processing Mills',
    keyAssetsFr: 'Port de Fret Lacustre d\'Inongo, Projet Carbone REDD+ Wildlife Works, Scieries de Nioki',
    status: 'Focal Point',
    companiesCount: 42,
    icon: 'tree',
  },
  {
    id: 'lomami',
    name: 'Lomami',
    capital: 'Kabinda',
    regionEn: 'Central Agricultural & Rail Transit Belt',
    regionFr: 'Ceinture Agricole & Transit Ferroviaire du Centre',
    sectorEn: 'Cereal Production (Maize, Sesame), Cotton Farming, Railway Freight Junction at Mwene-Ditu',
    sectorFr: 'Production céréalière (Maïs, Sésame), Cotoniculture, Jonction de fret ferroviaire de Mwene-Ditu',
    keyAssetsEn: 'Mwene-Ditu SNCC Rail Terminal, Kabinda Agro-Cooperatives, Mwene-Ditu Grain Silos',
    keyAssetsFr: 'Terminal Ferroviaire SNCC de Mwene-Ditu, Coopératives Agricoles de Kabinda, Silos à Grains de Mwene-Ditu',
    status: 'Focal Point',
    companiesCount: 38,
    icon: 'tree',
  },
  {
    id: 'sankuru',
    name: 'Sankuru',
    capital: 'Lusambo',
    regionEn: 'Central Equatorial River Forest Zone',
    regionFr: 'Zone Forestière & Fluviale Équatoriale du Centre',
    sectorEn: 'Tropical Hardwood Forestry, Wild Rubber, Rice Cultivation & Sankuru River Navigation Routes',
    sectorFr: 'Foresterie de bois durs tropicaux, Hévéa sauvage, Riziculture & Voies de navigation de la rivière Sankuru',
    keyAssetsEn: 'Lusambo River Port, Bena-Dibele Forestry Concessions, Lodja Regional Air Cargo Strip',
    keyAssetsFr: 'Port Fluvial de Lusambo, Concessions Forestières de Bena-Dibele, Piste Fret Aérien de Lodja',
    status: 'Focal Point',
    companiesCount: 32,
    icon: 'tree',
  },
  {
    id: 'kasai',
    name: 'Kasaï',
    capital: 'Tshikapa',
    regionEn: 'Southwestern Diamond & Border Gateway',
    regionFr: 'Porte Diamantifère & Frontalière du Sud-Ouest',
    sectorEn: 'Alluvial Diamond Mining, Angolan Cross-Border Transit (Tshikapa-Kamako Axis), Timber & Agriculture',
    sectorFr: 'Exploitation de diamants alluvionnaires, Transit transfrontalier avec l\'Angola (Axe Tshikapa-Kamako), Bois & Agriculture',
    keyAssetsEn: 'Tshikapa Diamond Processing Hub, Kamako Angola Border Customs, Kasai River Hydro Projects',
    keyAssetsFr: 'Hub de Traitement des Diamants de Tshikapa, Douane Frontalière de Kamako Angola, Projets Hydro sur la Rivière Kasaï',
    status: 'Focal Point',
    companiesCount: 55,
    icon: 'mining',
  },
  {
    id: 'haut-lomami',
    name: 'Haut-Lomami',
    capital: 'Kamina',
    regionEn: 'Southern Railway Junction & Savannah Belt',
    regionFr: 'Jonction Ferroviaire du Sud & Zone de Savane',
    sectorEn: 'Strategic Railway Network Node (Kamina Junction to Kasai, Katanga & Tshopo), Cattle Ranches & Cotton',
    sectorFr: 'Nœud ferroviaire stratégique (Jonction Kamina vers Kasaï, Katanga & Tshopo), Ranches bovins & Coton',
    keyAssetsEn: 'Kamina Military & Industrial Logistics Base, SNCC Railway Repair Workshops, Bukama River Port',
    keyAssetsFr: 'Base Logistique Militaire & Industrielle de Kamina, Ateliers de Réparation Ferroviaire SNCC, Port Fluvial de Bukama',
    status: 'Focal Point',
    companiesCount: 38,
    icon: 'building',
  },
  {
    id: 'maniema',
    name: 'Maniema',
    capital: 'Kindu',
    regionEn: 'East-Central 3T Mineral Corridor',
    regionFr: 'Corridor Minier 3T du Centre-Est',
    sectorEn: '3T Mineral Extraction (Cassiterite/Tin, Coltan, Wolframite), Alluvial Gold, Kindu Port & SNCC Rail Terminus',
    sectorFr: 'Extraction de minerais 3T (Cassitérite, Coltan, Wolframite), Or alluvionnaire, Port de Kindu & Terminus Ferroviaire',
    keyAssetsEn: 'Punio & Kailo Coltan Mines, Kindu River-Rail Terminal, Namoya Gold Concessions',
    keyAssetsFr: 'Mines de Coltan de Punio & Kailo, Terminal Fleuve-Fer de Kindu, Concessions Aurifères de Namoya',
    status: 'Focal Point',
    companiesCount: 60,
    icon: 'mining',
  },
  {
    id: 'haut-uele',
    name: 'Haut-Uele',
    capital: 'Isiro',
    regionEn: 'Northeastern Gold Frontier & Trans-African Highway',
    regionFr: 'Frontière Aurifère du Nord-Est & Autoroute Transafricaine',
    sectorEn: 'Kibali Gold Axis (One of Africa\'s Largest Industrial Gold Mines operated by Barrick/AngloGold), Timber & Coffee',
    sectorFr: 'Axe Aurifère de Kibali (Une des plus grandes mines d\'or industrielles d\'Afrique exploitée par Barrick), Bois & Café',
    keyAssetsEn: 'Kibali Hydro-Solar Gold Mine Complex (Durba), Isiro Industrial Airport Corridor, Dungu Timber Concessions',
    keyAssetsFr: 'Complexe Aurifère Hydro-Solaire de Kibali (Durba), Corridor de l\'Aéroport Industriel d\'Isiro, Concessions Forestières de Dungu',
    status: 'Focal Point',
    companiesCount: 78,
    icon: 'mining',
  },
  {
    id: 'bas-uele',
    name: 'Bas-Uele',
    capital: 'Buta',
    regionEn: 'Northern Border Rainforest Reserve',
    regionFr: 'Réserve Forestière de la Frontière Nord',
    sectorEn: 'Tropical Hardwood Forests, CAR Transboundary Agriculture, Wildlife Conservation & Artisanal Gold',
    sectorFr: 'Forêts de bois durs tropicaux, Agriculture transfrontalière avec la RCA, Conservation de la faune & Or artisanal',
    keyAssetsEn: 'Buta Railway Depot, Rubi-Tele Hunting Reserve, Aketi River Port to Congo River',
    keyAssetsFr: 'Dépôt Ferroviaire de Buta, Réserve de Chasse de Rubi-Tele, Port Fluvial d\'Aketi vers le Fleuve Congo',
    status: 'Focal Point',
    companiesCount: 28,
    icon: 'tree',
  },
  {
    id: 'nord-ubangi',
    name: 'Nord-Ubangi',
    capital: 'Gbadolite',
    regionEn: 'Far Northern Border Hydropower Zone',
    regionFr: 'Zone Hydroélectrique de la Frontière du Grand Nord',
    sectorEn: 'Mobayi-Mbongo Hydroelectric Plant (Power export to CAR), Cattle Livestock, Coffee & River Commerce',
    sectorFr: 'Centrale Hydroélectrique de Mobayi-Mbongo (Exportation d\'électricité vers la RCA), Élevage bovin, Café & Commerce fluvial',
    keyAssetsEn: 'Mobayi-Mbongo Hydro Dam (10.5MW), Gbadolite International Cargo Airport, Ubangi River Trade',
    keyAssetsFr: 'Barrage Hydro de Mobayi-Mbongo (10.5MW), Aéroport Fret International de Gbadolite, Commerce Fluvial de l\'Ubangi',
    status: 'Focal Point',
    companiesCount: 32,
    icon: 'zap',
  },
  {
    id: 'sud-ubangi',
    name: 'Sud-Ubangi',
    capital: 'Gemena',
    regionEn: 'Northwestern Agro-Export Corridor',
    regionFr: 'Corridor d\'Agro-Exportation du Nord-Ouest',
    sectorEn: 'Commercial Coffee & Cocoa Exports, Palm Oil Mills, Zongo River Hydropower Potential & Trans-Ubangi Freight',
    sectorFr: 'Exportations commerciales de café & cacao, Huileries de palme, Potentiel hydroélectrique de la rivière Zongo & Fret Ubangi',
    keyAssetsEn: 'Gemena Commercial Airport, Zongo Water Falls Hydropower Site, Kungu Agro-Industrial Plantations',
    keyAssetsFr: 'Aéroport Commercial de Gemena, Site Hydroélectrique des Chutes de Zongo, Plantations Agro-Industrielles de Kungu',
    status: 'Focal Point',
    companiesCount: 38,
    icon: 'tree',
  },
  {
    id: 'mongala',
    name: 'Mongala',
    capital: 'Lisala',
    regionEn: 'North-Central Congo River Navigation Spine',
    regionFr: 'Axe de Navigation du Fleuve Congo au Nord-Centre',
    sectorEn: 'Congo River Commercial Barging (Lisala Main Port), Palm Oil & Rubber Extraction, Tropical Forestry',
    sectorFr: 'Batellerie commerciale du Fleuve Congo (Port Principal de Lisala), Extraction d\'huile de palme & hévéa, Foresterie tropicale',
    keyAssetsEn: 'Port of Lisala River Logistics Terminal, Bumba Agricultural Port, Binga Palm Oil Refinery',
    keyAssetsFr: 'Terminal Logistique du Port Fluvial de Lisala, Port Agricole de Bumba, Raffinerie d\'Huile de Palme de Binga',
    status: 'Focal Point',
    companiesCount: 32,
    icon: 'ship',
  },
  {
    id: 'tshuapa',
    name: 'Tshuapa',
    capital: 'Boende',
    regionEn: 'Heart of the Congo Basin Central Rainforest',
    regionFr: 'Cœur de la Forêt Équatoriale du Bassin du Congo',
    sectorEn: 'Primary Rainforest Biodiversity Credits, FSC Certified Sustainable Timber, River Transportation & Copal Resin',
    sectorFr: 'Crédits biodiversité de forêt primaire, Bois durable certifié FSC, Transport fluvial & Résine de copal',
    keyAssetsEn: 'Boende River Barging Terminal, Salonga National Park Biodiversity Reserve, Tshuapa River Freight Network',
    keyAssetsFr: 'Terminal de Batellerie de Boende, Réserve de Biodiversité du Parc National de la Salonga, Réseau Fret de la Tshuapa',
    status: 'Focal Point',
    companiesCount: 25,
    icon: 'tree',
  },
];

export const ProvinceMap: React.FC = () => {
  const { lang, t } = useLanguage();
  const [selectedProvince, setSelectedProvince] = useState<ProvinceInfo>(provincesData[0]);

  const renderIcon = (type: string) => {
    switch (type) {
      case 'mining': return <Pickaxe className="h-5 w-5 text-amber-400 icon-animate" />;
      case 'zap': return <Zap className="h-5 w-5 text-yellow-400 icon-animate" />;
      case 'ship': return <Ship className="h-5 w-5 text-sky-400 icon-animate" />;
      case 'tree': return <TreePine className="h-5 w-5 text-emerald-400 icon-animate" />;
      case 'diamond': return <Gem className="h-5 w-5 text-[#FFE500] icon-animate" />;
      default: return <Building2 className="h-5 w-5 text-blue-400 icon-animate" />;
    }
  };

  return (
    <div className="space-y-8">
      
      {/* 26 Provinces Interactive Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2.5">
        {provincesData.map((prov, idx) => {
          const isSelected = selectedProvince.id === prov.id;
          return (
            <button
              key={prov.id}
              onClick={() => setSelectedProvince(prov)}
              className={`rounded-xl border p-3 text-left transition-all relative overflow-hidden group ${
                isSelected
                  ? 'border-amber-400 bg-amber-400/15 shadow-xl scale-105 z-10'
                  : 'border-white/10 bg-[#06122A]/80 hover:border-white/30 hover:bg-white/10'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-amber-400 font-mono">
                  #{idx + 1}
                </span>
                {renderIcon(prov.icon)}
              </div>
              <p className="mt-2 text-xs font-bold text-white line-clamp-1 font-display">
                {prov.name}
              </p>
              <p className="text-[10px] text-slate-400 line-clamp-1">
                {prov.capital}
              </p>
            </button>
          );
        })}
      </div>

      {/* Selected Province Detailed Economic & Geographic Card */}
      <div className="rounded-3xl border border-white/15 bg-[#06122A] p-6 sm:p-8 shadow-2xl relative overflow-hidden text-white">
        <div className="flag-stripe h-[3px]" />

        <div className="grid lg:grid-cols-12 gap-8 items-start pt-2">
          
          {/* Main Info (8 Cols) */}
          <div className="lg:col-span-8 space-y-5">
            
            <div className="flex flex-wrap items-center gap-2">
              <div className="inline-flex items-center gap-2 rounded-full border border-amber-400/30 bg-amber-400/10 px-3.5 py-1 text-xs font-bold text-amber-400 uppercase tracking-wider">
                <MapPin className="h-3.5 w-3.5" />
                <span>{lang === 'fr' ? 'Province de' : 'Province of'} {selectedProvince.name}</span>
              </div>
              
              <span className="rounded-full bg-sky-950 border border-sky-400/30 px-3 py-1 text-[11px] font-semibold text-sky-300">
                {lang === 'fr' ? selectedProvince.regionFr : selectedProvince.regionEn}
              </span>
            </div>

            <div>
              <h3 className="text-3xl sm:text-4xl font-black text-white font-display leading-tight">
                {selectedProvince.name}{' '}
                <span className="text-base font-normal text-slate-400">
                  ({lang === 'fr' ? 'Chef-lieu' : 'Capital'}: <strong className="text-white font-semibold">{selectedProvince.capital}</strong>)
                </span>
              </h3>
            </div>

            {/* Economic Sector Focus */}
            <div className="space-y-1.5 bg-white/5 rounded-2xl p-4 border border-white/10">
              <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest block font-display">
                ● {lang === 'fr' ? 'ORIENTATION ÉCONOMIQUE STRATÉGIQUE' : 'STRATEGIC ECONOMIC ORIENTATION'}
              </span>
              <p className="text-xs sm:text-sm leading-relaxed text-sky-100 font-medium">
                {lang === 'fr' ? selectedProvince.sectorFr : selectedProvince.sectorEn}
              </p>
            </div>

            {/* Key Infrastructure & Industrial Assets */}
            <div className="space-y-1.5 bg-white/5 rounded-2xl p-4 border border-white/10">
              <span className="text-[10px] font-bold text-sky-400 uppercase tracking-widest block font-display flex items-center gap-1.5">
                <Factory className="h-3.5 w-3.5" />
                <span>{lang === 'fr' ? 'INFRASTRUCTURES & SITES CLÉS' : 'KEY INFRASTRUCTURE & INDUSTRIAL ASSETS'}</span>
              </span>
              <p className="text-xs text-slate-300 font-normal leading-relaxed">
                {lang === 'fr' ? selectedProvince.keyAssetsFr : selectedProvince.keyAssetsEn}
              </p>
            </div>

            {/* Metrics Chips */}
            <div className="flex flex-wrap gap-4 pt-2">
              <div className="rounded-2xl border border-white/10 bg-[#020914] px-5 py-3 text-xs">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">{lang === 'fr' ? 'Statut Bureau CDCC:' : 'CDCC Office Status:'}</span>
                <span className="font-extrabold text-white text-sm flex items-center gap-1.5 mt-0.5">
                  <ShieldCheck className="h-4 w-4 text-emerald-400" />
                  <span>{selectedProvince.status}</span>
                </span>
              </div>

              <div className="rounded-2xl border border-white/10 bg-[#020914] px-5 py-3 text-xs">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">{lang === 'fr' ? 'Entreprises Membres Agrées:' : 'Accredited Member Enterprises:'}</span>
                <span className="font-extrabold text-amber-400 text-sm flex items-center gap-1.5 mt-0.5">
                  <CheckCircle2 className="h-4 w-4 text-amber-400" />
                  <span>{selectedProvince.companiesCount}+ {lang === 'fr' ? 'Sociétés' : 'Companies'}</span>
                </span>
              </div>
            </div>

          </div>

          {/* CTA Box (4 Cols) */}
          <div className="lg:col-span-4 rounded-3xl border border-white/10 bg-[#020914] p-6 space-y-5 text-center flex flex-col justify-between h-full">
            <div className="space-y-3">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-[#007DC5]/20 text-[#007DC5] border border-[#007DC5]/40 shadow-inner">
                <Sparkles className="h-7 w-7 icon-animate" />
              </div>
              <h4 className="text-base font-black text-white font-display">
                {lang === 'fr' ? `Contacter le Délégué ${selectedProvince.name}` : `Connect with ${selectedProvince.name} Chapter`}
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed font-light">
                {lang === 'fr'
                  ? `Accédez aux représentants consulaires locaux, à la cartographie des opportunités et au réseau d'entreprises de la province de ${selectedProvince.name}.`
                  : `Access local trade representatives, investment guides, and provincial business networks across ${selectedProvince.name}.`}
              </p>
            </div>

            <a
              href="/register"
              className="inline-flex items-center justify-center gap-2 w-full rounded-2xl bg-gradient-to-r from-[#F7D618] via-[#FFD750] to-[#F59E0B] py-3.5 text-xs font-black text-slate-950 hover:brightness-105 transition-all shadow-xl"
            >
              <span>{lang === 'fr' ? 'Contacter le Délégué Régional →' : 'Contact Regional Delegate →'}</span>
            </a>
          </div>

        </div>

      </div>

    </div>
  );
};
