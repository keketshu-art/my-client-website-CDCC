import { NextResponse } from 'next/server';
import { writeFile, mkdir } from 'fs/promises';
import path from 'path';
import { getDataStore, saveDataStore } from '@/lib/dataStore';

export async function POST(request: Request) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;
    const titleEn = formData.get('titleEn') as string || 'Chamber Event Photo';
    const titleFr = formData.get('titleFr') as string || 'Photo d\'événement de la Chambre';
    const date = formData.get('date') as string || new Date().toISOString().split('T')[0];

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);

    const targetDir = path.join(process.cwd(), 'public', 'storage', 'events-gallery');
    await mkdir(targetDir, { recursive: true });

    const filename = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9.-]/g, '_')}`;
    const filePath = path.join(targetDir, filename);

    await writeFile(filePath, buffer);
    const publicUrl = `/storage/events-gallery/${filename}`;

    const store = getDataStore();
    const newGalleryItem = {
      id: `gal-${Date.now()}`,
      titleEn,
      titleFr,
      date,
      photos: [publicUrl],
    };

    store.gallery.unshift(newGalleryItem);
    saveDataStore(store);

    return NextResponse.json({
      success: true,
      url: publicUrl,
      item: newGalleryItem,
    });
  } catch (err) {
    console.error("Upload error:", err);
    return NextResponse.json({ error: "Failed to upload file" }, { status: 500 });
  }
}
