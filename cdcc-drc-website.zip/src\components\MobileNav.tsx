'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useLanguage } from '@/context/LanguageContext';
import { Home, Briefcase, Calendar, Network, PhoneCall } from 'lucide-react';

export const MobileNav: React.FC = () => {
  const { lang } = useLanguage();
  const pathname = usePathname();

  const navItems = [
    {
      href: '/',
      labelEn: 'Home',
      labelFr: 'Accueil',
      icon: Home,
    },
    {
      href: '/membership',
      labelEn: 'Services',
      labelFr: 'Adhésion',
      icon: Briefcase,
    },
    {
      href: '/events',
      labelEn: 'Events',
      labelFr: 'Événements',
      icon: Calendar,
    },
    {
      href: '/community',
      labelEn: 'Directory',
      labelFr: 'Communauté',
      icon: Network,
    },
    {
      href: '/contact',
      labelEn: 'Contact',
      labelFr: 'Contact',
      icon: PhoneCall,
    },
  ];

  const isActive = (path: string) => {
    if (path === '/' && pathname === '/') return true;
    if (path !== '/' && pathname.startsWith(path)) return true;
    return false;
  };

  return (
    <nav
      className="fixed bottom-0 inset-x-0 z-50 lg:hidden bg-[#07162C] border-t border-slate-800 shadow-[0_-4px_20px_rgba(0,0,0,0.3)] px-2 py-1.5 flex items-center justify-around"
      aria-label="Mobile Navigation Bar"
    >
      {navItems.map((item) => {
        const active = isActive(item.href);
        const Icon = item.icon;
        const label = lang === 'fr' ? item.labelFr : item.labelEn;

        return (
          <Link
            key={item.href}
            href={item.href}
            className={`flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all ${
              active
                ? 'text-amber-400 font-bold scale-105'
                : 'text-slate-400 hover:text-white font-medium'
            }`}
          >
            <Icon className={`h-5 w-5 mb-0.5 ${active ? 'text-amber-400' : 'text-slate-400'}`} />
            <span className="text-[10px] tracking-tight">{label}</span>
          </Link>
        );
      })}
    </nav>
  );
};
