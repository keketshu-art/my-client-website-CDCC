import { NextResponse } from 'next/server';
import { getDataStore, saveDataStore, EventItem } from '@/lib/dataStore';

export async function GET() {
  const store = getDataStore();
  return NextResponse.json(store.events);
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const store = getDataStore();

    const newEvent: EventItem = {
      id: `evt-${Date.now()}`,
      titleEn: body.titleEn || "New Chamber Event",
      titleFr: body.titleFr || "Nouvel événement de la Chambre",
      date: body.date || new Date().toISOString().split('T')[0],
      locationEn: body.locationEn || "Kinshasa · DRC",
      locationFr: body.locationFr || "Kinshasa · RDC",
      province: body.province || "Kinshasa",
      type: body.type || "Summit",
      descriptionEn: body.descriptionEn || "",
      descriptionFr: body.descriptionFr || "",
      image: body.image || "/storage/events-gallery/rOSz89UsxCsHn2kmiF2hsRUUhqFlokZrtNf7EbC8.jpg",
      isUpcoming: body.isUpcoming !== false,
    };

    store.events.unshift(newEvent);
    if (newEvent.isUpcoming) {
      store.stats.upcoming += 1;
    }
    store.stats.eventsTracked += 1;
    saveDataStore(store);

    return NextResponse.json({ success: true, event: newEvent });
  } catch (err) {
    return NextResponse.json({ error: "Failed to create event" }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: "ID required" }, { status: 400 });

    const store = getDataStore();
    const eventToDelete = store.events.find(e => e.id === id);
    store.events = store.events.filter(e => e.id !== id);
    if (eventToDelete?.isUpcoming && store.stats.upcoming > 0) {
      store.stats.upcoming -= 1;
    }
    saveDataStore(store);

    return NextResponse.json({ success: true });
  } catch (err) {
    return NextResponse.json({ error: "Failed to delete event" }, { status: 500 });
  }
}
