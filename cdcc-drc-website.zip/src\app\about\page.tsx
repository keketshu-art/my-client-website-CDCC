'use client';

import React from 'react';
import Link from 'next/link';
import { useLanguage } from '@/context/LanguageContext';
import {
  ShieldCheck,
  Award,
  History,
  Target,
  Eye,
  Building2,
  Users,
  CheckCircle2,
  Globe,
  ArrowRight,
} from 'lucide-react';

export default function AboutPage() {
  const { lang, t } = useLanguage();

  const boardMembers = [
    {
      name: 'Dr. Joseph Tshisekedi',
      title: 'President of the Executive Council',
      roleFr: 'Président du Conseil Exécutif',
      bioEn: 'Over 25 years of institutional experience leading cross-border trade negotiations and industrial policy advocacy.',
      bioFr: 'Plus de 25 ans d\'expérience institutionnelle à la tête de négociations commerciales et de plaidoyer industriel.',
      image: '/storage/events-gallery/7eFFWH6DdJSmT8zPqP9iZXz8IU7gaWt6ElJbkO2I.jpg',
    },
    {
      name: 'Mme. Marie-Claire Kalala',
      title: 'Vice-President · International Relations',
      roleFr: 'Vice-Présidente · Relations Internationales',
      bioEn: 'Pioneer in SADC trade relations, specializing in diaspora investment funds and mining sector integration.',
      bioFr: 'Pionnière des relations commerciales SADC, spécialisée dans les fonds d\'investissement diaspora et l\'intégration minière.',
      image: '/storage/events-gallery/NJ4gwHinL7OG6yrNFR62Fc3I7Hn08sTGpQsKCk5d.jpg',
    },
    {
      name: 'Mr. Pravir Kumar',
      title: 'Strategic Energy Representative (ArtSolar)',
      roleFr: 'Représentant Stratégique Énergie (ArtSolar)',
      bioEn: 'Leading large-scale renewable solar and hydroelectricity generation projects across Haut-Katanga and Lualaba.',
      bioFr: 'Dirige des projets de production d\'énergie solaire et hydroélectrique de grande envergure dans le Haut-Katanga et le Lualaba.',
      image: '/storage/events-gallery/artsolar-meeting.png',
    },
  ];

  const partners = [
    { name: 'ArtSolar South Africa', category: 'Energy & Renewables Partner' },
    { name: 'Sky Hotel Sandton', category: 'Diplomatic & Forum Venue Partner' },
    { name: 'ANAPI (National Agency for Investment Promotion)', category: 'Institutional Partner' },
    { name: 'Ministry of Industry & SME Development', category: 'Government Partner' },
    { name: 'Federation of Enterprises of Congo (FEC)', category: 'Strategic Alliance' },
  ];

  return (
    <div className="space-y-16 pb-12 pt-24 sm:pt-28">

      {/* Hero Header */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 rounded-full border border-sky-300 bg-sky-50 px-3.5 py-1.5 text-[11px] font-bold text-[#007DC5] uppercase tracking-wider">
          <History className="h-3.5 w-3.5 text-[#007DC5]" />
          <span>SERVING SINCE 1960 · 60+ YEARS</span>
        </div>

        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#07162C] font-display max-w-4xl leading-tight">
          {t('aboutPageTitle')}
        </h1>

        <p className="text-sm sm:text-base text-slate-600 max-w-3xl leading-relaxed">
          {t('aboutPageSub')}
        </p>
      </section>

      {/* Institutional Heritage */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="executive-card rounded-3xl p-6 sm:p-10 bg-white border-slate-200 space-y-6 shadow-xl relative overflow-hidden">
          <div className="flag-stripe h-[3px]" aria-hidden="true" />

          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div className="space-y-3">
              <span className="text-[10px] font-bold text-[#007DC5] uppercase tracking-widest block font-display">
                INSTITUTIONAL HERITAGE
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-[#07162C] font-display">
                {t('ourHistoryTitle')}
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-normal">
                {t('ourHistoryText')}
              </p>
            </div>

            <div className="rounded-2xl border border-amber-200 bg-amber-50 p-6 space-y-3">
              <div className="flex items-center gap-3">
                <ShieldCheck className="h-6 w-6 text-amber-600 shrink-0" />
                <h3 className="text-sm font-extrabold text-[#07162C] font-display">
                  {t('nonPartisanTitle')}
                </h3>
              </div>
              <p className="text-xs text-slate-700 leading-relaxed">
                {t('nonPartisanText')}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-6">
          <div className="executive-card rounded-3xl p-6 bg-white border-slate-200 space-y-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-sky-100 text-[#007DC5]">
              <Target className="h-5 w-5" />
            </div>
            <h3 className="text-xl font-extrabold text-[#07162C] font-display">
              {t('missionTitle')}
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              {t('missionText')}
            </p>
          </div>

          <div className="executive-card rounded-3xl p-6 bg-white border-slate-200 space-y-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-100 text-amber-700">
              <Eye className="h-5 w-5" />
            </div>
            <h3 className="text-xl font-extrabold text-[#07162C] font-display">
              {t('visionTitle')}
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              {t('visionText')}
            </p>
          </div>
        </div>
      </section>

      {/* Leadership & Executive Board */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-6">
        <div className="border-b border-slate-200 pb-3">
          <span className="text-[10px] font-bold text-[#007DC5] uppercase tracking-widest block font-display">
            ● EXECUTIVE GOVERNANCE
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-[#07162C] font-display">
            {t('leadershipTitle')}
          </h2>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {boardMembers.map((m, idx) => {
            const role = lang === 'fr' ? m.roleFr : m.title;
            const bio = lang === 'fr' ? m.bioFr : m.bioEn;
            return (
              <div
                key={idx}
                className="executive-card rounded-3xl overflow-hidden bg-white border-slate-200 flex flex-col justify-between"
              >
                <div className="aspect-[16/10] overflow-hidden bg-slate-100">
                  <img
                    src={m.image}
                    alt={m.name}
                    className="h-full w-full object-cover"
                  />
                </div>
                <div className="p-5 space-y-2 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-base font-extrabold text-[#07162C] font-display">
                      {m.name}
                    </h3>
                    <p className="text-xs font-bold text-amber-600">
                      {role}
                    </p>
                    <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                      {bio}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Strategic Partners & Alliances */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-6">
        <div className="border-b border-slate-200 pb-3">
          <span className="text-[10px] font-bold text-[#007DC5] uppercase tracking-widest block font-display">
            ● GLOBAL ECOSYSTEM
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-[#07162C] font-display">
            {t('partnersTitle')}
          </h2>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {partners.map((p, idx) => (
            <div
              key={idx}
              className="executive-card rounded-2xl p-5 bg-white border-slate-200 flex items-center justify-between gap-4"
            >
              <div>
                <h4 className="text-xs font-bold text-[#07162C]">
                  {p.name}
                </h4>
                <p className="text-[10px] text-slate-500">
                  {p.category}
                </p>
              </div>
              <CheckCircle2 className="h-4 w-4 text-[#007DC5] shrink-0" />
            </div>
          ))}
        </div>
      </section>

    </div>
  );
}
