import { NextResponse } from 'next/server';
import { getDataStore, saveDataStore } from '@/lib/dataStore';

export async function GET() {
  const store = getDataStore();
  return NextResponse.json(store);
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    if (body.stats) {
      const store = getDataStore();
      store.stats = { ...store.stats, ...body.stats };
      saveDataStore(store);
      return NextResponse.json({ success: true, stats: store.stats });
    }
    return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
  } catch (err) {
    return NextResponse.json({ error: "Failed to update stats" }, { status: 500 });
  }
}
