'use client';

import React, { useEffect, useState } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import { LightboxModal } from '@/components/LightboxModal';
import { EventRegisterModal } from '@/components/EventRegisterModal';
import { EventItem, GalleryItem } from '@/lib/dataStore';
import {
  Calendar,
  MapPin,
  Search,
  Filter,
  Maximize2,
  Tag,
  ChevronRight,
  Clock,
  ShieldCheck,
  Users,
  FileText,
  ArrowRight,
  UserCheck,
  RotateCcw,
  Sparkles
} from 'lucide-react';

export default function EventsPage() {
  const { lang, t } = useLanguage();
  const [events, setEvents] = useState<EventItem[]>([]);
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  
  // Filters State
  const [tab, setTab] = useState<'upcoming' | 'past' | 'all'>('upcoming');
  const [selectedSector, setSelectedSector] = useState<string>('all');
  const [selectedProvince, setSelectedProvince] = useState<string>('all');

  // Modals State
  const [registerModalOpen, setRegisterModalOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<EventItem | null>(null);

  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [selectedGallery, setSelectedGallery] = useState<{ photos: string[]; title: string; date?: string } | null>(null);

  // Live Protocol Countdown Timer state
  const [timeLeft, setTimeLeft] = useState({ days: 12, hours: 8, minutes: 34, seconds: 15 });

  useEffect(() => {
    fetch('/api/data')
      .then((res) => res.json())
      .then((data) => {
        if (data.events) setEvents(data.events);
        if (data.gallery) setGallery(data.gallery);
      })
      .catch((err) => console.error(err));

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        return { ...prev, seconds: 59, minutes: (prev.minutes + 59) % 60 };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const openRegisterModal = (evt: EventItem) => {
    setSelectedEvent(evt);
    setRegisterModalOpen(true);
  };

  const openLightbox = (item: GalleryItem) => {
    const title = lang === 'fr' ? item.titleFr : item.titleEn;
    setSelectedGallery({ photos: item.photos, title, date: item.date });
    setLightboxOpen(true);
  };

  const resetFilters = () => {
    setTab('upcoming');
    setSelectedSector('all');
    setSelectedProvince('all');
  };

  // Filter events based on selected sector & province
  const filteredEvents = events.filter((evt) => {
    if (selectedSector !== 'all') {
      const typeStr = (evt.type || '').toLowerCase();
      const descStr = ((evt.descriptionEn || '') + ' ' + (evt.titleEn || '')).toLowerCase();
      if (selectedSector === 'bilateral' && !typeStr.includes('bilateral') && !typeStr.includes('trade') && !descStr.includes('bilateral')) {
        return false;
      }
      if (selectedSector === 'clean energy' && !typeStr.includes('clean energy') && !typeStr.includes('energy') && !typeStr.includes('mining') && !descStr.includes('energy')) {
        return false;
      }
      if (selectedSector === 'agribusiness' && !typeStr.includes('agri') && !typeStr.includes('sme') && !descStr.includes('agri')) {
        return false;
      }
    }

    if (selectedProvince !== 'all') {
      const provStr = (evt.province || '').toLowerCase();
      if (!provStr.includes(selectedProvince.toLowerCase())) {
        return false;
      }
    }

    return true;
  });

  const flagshipEvent = filteredEvents.find((e) => e.id === 'evt-flagship-1') || filteredEvents[0];
  const agendaEvents = filteredEvents.filter((e) => e.id !== (flagshipEvent?.id || ''));

  return (
    <div className="space-y-12 pb-16 pt-24 sm:pt-28 bg-[#F2F5FA] min-h-screen">

      {/* 1. HERO HEADER */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 rounded-full border border-sky-300 bg-sky-50 px-4 py-1.5 text-[11px] font-bold text-[#0055A5] uppercase tracking-wider shadow-sm">
          <Calendar className="h-3.5 w-3.5 text-[#0055A5]" />
          <span>{lang === 'fr' ? 'AGENDA PROTOCOLAIRE 2026 · CHAMBRE OFFICIELLE RDC' : 'PROTOCOL AGENDA 2026 · OFFICIAL CHAMBER DRC'}</span>
        </div>

        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-[#001438] font-display max-w-4xl leading-tight">
          {lang === 'fr' ? 'Événements & Sommets Officiels' : 'Official Events & Summits'}
        </h1>

        <p className="text-sm sm:text-base text-amber-600 font-bold max-w-2xl">
          {lang === 'fr' 
            ? 'Sommets bilatéraux de haut niveau, tournées d\'investisseurs et forums commerciaux' 
            : 'High-Level Bilateral Summits, Investor Roadshows & Trade Forums'}
        </p>
      </section>

      {/* 2. TAB SWITCHER & SECTOR FILTERS */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-4">
        <div className="executive-card rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/80 space-y-4 shadow-sm">
          
          {/* Top Tabs */}
          <div className="flex flex-wrap items-center gap-2 border-b border-slate-200/70 pb-4">
            <button
              onClick={() => setTab('upcoming')}
              className={`rounded-xl px-5 py-2.5 text-xs font-black transition-all flex items-center gap-2 ${
                tab === 'upcoming' 
                  ? 'bg-[#002454] text-white shadow-md ring-2 ring-[#002454]/20' 
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Calendar className="h-3.5 w-3.5 text-amber-400" />
              <span>{lang === 'fr' ? 'Agendas À Venir' : 'Upcoming Agendas'}</span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] ${tab === 'upcoming' ? 'bg-amber-400 text-slate-950 font-bold' : 'bg-slate-200 text-slate-700'}`}>
                {events.length}
              </span>
            </button>

            <button
              onClick={() => setTab('past')}
              className={`rounded-xl px-5 py-2.5 text-xs font-black transition-all flex items-center gap-2 ${
                tab === 'past' 
                  ? 'bg-[#002454] text-white shadow-md ring-2 ring-[#002454]/20' 
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Sparkles className="h-3.5 w-3.5 text-amber-400" />
              <span>{lang === 'fr' ? 'Galerie des Sommets' : 'Past Gallery'}</span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] ${tab === 'past' ? 'bg-amber-400 text-slate-950 font-bold' : 'bg-slate-200 text-slate-700'}`}>
                {gallery.length}
              </span>
            </button>

            <button
              onClick={() => setTab('all')}
              className={`rounded-xl px-5 py-2.5 text-xs font-black transition-all flex items-center gap-2 ${
                tab === 'all' 
                  ? 'bg-[#002454] text-white shadow-md ring-2 ring-[#002454]/20' 
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <span>{lang === 'fr' ? 'Tous les Programmes' : 'All Programs'}</span>
            </button>

            {(selectedSector !== 'all' || selectedProvince !== 'all') && (
              <button
                onClick={resetFilters}
                className="ml-auto text-xs font-bold text-amber-600 hover:text-amber-700 flex items-center gap-1.5 bg-amber-50 px-3 py-1.5 rounded-lg border border-amber-200 transition-colors"
              >
                <RotateCcw className="h-3 w-3" />
                <span>{lang === 'fr' ? 'Réinitialiser Filtres' : 'Reset Filters'}</span>
              </button>
            )}
          </div>

          {/* Sector Pills & Territory Dropdown */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
              <button
                onClick={() => setSelectedSector('all')}
                className={`rounded-lg px-3.5 py-1.5 text-xs font-bold transition-all ${
                  selectedSector === 'all' ? 'bg-[#0055A5] text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {lang === 'fr' ? 'Tous les Secteurs' : 'All Focus Sectors'}
              </button>
              <button
                onClick={() => setSelectedSector('bilateral')}
                className={`rounded-lg px-3.5 py-1.5 text-xs font-bold transition-all ${
                  selectedSector === 'bilateral' ? 'bg-[#0055A5] text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {lang === 'fr' ? 'Commerce Bilatéral' : 'Bilateral Trade'}
              </button>
              <button
                onClick={() => setSelectedSector('clean energy')}
                className={`rounded-lg px-3.5 py-1.5 text-xs font-bold transition-all ${
                  selectedSector === 'clean energy' ? 'bg-[#0055A5] text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {lang === 'fr' ? 'Énergie Propre & Infrastructures' : 'Clean Energy & Infrastructure'}
              </button>
              <button
                onClick={() => setSelectedSector('agribusiness')}
                className={`rounded-lg px-3.5 py-1.5 text-xs font-bold transition-all ${
                  selectedSector === 'agribusiness' ? 'bg-[#0055A5] text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {lang === 'fr' ? 'Agro-business' : 'Agribusiness'}
              </button>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <MapPin className="h-4 w-4 text-[#0055A5] shrink-0" />
              <select
                value={selectedProvince}
                onChange={(e) => setSelectedProvince(e.target.value)}
                className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs text-slate-800 font-bold focus:border-[#0055A5] focus:outline-none w-full sm:w-auto cursor-pointer"
              >
                <option value="all">{lang === 'fr' ? 'Territoire: Toutes les Juridictions' : 'Territory / Province: All Jurisdictions'}</option>
                <option value="kinshasa">Kinshasa</option>
                <option value="haut-katanga">Haut-Katanga</option>
                <option value="lualaba">Lualaba</option>
                <option value="nord-kivu">Nord-Kivu</option>
              </select>
            </div>
          </div>

        </div>
      </section>

      {/* NO RESULTS EMPTY STATE */}
      {filteredEvents.length === 0 && (tab === 'upcoming' || tab === 'all') && (
        <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          <div className="bg-white rounded-2xl p-10 text-center space-y-4 border border-slate-200 shadow-sm">
            <Filter className="h-10 w-10 text-slate-300 mx-auto" />
            <h3 className="text-lg font-bold text-slate-800 font-display">
              {lang === 'fr' ? 'Aucun événement ne correspond à vos filtres' : 'No events match your current filter selection'}
            </h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              {lang === 'fr' 
                ? 'Essayez de changer de secteur ou de province pour afficher d\'autres événements protocolaires.' 
                : 'Try adjusting your sector or province dropdown to view available protocol summit agendas.'}
            </p>
            <button
              onClick={resetFilters}
              className="inline-flex items-center gap-2 bg-[#002454] text-white px-5 py-2.5 rounded-xl text-xs font-bold shadow-md hover:bg-[#003882] transition-all"
            >
              <RotateCcw className="h-3.5 w-3.5 text-amber-400" />
              <span>{lang === 'fr' ? 'Réinitialiser tous les filtres' : 'Reset All Filters'}</span>
            </button>
          </div>
        </section>
      )}

      {/* 3. FEATURED FLAGSHIP EVENT CARD WITH LIVE PROTOCOL COUNTDOWN */}
      {(tab === 'upcoming' || tab === 'all') && flagshipEvent && (
        <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          <div className="executive-card rounded-3xl p-6 sm:p-8 bg-white border-slate-200 space-y-6 shadow-xl relative overflow-hidden">
            <div className="flag-stripe h-[3px]" aria-hidden="true" />

            {/* Top Badges */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-full bg-sky-100 text-[#0055A5] border border-sky-200 text-[10px] font-bold px-3 py-1 uppercase tracking-wider">
                OFFICIAL CHAMBER FLAGSHIP
              </span>
              <span className="rounded-full bg-[#001438] text-amber-400 text-[10px] font-bold px-3 py-1 uppercase tracking-wider">
                DRC · INTERNATIONAL
              </span>
              <span className="rounded-full bg-emerald-100 text-emerald-700 text-[10px] font-bold px-3 py-1 uppercase tracking-wider">
                Confirmed Protocol
              </span>
            </div>

            {/* Cover Photo */}
            <div className="relative aspect-[16/8] rounded-2xl overflow-hidden border border-slate-200">
              <img
                src={flagshipEvent.image || "/storage/events-gallery/drc-uk-meeting.png"}
                alt={flagshipEvent.titleEn}
                className="h-full w-full object-cover"
              />
              <div className="absolute top-3 left-3 bg-[#001438]/90 backdrop-blur-md px-3.5 py-1.5 rounded-xl text-xs font-bold text-white uppercase tracking-wider border border-white/20">
                {flagshipEvent.locationEn}
              </div>
              <div className="absolute bottom-3 right-3 bg-[#FED701] text-slate-950 px-3.5 py-1 rounded-lg text-xs font-black shadow-md">
                {flagshipEvent.date}
              </div>
            </div>

            {/* Title & Description */}
            <div className="space-y-3">
              <h2 className="text-2xl sm:text-3xl font-extrabold text-[#001438] font-display">
                {lang === 'fr' ? flagshipEvent.titleFr : flagshipEvent.titleEn}
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-normal">
                {lang === 'fr' ? flagshipEvent.descriptionFr : flagshipEvent.descriptionEn}
              </p>
            </div>

            {/* Live Protocol Countdown Timer Bar */}
            <div className="rounded-2xl bg-sky-50 border border-sky-200 p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-[#0055A5]" />
                <span className="text-xs font-bold uppercase tracking-wider text-[#001438]">
                  {lang === 'fr' ? 'COMPTE À REBOURS PROTOCOLAIRE' : 'PROTOCOL COUNTDOWN'}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <div className="bg-[#001438] text-white rounded-xl px-3 py-1.5 text-center min-w-[50px]">
                  <p className="text-lg font-black font-mono leading-none">{String(timeLeft.days).padStart(2, '0')}</p>
                  <p className="text-[9px] text-amber-400 font-bold uppercase mt-0.5">D</p>
                </div>
                <span className="text-lg font-bold text-[#001438]">:</span>
                <div className="bg-[#001438] text-white rounded-xl px-3 py-1.5 text-center min-w-[50px]">
                  <p className="text-lg font-black font-mono leading-none">{String(timeLeft.hours).padStart(2, '0')}</p>
                  <p className="text-[9px] text-amber-400 font-bold uppercase mt-0.5">H</p>
                </div>
                <span className="text-lg font-bold text-[#001438]">:</span>
                <div className="bg-[#001438] text-white rounded-xl px-3 py-1.5 text-center min-w-[50px]">
                  <p className="text-lg font-black font-mono leading-none">{String(timeLeft.minutes).padStart(2, '0')}</p>
                  <p className="text-[9px] text-amber-400 font-bold uppercase mt-0.5">M</p>
                </div>
                <span className="text-lg font-bold text-[#001438]">:</span>
                <div className="bg-[#001438] text-amber-400 rounded-xl px-3 py-1.5 text-center min-w-[50px]">
                  <p className="text-lg font-black font-mono leading-none">{String(timeLeft.seconds).padStart(2, '0')}</p>
                  <p className="text-[9px] text-white font-bold uppercase mt-0.5">S</p>
                </div>
              </div>
            </div>

            {/* Confirmed Ministerial Keynotes */}
            <div className="space-y-2 pt-2">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                CONFIRMED MINISTERIAL KEYNOTES
              </span>
              <div className="grid sm:grid-cols-2 gap-3">
                <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="h-9 w-9 rounded-lg bg-[#001438] text-white font-extrabold flex items-center justify-center text-xs">
                    GK
                  </div>
                  <div>
                    <p className="text-xs font-bold text-[#001438]">H.E. J. Kabongo</p>
                    <p className="text-[10px] text-slate-500">Minister of Foreign Trade</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="h-9 w-9 rounded-lg bg-[#0055A5] text-white font-extrabold flex items-center justify-center text-xs">
                    SJ
                  </div>
                  <div>
                    <p className="text-xs font-bold text-[#001438]">Hon. S. Jenkins</p>
                    <p className="text-[10px] text-slate-500">UK Trade Commissioner</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Action Row */}
            <div className="pt-2 flex items-center gap-3">
              <button
                onClick={() => openRegisterModal(flagshipEvent)}
                className="rounded-xl bg-[#001438] hover:bg-[#002454] px-7 py-3 text-xs font-bold text-white transition-all shadow-md flex items-center gap-2"
              >
                <UserCheck className="h-4 w-4 text-amber-400" />
                <span>{lang === 'fr' ? 'S\'inscrire à l\'Événement' : 'Register to Attend'}</span>
              </button>

              <button
                onClick={() => alert(lang === 'fr' ? "Téléchargement du Communiqué Officiel." : "Downloading Official Ministerial Protocol Accord PDF.")}
                className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 transition-colors"
                title="Official Communique PDF"
              >
                <FileText className="h-4 w-4" />
              </button>
            </div>

          </div>
        </section>
      )}

      {/* 4. UPCOMING OFFICIAL AGENDAS LIST */}
      {(tab === 'upcoming' || tab === 'all') && agendaEvents.length > 0 && (
        <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-6">
          <div className="border-b border-slate-200 pb-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black text-[#0055A5] uppercase tracking-widest block font-display">
                ● {lang === 'fr' ? 'AGENDAS OFFICIELS À VENIR' : 'UPCOMING OFFICIAL AGENDAS'}
              </span>
              <span className="rounded-full bg-slate-200 text-slate-700 text-[10px] font-bold px-2 py-0.5">
                {agendaEvents.length} {lang === 'fr' ? 'Confirmés' : 'Confirmed'}
              </span>
            </div>
          </div>

          <div className="space-y-4">
            {agendaEvents.map((evt) => (
              <div key={evt.id} className="executive-card rounded-2xl p-5 bg-white border-slate-200 space-y-3 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="rounded-md bg-emerald-50 text-emerald-700 font-bold text-[10px] px-2.5 py-0.5 uppercase">
                      {evt.type}
                    </span>
                    <span className="rounded-md bg-amber-50 text-amber-800 font-bold text-[10px] px-2.5 py-0.5">
                      {evt.province}
                    </span>
                  </div>
                  <span className="text-xs font-extrabold text-[#001438] bg-slate-100 px-3 py-1 rounded-lg w-fit">
                    {evt.date}
                  </span>
                </div>

                <h3 className="text-xl font-extrabold text-[#001438] font-display">
                  {lang === 'fr' ? evt.titleFr : evt.titleEn}
                </h3>

                <p className="text-xs text-slate-600 leading-relaxed">
                  {lang === 'fr' ? evt.descriptionFr : evt.descriptionEn}
                </p>

                <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-t border-slate-100 text-xs">
                  <div className="flex items-center gap-4 text-slate-500">
                    <span className="flex items-center gap-1 font-medium">
                      <MapPin className="h-3.5 w-3.5 text-[#0055A5]" />
                      {lang === 'fr' ? evt.locationFr : evt.locationEn}
                    </span>
                  </div>

                  <button
                    onClick={() => openRegisterModal(evt)}
                    className="rounded-xl bg-sky-100 hover:bg-sky-200 text-[#0055A5] px-4 py-2 font-bold transition-all text-center"
                  >
                    {lang === 'fr' ? 'Demander une Accréditation' : 'Request Accreditation'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 5. PAST SUMMITS & DIPLOMATIC GALLERY */}
      {(tab === 'past' || tab === 'all') && (
        <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-6">
          <div className="border-b border-slate-200 pb-3 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-black text-amber-600 uppercase tracking-widest block font-display">
                ● {lang === 'fr' ? 'ARCHIVES & SOMMETS PASSÉS' : 'PAST SUMMITS & GALLERY'}
              </span>
              <h2 className="text-2xl font-black text-[#001438] font-display">
                {lang === 'fr' ? 'Galerie des Sommets et Rencontres Diplômatiques' : 'Past Summits & Diplomatic Gallery'}
              </h2>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {gallery.map((g) => {
              const title = lang === 'fr' ? g.titleFr : g.titleEn;
              const cover = g.photos[0] || '/storage/events-gallery/drc-uk-meeting.png';

              return (
                <div
                  key={g.id}
                  onClick={() => openLightbox(g)}
                  className="executive-card rounded-2xl overflow-hidden cursor-pointer group hover:border-[#0055A5]/40 transition-all bg-white flex flex-col justify-between shadow-sm hover:shadow-md"
                >
                  <div className="relative aspect-[16/10] bg-slate-100 overflow-hidden">
                    <img src={cover} alt={title} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                    <div className="absolute top-3 left-3 bg-[#001438]/90 text-amber-400 font-bold text-[10px] px-2.5 py-1 rounded-md border border-amber-400/20">
                      CHAMBER ARCHIVE
                    </div>
                  </div>

                  <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                    <div className="space-y-2">
                      <h3 className="text-sm font-bold text-[#001438] group-hover:text-[#0055A5] transition-colors leading-snug">
                        {title}
                      </h3>
                    </div>

                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                      <span className="text-[11px] text-slate-500">{g.date}</span>
                      <span className="font-bold text-[#0055A5] flex items-center gap-1">
                        <span>{lang === 'fr' ? 'Voir Galerie' : 'View Gallery'}</span>
                        <ArrowRight className="h-3 w-3" />
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Modals */}
      {selectedGallery && (
        <LightboxModal
          isOpen={lightboxOpen}
          onClose={() => setLightboxOpen(false)}
          photos={selectedGallery.photos}
          title={selectedGallery.title}
          date={selectedGallery.date}
        />
      )}

      {selectedEvent && (
        <EventRegisterModal
          isOpen={registerModalOpen}
          onClose={() => setRegisterModalOpen(false)}
          event={selectedEvent}
        />
      )}

    </div>
  );
}
