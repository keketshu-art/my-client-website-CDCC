'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useLanguage } from '@/context/LanguageContext';
import {
  CheckCircle2,
  Sparkles,
  ShieldCheck,
  TrendingUp,
  FileCheck,
  Globe2,
  Users,
  ChevronDown,
  ArrowRight,
  UserCheck,
  Building2,
  Mail,
  Phone,
  Send,
  Star,
  Award,
  Check,
} from 'lucide-react';

export default function MembershipPage() {
  const { lang, t } = useLanguage();
  const [billingCycle, setBillingCycle] = useState<'annual' | 'monthly'>('annual');
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  // Form State
  const [formData, setFormData] = useState({
    fullName: '',
    company: '',
    sector: 'Agribusiness & Food Security',
    province: 'Kinshasa',
    tier: 'Corporate Enterprise',
    email: '',
    phone: '',
    objectives: '',
    agreedOHADA: false,
  });

  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.agreedOHADA) {
      alert("Please attest to OHADA compliance before submitting.");
      return;
    }
    setLoading(true);

    try {
      const res = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName: formData.fullName,
          email: formData.email,
          phone: formData.phone,
          company: formData.company,
          sector: formData.sector,
          province: formData.province,
          country: 'Democratic Republic of the Congo',
          type: 'general',
          message: `Tier: ${formData.tier}. Objectives: ${formData.objectives}`,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setSubmitted(true);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const faqs = [
    {
      q: 'Who can join CDCC?',
      a: 'Any registered Congolese enterprise, foreign investor, sole proprietor, or diaspora founder operating or investing in the Democratic Republic of the Congo.',
    },
    {
      q: 'How does CDCC support foreign investors?',
      a: 'We provide expedited ANAPI tax incentive clearance, legal arbitration protection, direct bilateral ministerial introductions, and customs fast-tracking across all 26 provinces.',
    },
    {
      q: 'Are provincial chapters active in all 26 provinces?',
      a: 'Yes. The CDCC maintains accredited regional chapter presidencies and one-stop trade desks across every provincial capital from Haut-Katanga to Kongo Central.',
    },
    {
      q: 'How does Diaspora membership work?',
      a: 'Diaspora members receive 5-year capital equipment import duty rebates, priority co-investment matchmaking, and direct land tenure assistance.',
    },
  ];

  return (
    <div className="space-y-16 pb-12 pt-24 sm:pt-28">

      {/* 1. HERO HEADER */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-4 text-center sm:text-left">
        <div className="inline-flex items-center gap-2 rounded-full border border-amber-400/40 bg-amber-50 px-3.5 py-1.5 text-[11px] font-bold text-amber-700 uppercase tracking-wider">
          <Sparkles className="h-3.5 w-3.5 text-amber-600" />
          <span>JOIN THE NATIONAL NETWORK · RDC 26 PROVINCES</span>
        </div>

        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#07162C] font-display max-w-4xl leading-tight">
          Empowering DRC Enterprises & Global Partners
        </h1>

        <p className="text-sm sm:text-base text-slate-600 max-w-3xl leading-relaxed font-normal">
          Since 1960, the CDCC has stood as the sovereign institutional bridge connecting local innovators, multinational corporations, and diaspora capital across all 26 provincial chapters to accelerated bilateral corridors.
        </p>

        {/* 3 Metric Chips */}
        <div className="grid grid-cols-3 gap-4 pt-4 max-w-2xl">
          <div className="executive-card rounded-2xl p-4 bg-white border border-slate-200">
            <p className="font-display text-2xl font-black text-[#007DC5]">26</p>
            <p className="text-xs font-bold text-[#07162C]">ACTIVE CHAPTERS</p>
          </div>

          <div className="executive-card rounded-2xl p-4 bg-white border border-slate-200">
            <p className="font-display text-2xl font-black text-amber-600">2,400+</p>
            <p className="text-xs font-bold text-[#07162C]">ENTERPRISES</p>
          </div>

          <div className="executive-card rounded-2xl p-4 bg-white border border-slate-200">
            <p className="font-display text-2xl font-black text-emerald-600">$1.8B+</p>
            <p className="text-xs font-bold text-[#07162C]">FACILITATED</p>
          </div>
        </div>

        {/* Ministerial Photo Banner */}
        <div className="pt-4">
          <div className="executive-card rounded-2xl overflow-hidden relative aspect-[21/8] border border-slate-200 shadow-md">
            <img
              src="/storage/events-gallery/drc-uk-meeting.png"
              alt="Direct ministerial representation & trade facilitation"
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#07162C]/90 via-transparent to-transparent p-4 flex items-end">
              <span className="text-xs font-bold text-white flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-amber-400" />
                <span>Direct ministerial representation & trade facilitation</span>
              </span>
            </div>
          </div>
        </div>
      </section>


      {/* 2. MEMBERSHIP TIERS */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-200 pb-3">
          <div>
            <span className="text-[10px] font-bold text-[#007DC5] uppercase tracking-widest block font-display">
              ● MEMBERSHIP STRUCTURE
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#07162C] font-display">
              Membership Tiers
            </h2>
          </div>

          {/* Annual / Monthly Toggle */}
          <div className="flex items-center gap-1 rounded-xl bg-slate-200/80 p-1 w-fit">
            <button
              onClick={() => setBillingCycle('annual')}
              className={`rounded-lg px-4 py-1.5 text-xs font-bold transition-all ${
                billingCycle === 'annual' ? 'bg-white text-[#07162C] shadow-sm' : 'text-slate-600'
              }`}
            >
              Annual (Save 18%)
            </button>
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`rounded-lg px-4 py-1.5 text-xs font-bold transition-all ${
                billingCycle === 'monthly' ? 'bg-white text-[#07162C] shadow-sm' : 'text-slate-600'
              }`}
            >
              Monthly
            </button>
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">

          {/* Tier 1: Individual */}
          <div className="executive-card rounded-3xl p-6 bg-white border-slate-200 space-y-5 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold text-[#07162C]">Individual & Entrepreneur</span>
                <UserCheck className="h-4 w-4 text-slate-400" />
              </div>
              <p className="text-[11px] text-slate-500">Sole traders & early-stage founders</p>

              <div className="pt-2">
                <span className="font-display text-3xl font-black text-[#07162C]">$150</span>
                <span className="text-xs text-slate-500 font-medium"> / year (an)</span>
              </div>

              <ul className="space-y-2.5 text-xs text-slate-600 pt-3 border-t border-slate-100">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-[#007DC5] shrink-0 mt-0.5" />
                  <span>Access to digital trade resource center</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-[#007DC5] shrink-0 mt-0.5" />
                  <span>Entry to monthly chamber networking mixers</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-[#007DC5] shrink-0 mt-0.5" />
                  <span>Standard DRC business directory listing</span>
                </li>
              </ul>
            </div>

            <button
              onClick={() => {
                setFormData((prev) => ({ ...prev, tier: 'Individual & Entrepreneur' }));
                document.getElementById('application-form')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="w-full rounded-xl bg-sky-50 hover:bg-sky-100 text-[#007DC5] border border-sky-200 py-3 text-xs font-bold transition-all"
            >
              Apply Now →
            </button>
          </div>

          {/* Tier 2: SME */}
          <div className="executive-card rounded-3xl p-6 bg-white border-slate-200 space-y-5 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold text-[#07162C]">SME / PME Chapter Member</span>
                <Building2 className="h-4 w-4 text-[#007DC5]" />
              </div>
              <p className="text-[11px] text-slate-500">Registered domestic companies</p>

              <div className="pt-2">
                <span className="font-display text-3xl font-black text-[#07162C]">$500</span>
                <span className="text-xs text-slate-500 font-medium"> / year (an)</span>
              </div>

              <ul className="space-y-2.5 text-xs text-slate-600 pt-3 border-t border-slate-100">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-[#007DC5] shrink-0 mt-0.5" />
                  <span>Voting rights at provincial chapter assemblies</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-[#007DC5] shrink-0 mt-0.5" />
                  <span>Trade facilitation & customs compliance desk</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-[#007DC5] shrink-0 mt-0.5" />
                  <span>Quarterly legal clinic & tax advisory access</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-[#007DC5] shrink-0 mt-0.5" />
                  <span>Verified B2B matchmaking meetings</span>
                </li>
              </ul>
            </div>

            <button
              onClick={() => {
                setFormData((prev) => ({ ...prev, tier: 'SME / PME Chapter Member' }));
                document.getElementById('application-form')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="w-full rounded-xl bg-sky-50 hover:bg-sky-100 text-[#007DC5] border border-sky-200 py-3 text-xs font-bold transition-all"
            >
              Apply Now →
            </button>
          </div>

          {/* Tier 3: Corporate Enterprise (FEATURED DARK CARD WITH GOLD HIGHLIGHT) */}
          <div className="sovereign-card rounded-3xl p-6 space-y-5 flex flex-col justify-between shadow-2xl relative border-amber-400/40">
            <div className="absolute top-3 right-3 bg-amber-500 text-slate-950 px-2.5 py-0.5 rounded-full text-[9px] font-extrabold uppercase flex items-center gap-1">
              <Star className="h-3 w-3 fill-slate-950" />
              <span>MOST POPULAR / PRIORITÉ</span>
            </div>

            <div className="space-y-3 pt-2">
              <span className="text-sm font-extrabold text-white block">Corporate Enterprise</span>
              <p className="text-[11px] text-slate-300">Congolese & multinational leaders</p>

              <div className="pt-2">
                <span className="font-display text-3xl font-black text-amber-400">$2,500</span>
                <span className="text-xs text-slate-300 font-medium"> / year (an)</span>
              </div>

              <ul className="space-y-2.5 text-xs text-slate-200 pt-3 border-t border-slate-800">
                <li className="flex items-start gap-2">
                  <Star className="h-4 w-4 text-amber-400 shrink-0 mt-0.5 fill-amber-400" />
                  <span>Boardroom diplomatic & ministerial access</span>
                </li>
                <li className="flex items-start gap-2">
                  <Star className="h-4 w-4 text-amber-400 shrink-0 mt-0.5 fill-amber-400" />
                  <span>Priority DRC bilateral trade missions abroad</span>
                </li>
                <li className="flex items-start gap-2">
                  <Star className="h-4 w-4 text-amber-400 shrink-0 mt-0.5 fill-amber-400" />
                  <span>Complimentary Kinshasa Expo summit pavilion booth</span>
                </li>
                <li className="flex items-start gap-2">
                  <Star className="h-4 w-4 text-amber-400 shrink-0 mt-0.5 fill-amber-400" />
                  <span>Parliamentary policy lobbying & legal advocacy</span>
                </li>
                <li className="flex items-start gap-2">
                  <Star className="h-4 w-4 text-amber-400 shrink-0 mt-0.5 fill-amber-400" />
                  <span>Dedicated sovereign relationship manager</span>
                </li>
              </ul>
            </div>

            <button
              onClick={() => {
                setFormData((prev) => ({ ...prev, tier: 'Corporate Enterprise' }));
                document.getElementById('application-form')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="w-full rounded-xl bg-gradient-to-r from-[#F7D618] via-[#FFD750] to-[#F59E0B] text-slate-950 py-3 text-xs font-bold shadow-md hover:brightness-105 transition-all flex items-center justify-center gap-1.5"
            >
              <Check className="h-4 w-4" />
              <span>Apply as Corporate / Postuler</span>
            </button>
          </div>

          {/* Tier 4: Diaspora Partner */}
          <div className="executive-card rounded-3xl p-6 bg-white border-slate-200 space-y-5 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold text-[#07162C]">Diaspora Global Partner</span>
                <Globe2 className="h-4 w-4 text-purple-600" />
              </div>
              <p className="text-[11px] text-slate-500">Congolese abroad & international founders</p>

              <div className="pt-2">
                <span className="font-display text-3xl font-black text-[#07162C]">$350</span>
                <span className="text-xs text-slate-500 font-medium"> / year (an)</span>
              </div>

              <ul className="space-y-2.5 text-xs text-slate-600 pt-3 border-t border-slate-100">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-purple-600 shrink-0 mt-0.5" />
                  <span>International investment & local syndication matchmaking</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-purple-600 shrink-0 mt-0.5" />
                  <span>Consular protocol & multi-entry visa expedited clearance</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-purple-600 shrink-0 mt-0.5" />
                  <span>Land tenure, real estate & customs repatriation guide</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-purple-600 shrink-0 mt-0.5" />
                  <span>Virtual participation in CDCC plenary sessions</span>
                </li>
              </ul>
            </div>

            <button
              onClick={() => {
                setFormData((prev) => ({ ...prev, tier: 'Diaspora Global Partner' }));
                document.getElementById('application-form')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="w-full rounded-xl bg-sky-50 hover:bg-sky-100 text-[#007DC5] border border-sky-200 py-3 text-xs font-bold transition-all"
            >
              Apply Now →
            </button>
          </div>

        </div>
      </section>


      {/* 3. CHAMBER MEMBERSHIP APPLICATION FORM */}
      <section id="application-form" className="px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <div className="executive-card rounded-3xl p-6 sm:p-10 bg-white border-slate-200 space-y-6 shadow-xl relative overflow-hidden">
          <div className="flag-stripe h-[3px]" aria-hidden="true" />

          <div>
            <span className="text-[10px] font-bold text-[#007DC5] uppercase tracking-widest block font-display">
              ● OFFICIAL REGISTRATION PROTOCOL
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#07162C] font-display">
              Chamber Membership Application
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Submit your credentials for review by the CDCC Credentials Committee. Confirmation within 48 business hours.
            </p>
          </div>

          {submitted ? (
            <div className="p-8 text-center space-y-4 bg-emerald-50 rounded-2xl border border-emerald-200">
              <CheckCircle2 className="h-12 w-12 text-emerald-600 mx-auto" />
              <h3 className="text-xl font-bold text-[#07162C]">Application Received</h3>
              <p className="text-xs text-slate-600 max-w-md mx-auto">
                Thank you for applying for CDCC Membership. Our credentials delegation will contact you via corporate email with your official reference code.
              </p>
              <button
                onClick={() => setSubmitted(false)}
                className="rounded-xl bg-[#07162C] text-white text-xs font-bold px-5 py-2.5"
              >
                Submit Another Application
              </button>
            </div>
          ) : (
            <form onSubmit={handleFormSubmit} className="space-y-4">
              
              {/* Row 1 */}
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Full Legal Name *
                  </label>
                  <div className="relative">
                    <UserCheck className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <input
                      type="text"
                      required
                      placeholder="Ex: Dieudonné Mwamba"
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 pl-10 pr-4 py-2.5 text-xs text-slate-900 focus:border-[#007DC5] focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Company / Entity Name *
                  </label>
                  <div className="relative">
                    <Building2 className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <input
                      type="text"
                      required
                      placeholder="Congo Agribusiness Alliance SARL"
                      value={formData.company}
                      onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 pl-10 pr-4 py-2.5 text-xs text-slate-900 focus:border-[#007DC5] focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Row 2 */}
              <div className="grid sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Business Sector *
                  </label>
                  <select
                    value={formData.sector}
                    onChange={(e) => setFormData({ ...formData, sector: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-xs text-slate-900 focus:border-[#007DC5] focus:outline-none"
                  >
                    <option value="Agribusiness & Food Security">Agribusiness & Food Security</option>
                    <option value="Mining & Minerals">Mining & Minerals</option>
                    <option value="Clean Energy & Infrastructure">Clean Energy & Infrastructure</option>
                    <option value="Fintech & Banking">Fintech & Banking</option>
                    <option value="Import / Export Trade">Import / Export Trade</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Provincial Chapter Base *
                  </label>
                  <select
                    value={formData.province}
                    onChange={(e) => setFormData({ ...formData, province: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-xs text-slate-900 focus:border-[#007DC5] focus:outline-none"
                  >
                    <option value="Kinshasa">Kinshasa (Metropolitan)</option>
                    <option value="Haut-Katanga">Haut-Katanga (Lubumbashi)</option>
                    <option value="Lualaba">Lualaba (Kolwezi)</option>
                    <option value="Kongo Central">Kongo Central (Matadi)</option>
                    <option value="Nord-Kivu">Nord-Kivu (Goma)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Desired Membership Tier *
                  </label>
                  <select
                    value={formData.tier}
                    onChange={(e) => setFormData({ ...formData, tier: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-xs text-slate-900 focus:border-[#007DC5] focus:outline-none"
                  >
                    <option value="Individual & Entrepreneur">Individual ($150/yr)</option>
                    <option value="SME / PME Chapter Member">SME Chapter ($500/yr)</option>
                    <option value="Corporate Enterprise">Corporate Enterprise ($2,500/yr)</option>
                    <option value="Diaspora Global Partner">Diaspora Partner ($350/yr)</option>
                  </select>
                </div>
              </div>

              {/* Row 3 */}
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Corporate Email *
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <input
                      type="email"
                      required
                      placeholder="direction@enterprise.cd"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 pl-10 pr-4 py-2.5 text-xs text-slate-900 focus:border-[#007DC5] focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Telephone / WhatsApp *
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <input
                      type="tel"
                      required
                      placeholder="+243 81 000 0000"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 pl-10 pr-4 py-2.5 text-xs text-slate-900 focus:border-[#007DC5] focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Objectives Textarea */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Key Commercial Objectives (Optional)
                </label>
                <textarea
                  rows={3}
                  placeholder="Outline your domestic market focus, import/export needs, or capital partnerships..."
                  value={formData.objectives}
                  onChange={(e) => setFormData({ ...formData, objectives: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-xs text-slate-900 focus:border-[#007DC5] focus:outline-none"
                />
              </div>

              {/* Checkbox */}
              <div className="flex items-start gap-2 pt-2">
                <input
                  type="checkbox"
                  id="ohadaCheck"
                  checked={formData.agreedOHADA}
                  onChange={(e) => setFormData({ ...formData, agreedOHADA: e.target.checked })}
                  className="mt-0.5 rounded border-slate-300 text-[#007DC5] focus:ring-[#007DC5]"
                />
                <label htmlFor="ohadaCheck" className="text-[11px] text-slate-600">
                  I attest that the information provided is compliant with DRC OHADA corporate registrations and CDCC ethical charters.
                </label>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={loading}
                className="w-full rounded-xl bg-[#07162C] hover:bg-[#0C2344] py-3.5 text-xs font-bold text-white transition-all shadow-md flex items-center justify-center gap-2"
              >
                <Send className="h-4 w-4 text-amber-400" />
                <span>{loading ? 'Processing Credentials...' : 'Submit Application / Soumettre'}</span>
              </button>
            </form>
          )}

        </div>
      </section>


      {/* 4. BILATERAL TRADE DESKS BANNER */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="rounded-3xl bg-[#007DC5] text-white p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-lg">
          <div className="space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-sky-200">
              BILATERAL TRADE DESKS
            </span>
            <h3 className="text-xl sm:text-2xl font-extrabold font-display">
              Pretoria · Brussels · Paris · Kinshasa
            </h3>
            <p className="text-xs text-sky-100 max-w-xl">
              Active bilateral desks facilitate customs fast-tracking, sovereign tax mitigation, and high-level consular introductions for our certified member network.
            </p>
          </div>
          <span className="rounded-full bg-white/20 border border-white/30 text-white font-bold text-xs px-4 py-2 shrink-0">
            Over 40 partner chambers worldwide
          </span>
        </div>
      </section>


      {/* 5. FREQUENTLY ASKED QUESTIONS */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto space-y-6">
        <div className="text-center space-y-1">
          <span className="text-[10px] font-bold text-[#007DC5] uppercase tracking-widest block font-display">
            ● INSTITUTIONAL PROTOCOL
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-[#07162C] font-display">
            Frequently Asked Questions
          </h2>
          <p className="text-xs text-slate-500">
            Essential details on chamber status, legal standing, foreign investment corridors, and membership governance.
          </p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, idx) => {
            const isOpen = openFaq === idx;
            return (
              <div key={idx} className="executive-card rounded-2xl bg-white border-slate-200 overflow-hidden">
                <button
                  onClick={() => setOpenFaq(isOpen ? null : idx)}
                  className="w-full p-4 text-left font-bold text-xs sm:text-sm text-[#07162C] flex items-center justify-between gap-4"
                >
                  <span>{faq.q}</span>
                  <ChevronDown className={`h-4 w-4 text-[#007DC5] transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                </button>
                {isOpen && (
                  <div className="px-4 pb-4 text-xs text-slate-600 leading-relaxed border-t border-slate-100 pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

    </div>
  );
}
