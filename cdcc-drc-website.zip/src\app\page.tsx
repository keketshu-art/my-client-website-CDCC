'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useLanguage } from '@/context/LanguageContext';
import { StatsCounter } from '@/components/StatsCounter';
import { LightboxModal } from '@/components/LightboxModal';
import { EventRegisterModal } from '@/components/EventRegisterModal';
import { EventItem, GalleryItem, StatsCounters } from '@/lib/dataStore';
import {
  ArrowRight,
  Calendar,
  MapPin,
  Sparkles,
  Users,
  Building2,
  Globe2,
  BookOpen,
  GraduationCap,
  Award,
  Maximize2,
  ChevronRight,
  ShieldCheck,
  TrendingUp,
  FileCheck,
  CheckCircle2,
  Layers,
  ArrowUpRight,
  Clock,
  UserCheck,
  Linkedin,
  Twitter,
  Youtube,
  Zap,
  Anchor,
  Pickaxe,
  Briefcase,
  Sprout,
  Landmark,
  Quote,
  Shield,
  FileText,
  Search,
  Scale,
  Send,
  Building,
  Check,
  Flame,
  Radio,
  Cpu,
} from 'lucide-react';

export default function HomePage() {
  const { lang, t } = useLanguage();
  const [stats, setStats] = useState<StatsCounters>({
    members: 5000,
    provinces: 26,
    eventsPerYear: 120,
    registered: 5000,
    upcoming: 5,
    eventsTracked: 148,
    yearsOfService: 66,
  });

  const [upcomingEvents, setUpcomingEvents] = useState<EventItem[]>([]);
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>([]);
  const [selectedFilter, setSelectedFilter] = useState<string>('all');
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeLocationTab, setActiveLocationTab] = useState<'pretoria' | 'kinshasa' | 'desks'>('pretoria');

  // Form State
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', sector: '', province: '' });
  
  // Lightbox Modal State
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [selectedGallery, setSelectedGallery] = useState<{ photos: string[]; title: string; date?: string } | null>(null);

  // Event Register Modal State
  const [registerModalOpen, setRegisterModalOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<EventItem | null>(null);

  const testimonials = [
    {
      name: 'Marie Kabongo',
      titleEn: 'Founder · Lubumbashi',
      titleFr: 'Fondatrice · Lubumbashi',
      avatar: '/images/marie-kabongo.jpg',
      quoteEn: 'The Chamber opened regional markets we could not reach alone.',
      quoteFr: 'La Chambre a transformé notre accès aux marchés régionaux.',
      trustEn: 'TRUST. TRANSPARENCY. MEASURABLE GROWTH.',
      trustFr: 'CONFIANCE. TRANSPARENCE. CROISSANCE MESURABLE.',
    },
    {
      name: 'Dieudonné Mwamba',
      titleEn: 'CEO, Congo Agribusiness · Kinshasa',
      titleFr: 'PDG, Congo Agribusiness · Kinshasa',
      avatar: '/storage/events-gallery/NJ4gwHinL7OG6yrNFR62Fc3I7Hn08sTGpQsKCk5d.jpg',
      quoteEn: 'Export certification through CDCC cut our customs clearance time in half.',
      quoteFr: 'La certification CDCC a réduit nos délais douaniers de moitié.',
      trustEn: 'VERIFIED EXPORTER · OHADA FRAMEWORK.',
      trustFr: 'EXPORTATEUR VÉRIFIÉ · CADRE OHADA.',
    },
    {
      name: 'Mr. Pravir Kumar',
      titleEn: 'Managing Director, ArtSolar · Lualaba',
      titleFr: 'Directeur Général, ArtSolar · Lualaba',
      avatar: '/storage/events-gallery/artsolar-meeting.png',
      quoteEn: 'Partnering with the Chamber unlocked 150MW of solar infrastructure across copper-cobalt corridors.',
      quoteFr: 'Notre partenariat avec la Chambre a débloqué 150MW d\'infrastructures solaires.',
      trustEn: 'INSTITUTIONAL ENERGY PARTNER · GREEN MINING.',
      trustFr: 'PARTENAIRE ÉNERGÉTIQUE INSTITUTIONNEL.',
    },
  ];

  useEffect(() => {
    fetch('/api/data')
      .then((res) => res.json())
      .then((data) => {
        if (data.stats) setStats(data.stats);
        if (data.events) {
          setUpcomingEvents(data.events.filter((e: EventItem) => e.isUpcoming));
        }
        if (data.gallery) setGalleryItems(data.gallery);
      })
      .catch((err) => console.error("Error loading home data:", err));
  }, []);

  const openLightbox = (item: GalleryItem) => {
    const title = lang === 'fr' ? item.titleFr : item.titleEn;
    setSelectedGallery({ photos: item.photos, title, date: item.date });
    setLightboxOpen(true);
  };

  const openRegisterModal = (evt: EventItem) => {
    setSelectedEvent(evt);
    setRegisterModalOpen(true);
  };

  const handleQuickRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email) return;
    setFormSubmitted(true);
  };

  const filteredEvents = upcomingEvents.filter((evt) => {
    if (selectedFilter === 'all') return true;
    return evt.type.toLowerCase().includes(selectedFilter.toLowerCase());
  });

  const currentTestimonial = testimonials[activeTestimonial];

  return (
    <div className="space-y-16 pb-12 pt-20 sm:pt-24 bg-[#F2F5FA]">

      {/* 1. HERO SECTION */}
      <section className="px-2 sm:px-4 lg:px-6 w-full max-w-[1600px] mx-auto">
        <div className="relative w-full rounded-3xl overflow-hidden shadow-2xl min-h-[640px] lg:min-h-[740px] bg-[#001438] border border-blue-900/30 flex flex-col justify-between p-5 sm:p-8 lg:p-12">
          
          {/* Background Image (Image 2) */}
          <div className="absolute inset-0 z-0">
            <img
              src="/images/hero-bg-clean.png"
              alt="CDCC DRC Hero Background"
              className="h-full w-full object-cover object-[55%_center] lg:object-center"
            />
            {/* Soft gradient overlay on left side */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#001438]/85 via-[#001438]/35 to-transparent pointer-events-none max-w-xl" />
          </div>

          {/* Top Row inside Hero: Top Right Floating Navigation Pill */}
          <div className="relative z-30 flex items-center justify-between w-full">
            {/* Small Brand Emblem / Badge on top left */}
            <div className="flex items-center gap-3 bg-blue-950/60 backdrop-blur-md border border-white/20 px-4 py-2 rounded-full shadow-lg">
              <img
                src="/images/cdcc-logo.png"
                alt="CDCC Emblem"
                className="h-7 w-auto object-contain brightness-125"
                style={{ height: '28px', width: 'auto' }}
              />
              <span className="text-xs font-black text-white font-display tracking-tight hidden sm:inline">
                Chambre de Commerce <span className="text-amber-400">· RDC</span>
              </span>
            </div>

            {/* Floating Top Nav Pill (Translucent See-Through Glassmorphism) */}
            <nav className="bg-white/75 backdrop-blur-xl rounded-full px-6 py-2.5 shadow-2xl border border-white/70 flex items-center gap-5 sm:gap-7 text-xs sm:text-sm font-bold text-slate-800">
              <Link href="/about" className="relative text-[#002454] font-extrabold flex flex-col items-center">
                <span>{lang === 'fr' ? 'À propos' : 'About'}</span>
                <span className="h-1.5 w-1.5 rounded-full bg-[#CE1126] mt-0.5" />
              </Link>
              <Link href="/membership" className="hover:text-[#0055A5] transition-colors">
                {lang === 'fr' ? 'Membres' : 'Members'}
              </Link>
              <Link href="/services/trade-facilitation" className="hover:text-[#0055A5] transition-colors">
                Services
              </Link>
              <Link href="/membership" className="hover:text-[#0055A5] transition-colors">
                {lang === 'fr' ? 'Investir' : 'Invest'}
              </Link>
              <Link href="/events" className="hover:text-[#0055A5] transition-colors">
                {lang === 'fr' ? 'Actualités' : 'News'}
              </Link>
            </nav>
          </div>

          {/* Main Grid Content (Headline on Left, Cards Flush Far Right) */}
          <div className="relative z-30 grid lg:grid-cols-12 gap-6 items-center my-auto pt-8 pb-10">
            
            {/* LEFT COLUMN: Bold Headline & Subtext */}
            <div className="lg:col-span-6 xl:col-span-5 space-y-6 max-w-xl">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white font-display leading-[1.06] tracking-tight drop-shadow-md">
                {lang === 'fr' ? (
                  <>
                    Bâtissons l'économie <br />
                    <span className="text-[#FFE500]">de demain.</span>
                  </>
                ) : (
                  <>
                    Building a Stronger <br />
                    <span className="text-[#FFE500]">Business Future</span> <br />
                    for the DRC
                  </>
                )}
              </h1>

              <p className="text-sm sm:text-base text-sky-100/95 font-normal leading-relaxed max-w-lg drop-shadow-sm">
                {lang === 'fr'
                  ? "Entreprises. Investissement stratégique. Croissance pérenne. La passerelle souveraine entre les secteurs minéraux, l'énergie et le potentiel industriel de la République Démocratique du Congo."
                  : "Connect with investors, access strategic market intelligence, and accelerate enterprise growth through the DRC's trusted national business network."}
              </p>

              <div className="pt-2 flex flex-wrap items-center gap-4">
                <Link
                  href="/membership"
                  className="font-display inline-flex items-center gap-3 rounded-full bg-[#F7D618] hover:bg-[#FFD750] px-7 py-3.5 text-xs sm:text-sm font-black text-slate-950 transition-all shadow-xl hover:scale-105 active:scale-95 group"
                >
                  <span>{lang === 'fr' ? 'Approuver l\'Adhésion →' : 'Become a Member →'}</span>
                </Link>

                <Link
                  href="/register"
                  className="font-display inline-flex items-center gap-2 rounded-full bg-white/15 hover:bg-white/25 border border-white/30 backdrop-blur-md px-6 py-3.5 text-xs sm:text-sm font-bold text-white transition-all"
                >
                  <ShieldCheck className="h-4 w-4 text-amber-400" />
                  <span>{lang === 'fr' ? 'Guichet Inscription CDCC' : 'CDCC Registration'}</span>
                </Link>
              </div>

              {/* Stat Counters inside Hero Left */}
              <div className="pt-4 border-t border-white/15 flex items-center gap-8">
                <div>
                  <div className="text-2xl font-black text-white font-display">5,000+</div>
                  <div className="text-[11px] text-sky-200/80 font-medium">Entreprises Membres Accréditées</div>
                </div>
                <div className="border-l border-white/20 pl-8">
                  <div className="text-2xl font-black text-amber-400 font-display">26 Secteurs</div>
                  <div className="text-[11px] text-sky-200/80 font-medium">Mines, Énergie, Agri, Tech</div>
                </div>
              </div>

            </div>

            {/* RIGHT COLUMN: 2 Translucent See-Through Floating Glass Cards */}
            <div className="lg:col-span-6 lg:col-start-7 xl:col-span-4 xl:col-start-9 flex flex-col items-end space-y-5 w-full ml-auto">
              
              {/* TOP CARD: Good Morning Entrepreneur */}
              <div className="bg-white/75 backdrop-blur-xl rounded-3xl p-6 sm:p-7 shadow-2xl border border-white/70 text-slate-900 w-full max-w-[370px] relative overflow-hidden flex flex-col justify-between min-h-[210px] transition-transform hover:scale-[1.01] group">
                
                <div className="space-y-3">
                  {/* Pill Tag */}
                  <div className="inline-flex items-center gap-1.5 rounded-full bg-white/80 px-3.5 py-1 text-[11px] font-bold text-slate-700 border border-slate-200/80 shadow-xs">
                    <span className="h-2 w-2 rounded-full bg-[#CE1126] animate-pulse" />
                    <span>Session</span>
                  </div>

                  {/* Heading */}
                  <h3 className="text-2xl sm:text-3xl font-black text-[#002454] font-display leading-tight">
                    {lang === 'fr' ? (
                      <>Bonjour, <br /><span className="text-[#0055A5]">Entrepreneur.</span></>
                    ) : (
                      <>Good morning, <br /><span className="text-[#0055A5]">Entrepreneur.</span></>
                    )}
                  </h3>

                  {/* Subtext */}
                  <p className="text-xs sm:text-sm text-slate-600 font-medium">
                    {lang === 'fr'
                      ? "Votre prochain contrat commence ici. Prêt à développer vos affaires ?"
                      : "Your next contract starts here. Ready to grow?"}
                  </p>
                </div>

                {/* Footer Action Row */}
                <div className="flex items-center justify-between pt-4 border-t border-slate-200/70 mt-4">
                  <span className="text-[11px] font-extrabold text-[#0055A5] uppercase tracking-wider font-display">
                    CDCC CONSULAR PORTAL
                  </span>
                  <Link
                    href="/register"
                    className="flex h-11 w-11 items-center justify-center rounded-full bg-[#0055A5] text-white shadow-lg hover:bg-[#003E80] hover:scale-110 transition-all"
                    title="Access Consular Portal"
                  >
                    <ArrowRight className="h-5 w-5 icon-animate" />
                  </Link>
                </div>
              </div>

              {/* BOTTOM CARD: Marie Kabongo Testimonial */}
              <div className="bg-white/75 backdrop-blur-xl rounded-3xl p-6 sm:p-7 shadow-2xl border border-white/70 text-slate-900 w-full max-w-[370px] space-y-4 transition-transform hover:scale-[1.01] group">
                
                {/* User Header */}
                <div className="flex items-center gap-3.5">
                  <img
                    src={currentTestimonial.avatar}
                    alt={currentTestimonial.name}
                    className="h-12 w-12 rounded-full object-cover border-2 border-[#0055A5] shadow-sm"
                  />
                  <div>
                    <h4 className="text-sm font-extrabold text-[#002454] font-display">
                      {currentTestimonial.name}
                    </h4>
                    <p className="text-[11px] font-semibold text-slate-500">
                      {lang === 'fr' ? currentTestimonial.titleFr : currentTestimonial.titleEn}
                    </p>
                  </div>
                </div>

                {/* Quote Content */}
                <div className="space-y-2">
                  <div className="text-[#0055A5] opacity-40 text-3xl font-serif leading-none select-none">99</div>
                  <p className="text-xs sm:text-sm font-semibold text-slate-700 italic leading-relaxed">
                    "{lang === 'fr' ? currentTestimonial.quoteFr : currentTestimonial.quoteEn}"
                  </p>
                  <p className="text-[10px] font-extrabold text-amber-600 uppercase tracking-wider pt-1">
                    {lang === 'fr' ? currentTestimonial.trustFr : currentTestimonial.trustEn}
                  </p>
                </div>

                {/* Carousel Navigation & Trust Link */}
                <div className="flex items-center justify-between border-t border-slate-200/70 pt-3">
                  <div className="flex items-center gap-1.5">
                    {testimonials.map((_, idx) => (
                      <button
                        key={idx}
                        onClick={() => setActiveTestimonial(idx)}
                        className={`h-2 rounded-full transition-all ${
                          activeTestimonial === idx ? 'w-6 bg-[#0055A5]' : 'w-2 bg-slate-300'
                        }`}
                        aria-label={`Testimonial slide ${idx + 1}`}
                      />
                    ))}
                  </div>

                  <Link href="/about" className="text-[11px] font-bold text-[#0055A5] hover:underline flex items-center gap-1">
                    <span>Trust Charter</span>
                    <ChevronRight className="h-3.5 w-3.5 icon-animate" />
                  </Link>
                </div>

              </div>

            </div>

          </div>

        </div>
      </section>

      {/* 2. TICKER BAR — SOVEREIGN TRUST BADGES */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-[1400px] mx-auto">
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-sm flex flex-wrap items-center justify-around gap-4 text-xs font-bold text-slate-600">
          <div className="flex items-center gap-2">
            <Landmark className="h-4 w-4 text-[#007DC5] icon-animate" />
            <span>Organe Officiel d'État RDC · 1960</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 text-amber-500 icon-animate" />
            <span>26 Provinces Couvertes</span>
          </div>
          <div className="flex items-center gap-2">
            <Scale className="h-4 w-4 text-emerald-600 icon-animate" />
            <span>Conformité Juridique OHADA</span>
          </div>
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4 text-purple-600 icon-animate" />
            <span>5 000+ Entreprises Membres</span>
          </div>
          <div className="flex items-center gap-2">
            <Globe2 className="h-4 w-4 text-[#007DC5] icon-animate" />
            <span>Kinshasa & Pretoria Desks</span>
          </div>
        </div>
      </section>


      {/* 3. SECTION 1 — SERVICES STRATÉGIQUES & GUICHET BILATÉRAL */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-[1400px] mx-auto space-y-6">
        
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-200 pb-4">
          <div>
            <span className="text-[11px] font-extrabold text-[#007DC5] uppercase tracking-widest block font-display">
              ● ARCHITECTURE & ACCÈS CONSEILS
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#07162C] font-display">
              Services Stratégiques & Guichet Bilatéral
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 max-w-2xl mt-1">
              Des solutions souveraines et sur-mesure pour sécuriser l'implantation, la conformité légale et la rentabilité de vos investissements.
            </p>
          </div>

          <Link
            href="/services/trade-facilitation"
            className="text-xs font-bold text-[#007DC5] hover:underline flex items-center gap-1 shrink-0"
          >
            <span>Télécharger la Charte des Services</span>
            <ArrowRight className="h-4 w-4 icon-animate" />
          </Link>
        </div>

        {/* 4 Feature Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          
          {/* Service 1 */}
          <div className="executive-card rounded-2xl p-6 bg-white border-slate-200 space-y-4 group flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-sky-100 text-[#007DC5]">
                  <FileCheck className="h-5 w-5 icon-animate" />
                </div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">GUICHET UNIQUE</span>
              </div>
              <h3 className="text-base font-extrabold text-[#07162C] font-display group-hover:text-[#007DC5] transition-colors">
                Facilitation Douanière & Flux
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Certification sous-traitance, accréditation légale, exonération douanière et sécurisation des processus de fret vers la RDC.
              </p>
            </div>
            <Link
              href="/services/trade-facilitation"
              className="text-xs font-bold text-[#007DC5] flex items-center justify-between pt-3 border-t border-slate-100"
            >
              <span>Consulter le protocole</span>
              <ChevronRight className="h-4 w-4 icon-animate" />
            </Link>
          </div>

          {/* Service 2 */}
          <div className="executive-card rounded-2xl p-6 bg-white border-slate-200 space-y-4 group flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-100 text-amber-700">
                  <Scale className="h-5 w-5 icon-animate" />
                </div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">DROIT OHADA</span>
              </div>
              <h3 className="text-base font-extrabold text-[#07162C] font-display group-hover:text-amber-700 transition-colors">
                Tarification & Legal Certification
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Audit juridique de vos contrats sous le droit OHADA, vérification de légalité des partenariats et accès aux tarifs préférentiels membre.
              </p>
            </div>
            <Link
              href="/services/legal-certification"
              className="text-xs font-bold text-amber-700 flex items-center justify-between pt-3 border-t border-slate-100"
            >
              <span>Vérifier conformité</span>
              <ChevronRight className="h-4 w-4 icon-animate" />
            </Link>
          </div>

          {/* Service 3 */}
          <div className="executive-card rounded-2xl p-6 bg-white border-slate-200 space-y-4 group flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-purple-100 text-purple-700">
                  <Search className="h-5 w-5 icon-animate" />
                </div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">MARKET INTEL</span>
              </div>
              <h3 className="text-base font-extrabold text-[#07162C] font-display group-hover:text-purple-700 transition-colors">
                Veille Économique & Offres
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Rapports exclusifs, appels d'offres publics et privés, cartographie des acteurs clés et opportunités d'affaires dans les 26 provinces.
              </p>
            </div>
            <Link
              href="/services/market-intelligence"
              className="text-xs font-bold text-purple-700 flex items-center justify-between pt-3 border-t border-slate-100"
            >
              <span>Accéder aux rapports</span>
              <ChevronRight className="h-4 w-4 icon-animate" />
            </Link>
          </div>

          {/* Service 4 */}
          <div className="executive-card rounded-2xl p-6 bg-white border-slate-200 space-y-4 group flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                  <ShieldCheck className="h-5 w-5 icon-animate" />
                </div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">PLAIDOYER ETAT</span>
              </div>
              <h3 className="text-base font-extrabold text-[#07162C] font-display group-hover:text-emerald-700 transition-colors">
                Plaidoyer de Haut Niveau
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Représentation directe auprès des ministères et institutions, médiation d'affaires et défense des intérêts des entreprises membres.
              </p>
            </div>
            <Link
              href="/services/high-level-advocacy"
              className="text-xs font-bold text-emerald-700 flex items-center justify-between pt-3 border-t border-slate-100"
            >
              <span>Conseil souverain</span>
              <ChevronRight className="h-4 w-4 icon-animate" />
            </Link>
          </div>

        </div>
      </section>


      {/* 4. SECTION 2 — FILIÈRES D'AVENIR & GISEMENTS DE VALEUR */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-[1400px] mx-auto space-y-6">
        
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-200 pb-4">
          <div>
            <span className="text-[11px] font-extrabold text-amber-600 uppercase tracking-widest block font-display">
              ● SECTEURS · RDC · 2026
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#07162C] font-display">
              Filières d'Avenir & Gisements de Valeur
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 max-w-2xl mt-1">
              La RDC offre d'immenses opportunités de croissance durable dans des secteurs clés grâce à ses ressources et son marché national de 100 millions d'habitants.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs font-bold text-slate-600">5 Secteurs Prioritaires</span>
          </div>
        </div>

        {/* Sectors Layout Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          
          {/* Sector 1: Large Featured Card (Mines & Batteries) */}
          <div className="lg:col-span-8 rounded-3xl overflow-hidden shadow-xl bg-gradient-to-r from-[#002454] to-[#003E80] text-white p-7 sm:p-10 relative flex flex-col justify-between min-h-[340px] group border border-blue-400/20">
            {/* Background Texture Graphic */}
            <div className="absolute inset-0 bg-cover bg-center opacity-30 mix-blend-overlay group-hover:scale-105 transition-transform duration-700" style={{ backgroundImage: "url('/storage/events-gallery/7eFFWH6DdJSmT8zPqP9iZXz8IU7gaWt6ElJbkO2I.jpg')" }} />
            <div className="absolute inset-0 bg-gradient-to-t from-[#001438] via-transparent to-transparent opacity-90" />

            <div className="relative z-10 space-y-3">
              <div className="inline-flex items-center gap-2 rounded-full bg-amber-400/20 border border-amber-400/30 px-3.5 py-1 text-[11px] font-bold text-amber-300">
                <Pickaxe className="h-3.5 w-3.5 icon-animate" />
                <span>N°1 Mondial Cobalt & Tantalite</span>
              </div>

              <h3 className="text-2xl sm:text-4xl font-black font-display text-white leading-tight">
                Mines Stratégiques & Chaîne de Valeur des Batteries
              </h3>

              <p className="text-xs sm:text-sm text-sky-100 max-w-xl leading-relaxed">
                Au-delà de l'extraction brute, la CDCC accompagne l'industrialisation du raffinage local et la valorisation des minerais de batterie en RDC.
              </p>
            </div>

            <div className="relative z-10 pt-6 flex flex-wrap items-center justify-between gap-4 border-t border-white/20">
              <div className="flex items-center gap-3 text-xs font-bold text-sky-200">
                <span>Cobalt</span> · <span>Lithium</span> · <span>Cuivre</span> · <span>Tantalite</span>
              </div>
              <Link
                href="/membership"
                className="inline-flex items-center gap-2 rounded-full bg-white text-[#002454] px-5 py-2 text-xs font-black hover:bg-slate-100 transition-all shadow-md"
              >
                <span>Accéder à la filière</span>
                <ArrowRight className="h-3.5 w-3.5 icon-animate" />
              </Link>
            </div>
          </div>

          {/* Sector 2: Hydro-électricité */}
          <div className="lg:col-span-4 rounded-3xl overflow-hidden shadow-xl bg-[#07162C] text-white p-7 relative flex flex-col justify-between min-h-[340px] group border border-slate-700">
            <div className="absolute inset-0 bg-cover bg-center opacity-30 group-hover:scale-105 transition-transform duration-700" style={{ backgroundImage: "url('/storage/events-gallery/artsolar-meeting.png')" }} />
            <div className="absolute inset-0 bg-gradient-to-t from-[#07162C] via-[#07162C]/70 to-transparent" />

            <div className="relative z-10 space-y-3">
              <div className="inline-flex items-center gap-2 rounded-full bg-sky-400/20 border border-sky-400/30 px-3 py-1 text-[10px] font-bold text-sky-300">
                <Zap className="h-3.5 w-3.5 icon-animate" />
                <span>100 000 MW Potentiel</span>
              </div>

              <h3 className="text-xl sm:text-2xl font-black font-display text-white">
                Hydro-électricité & Énergie Propre
              </h3>

              <p className="text-xs text-slate-300 leading-relaxed">
                Grand Inga, mini-réseaux et centrales solaires pour l'approvisionnement des zones minières et urbaines.
              </p>
            </div>

            <div className="relative z-10 pt-4">
              <Link
                href="/membership"
                className="text-xs font-bold text-sky-400 hover:underline flex items-center justify-between"
              >
                <span>Projets Énergie Inga</span>
                <ChevronRight className="h-4 w-4 icon-animate" />
              </Link>
            </div>
          </div>

          {/* Sector 3: Agro-Industrie */}
          <div className="lg:col-span-4 rounded-3xl p-6 bg-white border border-slate-200 shadow-md space-y-4 group flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                <Sprout className="h-5 w-5 icon-animate" />
              </div>
              <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider block">80M HECTARES ARABLES</span>
              <h3 className="text-lg font-extrabold text-[#07162C] font-display group-hover:text-emerald-700 transition-colors">
                Agro-Industrie & Souveraineté
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Grands domaines agricoles, transformation agroalimentaire et chaînes du froid interprovinciales.
              </p>
            </div>
            <Link href="/membership" className="text-xs font-bold text-emerald-700 flex items-center justify-between pt-3 border-t border-slate-100">
              <span>Filière Agricole</span>
              <ChevronRight className="h-4 w-4 icon-animate" />
            </Link>
          </div>

          {/* Sector 4: Infrastructures */}
          <div className="lg:col-span-4 rounded-3xl p-6 bg-white border border-slate-200 shadow-md space-y-4 group flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-100 text-[#007DC5]">
                <Building className="h-5 w-5 icon-animate" />
              </div>
              <span className="text-[10px] font-bold text-[#007DC5] uppercase tracking-wider block">CORRIDORS DE TRANSPORT</span>
              <h3 className="text-lg font-extrabold text-[#07162C] font-display group-hover:text-[#007DC5] transition-colors">
                Infrastructures & Corridors
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Construire les routes, rails et ports connectant la RDC au marché régional africain.
              </p>
            </div>
            <Link href="/membership" className="text-xs font-bold text-[#007DC5] flex items-center justify-between pt-3 border-t border-slate-100">
              <span>Grands Travaux</span>
              <ChevronRight className="h-4 w-4 icon-animate" />
            </Link>
          </div>

          {/* Sector 5: Numérique */}
          <div className="lg:col-span-4 rounded-3xl p-6 bg-white border border-slate-200 shadow-md space-y-4 group flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-purple-100 text-purple-700">
                <Cpu className="h-5 w-5 icon-animate" />
              </div>
              <span className="text-[10px] font-bold text-purple-700 uppercase tracking-wider block">FINTECH & DATA</span>
              <h3 className="text-lg font-extrabold text-[#07162C] font-display group-hover:text-purple-700 transition-colors">
                Réseaux & Croissance Numérique
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Infrastructures fibre optique, datacenters nationaux et numérisation des services commerciaux.
              </p>
            </div>
            <Link href="/membership" className="text-xs font-bold text-purple-700 flex items-center justify-between pt-3 border-t border-slate-100">
              <span>Hub Digital</span>
              <ChevronRight className="h-4 w-4 icon-animate" />
            </Link>
          </div>

        </div>
      </section>


      {/* 5. SECTION 3 — 10 RAISONS MAJEURES DE REJOINDRE LA CDCC */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-[1400px] mx-auto space-y-6">
        <div className="text-center space-y-2 max-w-2xl mx-auto">
          <span className="text-[11px] font-extrabold text-[#007DC5] uppercase tracking-widest block font-display">
            ● OFFICIEL · 10 PILIERS
          </span>
          <h2 className="text-3xl font-black text-[#07162C] font-display">
            10 Raisons Majeures de Rejoindre la CDCC
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            Une plateforme d'élite conçue pour dynamiser et accompagner les entreprises ambitieuses au cœur des affaires congolaises.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {[
            { num: '01', title: 'Accès aux Marchés', desc: 'Mise en relation B2B directe et accès privilégié aux donneurs d\'ordre nationaux.', icon: Users },
            { num: '02', title: 'Intelligence Stratégique', desc: 'Analyses prospectives, cartographie des risques et rapports d\'opportunités.', icon: Search },
            { num: '03', title: 'Plaidoyer Public', desc: 'Défense active de vos intérêts auprès des instances gouvernementales.', icon: Landmark },
            { num: '04', title: 'Réseau de Partenaires', desc: 'Intégration aux délégations économiques lors des sommets diplomatiques.', icon: Globe2 },
            { num: '05', title: 'Visibilité Accrue', desc: 'Référencement prioritaire dans l\'Annuaire Officiel des Entreprises Agrées.', icon: ShieldCheck },
            { num: '06', title: 'Formations & Ateliers', desc: 'Programmes exclusifs de mise à niveau aux normes juridiques OHADA.', icon: BookOpen },
            { num: '07', title: 'Protection Juridique', desc: 'Accompagnement en droit des affaires, médiation et arbitrage commercial.', icon: Scale },
            { num: '08', title: 'Services Financiers', desc: 'Mise en relation avec les banques multilatérales et fonds souverains.', icon: TrendingUp },
            { num: '09', title: 'Label Éthique CDCC', desc: 'Certification d\'intégrité renforçant la crédibilité de votre entreprise.', icon: Award },
            { num: '10', title: 'Force du Réseau', desc: 'Synergie d\'action et partage d\'expérience avec plus de 5 000 membres.', icon: Zap },
          ].map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="executive-card rounded-2xl p-5 bg-white border-slate-200 space-y-3 group hover:border-[#007DC5]/50 flex flex-col justify-between"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-[#007DC5]">
                    <span className="font-display text-sm font-black text-[#007DC5]">{item.num}</span>
                    <Icon className="h-4 w-4 icon-animate" />
                  </div>
                  <h3 className="text-xs sm:text-sm font-extrabold text-[#07162C] font-display group-hover:text-[#007DC5] transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </section>


      {/* 6. SECTION 4 — UN SIÈGE STRATÉGIQUE À PRETORIA, DES ANTENNES GLOBALES */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-[1400px] mx-auto">
        <div className="executive-card rounded-3xl p-6 sm:p-10 bg-white border-slate-200 space-y-6 shadow-xl relative overflow-hidden">
          <div className="flag-stripe h-[3px]" aria-hidden="true" />

          <div className="grid lg:grid-cols-12 gap-8 items-center">
            
            {/* Left Content Column */}
            <div className="lg:col-span-6 space-y-6">
              <div>
                <span className="text-[11px] font-extrabold text-[#007DC5] uppercase tracking-widest block font-display">
                  ● DIPLOMATIE · SADC · KINSHASA
                </span>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-[#07162C] font-display mt-1">
                  Un Siège Stratégique à Pretoria, des Antennes Globales
                </h2>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mt-2">
                  Implantée au cœur du quartier diplomatique sud-africain, la CDCC opère des liaisons permanentes entre Kinshasa et les grands centres financiers mondiaux.
                </p>
              </div>

              {/* Interactive Tabs */}
              <div className="space-y-3">
                <button
                  onClick={() => setActiveLocationTab('pretoria')}
                  className={`w-full text-left rounded-2xl p-4 transition-all flex items-start gap-3 border ${
                    activeLocationTab === 'pretoria'
                      ? 'bg-sky-50/80 border-[#007DC5] shadow-sm'
                      : 'bg-white border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#007DC5] text-white shrink-0 mt-0.5">
                    <Building2 className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-[#07162C] font-display">
                      Transvaal (Pretoria) · Siège Diplômatique
                    </h4>
                    <p className="text-[11px] text-slate-600 mt-0.5">
                      1025 Park St, Hatfield, Pretoria. Bureau de liaison bilatéral SADC & diplomatie industrielle.
                    </p>
                  </div>
                </button>

                <button
                  onClick={() => setActiveLocationTab('kinshasa')}
                  className={`w-full text-left rounded-2xl p-4 transition-all flex items-start gap-3 border ${
                    activeLocationTab === 'kinshasa'
                      ? 'bg-amber-50/80 border-amber-500 shadow-sm'
                      : 'bg-white border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-500 text-slate-950 shrink-0 mt-0.5">
                    <Landmark className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-[#07162C] font-display">
                      Kinshasa Business Hub · Antenne Centrale Gombe
                    </h4>
                    <p className="text-[11px] text-slate-600 mt-0.5">
                      Avenue du Marché, Gombe. Secrétariat exécutif, légalisation et guichet unique ministériel.
                    </p>
                  </div>
                </button>

                <button
                  onClick={() => setActiveLocationTab('desks')}
                  className={`w-full text-left rounded-2xl p-4 transition-all flex items-start gap-3 border ${
                    activeLocationTab === 'desks'
                      ? 'bg-purple-50/80 border-purple-600 shadow-sm'
                      : 'bg-white border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-purple-600 text-white shrink-0 mt-0.5">
                    <Globe2 className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-[#07162C] font-display">
                      Desks Internationaux · Londres, Bruxelles, Dubai & Beijing
                    </h4>
                    <p className="text-[11px] text-slate-600 mt-0.5">
                      Point de contact permanent pour les investisseurs institutionnels et les fonds de la diaspora.
                    </p>
                  </div>
                </button>
              </div>
            </div>

            {/* Right Map Preview Graphic */}
            <div className="lg:col-span-6 rounded-3xl overflow-hidden border border-slate-200 shadow-lg relative min-h-[340px] bg-slate-900 flex flex-col justify-end p-6">
              <img
                src="/storage/events-gallery/drc-uk-meeting.png"
                alt="CDCC Pretoria Map & Hub"
                className="absolute inset-0 h-full w-full object-cover opacity-60"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#07162C] via-[#07162C]/40 to-transparent" />

              <div className="relative z-10 space-y-2 bg-[#07162C]/90 backdrop-blur-md rounded-2xl p-4 border border-white/10">
                <div className="flex items-center justify-between text-xs font-bold text-amber-400">
                  <span className="flex items-center gap-1.5">
                    <MapPin className="h-3.5 w-3.5 text-amber-400" />
                    <span>Location Active · Pretoria</span>
                  </span>
                  <span className="text-[10px] text-sky-200">ACCÈS SÉCURISÉ</span>
                </div>
                <p className="text-xs text-white font-semibold">
                  1025 Park St, Hatfield, Pretoria, 0083, Afrique du Sud
                </p>
                <div className="pt-2 flex items-center justify-between text-[11px]">
                  <span className="text-slate-300">Tél: +27 12 342 1234</span>
                  <Link href="/contact" className="text-amber-400 hover:underline font-bold flex items-center gap-1">
                    <span>Prendre Rendez-vous</span>
                    <ArrowRight className="h-3 w-3" />
                  </Link>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>


      {/* 7. SECTION 5 — EXECUTIVE QUOTE BANNER (ALBERT MUBAKE) */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-[1400px] mx-auto">
        <div className="sovereign-card rounded-3xl p-8 sm:p-14 lg:p-16 relative overflow-hidden border border-[#FED701]/40 shadow-2xl bg-[#05005B]">
          
          <div className="grid lg:grid-cols-12 gap-10 lg:gap-12 items-center relative z-10">
            
            {/* President Portrait Box (Much Bigger Image & Frame) */}
            <div className="lg:col-span-5 flex flex-col items-center sm:items-start text-center sm:text-left space-y-4">
              <div className="relative group w-full max-w-[320px] sm:max-w-[360px]">
                <img
                  src="/images/albert-mubake.jpg"
                  alt="Albert Mubake — Président du Conseil Exécutif · CDCC"
                  className="w-full aspect-[4/5] rounded-3xl object-cover border-2 border-[#FED701] shadow-2xl transition-transform duration-300 group-hover:scale-[1.02]"
                />
                <div className="absolute -bottom-3 -right-3 bg-gradient-to-r from-[#FED701] via-[#FEC203] to-[#FCB305] text-[#05005B] px-4 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2 border border-white/30">
                  <ShieldCheck className="h-6 w-6 text-[#05005B]" />
                  <span className="text-xs font-black uppercase tracking-wider">OFFICIEL</span>
                </div>
              </div>

              <div className="space-y-1 pt-2">
                <h3 className="text-2xl sm:text-3xl font-black text-white font-display">Albert Mubake</h3>
                <p className="text-xs sm:text-sm font-black text-[#FED701] uppercase tracking-wider font-display">
                  {lang === 'fr' ? 'Président du Conseil Exécutif · CDCC' : 'President of the Executive Council · CDCC'}
                </p>
              </div>
            </div>

            {/* Quote Message (Much Bigger Box & Text) */}
            <div className="lg:col-span-7 space-y-6">
              <div className="flex items-center gap-3">
                <Quote className="h-10 w-10 text-[#FED701] opacity-80" />
                <span className="text-xs font-black text-[#FED701] uppercase tracking-widest font-display">
                  {lang === 'fr' ? '● MESSAGE DU PRÉSIDENT' : '● PRESIDENTIAL ADDRESS'}
                </span>
              </div>

              <blockquote className="text-xl sm:text-2xl lg:text-3xl font-black text-white leading-snug font-display tracking-tight">
                {lang === 'fr'
                  ? "« Nous ne nous contentons pas de promouvoir les échanges commerciaux : nous bâtissons les fondations d'une souveraineté économique partagée entre l'Afrique du Sud, la RDC et nos partenaires internationaux. »"
                  : "“We do not merely promote commercial exchange: we are building the foundations of a shared economic sovereignty between South Africa, the DRC, and our international partners.”"}
              </blockquote>

              <p className="text-xs sm:text-sm text-sky-100/90 leading-relaxed font-normal">
                {lang === 'fr'
                  ? "La République Démocratique du Congo n'est pas un simple réservoir passif de matières premières. Pour élever le potentiel de la circularité interafricaine, la CDCC opère comme un pont souverain entre votre capital, les entreprises du terrain, et les opportunités d'investissement à forte valeur ajoutée."
                  : "The Democratic Republic of the Congo is not a mere passive reservoir of raw materials. To elevate the potential of pan-African economic circularity, the CDCC operates as a sovereign bridge connecting your capital to local ground enterprises."}
              </p>

              <div className="pt-3 border-t border-white/15 flex flex-wrap items-center gap-4 text-xs font-extrabold text-[#FED701]">
                <span className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-[#FED701] animate-pulse" />
                  {lang === 'fr' ? 'Engagement & Dialogue 2026' : 'Engagement & Dialogue 2026'}
                </span>
                <span>·</span>
                <span>{lang === 'fr' ? 'Secteur Privé · RDC' : 'Private Sector · DRC'}</span>
              </div>
            </div>

          </div>
        </div>
      </section>


      {/* 8. SECTION 6 — MISSIONS COMMERCIALES & FORUMS 2026 */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-[1400px] mx-auto space-y-6">
        
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-200 pb-4">
          <div>
            <span className="text-[11px] font-extrabold text-[#007DC5] uppercase tracking-widest block font-display">
              ● DÉLÉGATIONS & DIALOGUES
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#07162C] font-display">
              Missions Commerciales & Forums 2026
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Participez aux délégations et rencontres B2B officielles encadrées par la CDCC auprès des ministères et décideurs industriels.
            </p>
          </div>

          <Link
            href="/events"
            className="rounded-xl bg-[#07162C] hover:bg-[#0C2344] px-5 py-2.5 text-xs font-bold text-white transition-all shadow-md flex items-center gap-2 shrink-0"
          >
            <span>Demander Accréditation Délégation</span>
            <ArrowRight className="h-4 w-4 icon-animate" />
          </Link>
        </div>

        {/* Event Cards Grid */}
        <div className="grid gap-6 md:grid-cols-3">
          
          {/* Forum 1 */}
          <div className="executive-card rounded-2xl overflow-hidden flex flex-col justify-between group bg-white">
            <div className="relative aspect-[16/10] overflow-hidden bg-slate-100">
              <img
                src="/storage/events-gallery/drc-uk-meeting.png"
                alt="Sommet Minier-Énergie"
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute top-3 left-3 bg-[#07162C]/90 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-bold text-amber-400 uppercase">
                BILATÉRAL
              </div>
              <div className="absolute bottom-3 right-3 bg-white/95 backdrop-blur-md px-2.5 py-1 rounded-lg text-[10px] font-bold text-[#07162C] shadow-sm">
                12-14 JUIN 2026
              </div>
            </div>

            <div className="p-5 space-y-3 flex-1 flex flex-col justify-between">
              <div className="space-y-2">
                <span className="text-[10px] font-bold text-[#007DC5] uppercase tracking-wider block">JOHANNESBURG</span>
                <h3 className="text-base font-bold text-[#07162C] group-hover:text-[#007DC5] transition-colors leading-snug">
                  Sommet Minier-Énergie RDC-IPFA
                </h3>
                <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                  Table ronde de haut niveau entre les majors minières et les investisseurs énergétiques de la région SADC.
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] font-semibold text-slate-500">Sky Hotel Sandton</span>
                <Link href="/events" className="text-xs font-bold text-[#007DC5] flex items-center gap-1">
                  <span>S'inscrire</span>
                  <ChevronRight className="h-3.5 w-3.5 icon-animate" />
                </Link>
              </div>
            </div>
          </div>

          {/* Forum 2 */}
          <div className="executive-card rounded-2xl overflow-hidden flex flex-col justify-between group bg-white">
            <div className="relative aspect-[16/10] overflow-hidden bg-slate-100">
              <img
                src="/storage/events-gallery/NJ4gwHinL7OG6yrNFR62Fc3I7Hn08sTGpQsKCk5d.jpg"
                alt="Forum Agro-Industrie"
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute top-3 left-3 bg-[#07162C]/90 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-bold text-amber-400 uppercase">
                AGRI & LOGISTIQUE
              </div>
              <div className="absolute bottom-3 right-3 bg-white/95 backdrop-blur-md px-2.5 py-1 rounded-lg text-[10px] font-bold text-[#07162C] shadow-sm">
                25-27 SEPT 2026
              </div>
            </div>

            <div className="p-5 space-y-3 flex-1 flex flex-col justify-between">
              <div className="space-y-2">
                <span className="text-[10px] font-bold text-[#007DC5] uppercase tracking-wider block">KINSHASA</span>
                <h3 className="text-base font-bold text-[#07162C] group-hover:text-[#007DC5] transition-colors leading-snug">
                  Forum Agro-Industrie & Logistique
                </h3>
                <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                  Développement des corridors agricoles et chaînes de transformation locale dans les provinces de l'Ouest.
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] font-semibold text-slate-500">Fleuve Congo Hotel</span>
                <Link href="/events" className="text-xs font-bold text-[#007DC5] flex items-center gap-1">
                  <span>S'inscrire</span>
                  <ChevronRight className="h-3.5 w-3.5 icon-animate" />
                </Link>
              </div>
            </div>
          </div>

          {/* Forum 3 */}
          <div className="executive-card rounded-2xl overflow-hidden flex flex-col justify-between group bg-white">
            <div className="relative aspect-[16/10] overflow-hidden bg-slate-100">
              <img
                src="/storage/events-gallery/artsolar-meeting.png"
                alt="Forum Énergie Propre"
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute top-3 left-3 bg-[#07162C]/90 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-bold text-amber-400 uppercase">
                CLEAN ENERGY
              </div>
              <div className="absolute bottom-3 right-3 bg-white/95 backdrop-blur-md px-2.5 py-1 rounded-lg text-[10px] font-bold text-[#07162C] shadow-sm">
                10-12 NOV 2026
              </div>
            </div>

            <div className="p-5 space-y-3 flex-1 flex flex-col justify-between">
              <div className="space-y-2">
                <span className="text-[10px] font-bold text-[#007DC5] uppercase tracking-wider block">LUBUMBASHI</span>
                <h3 className="text-base font-bold text-[#07162C] group-hover:text-[#007DC5] transition-colors leading-snug">
                  Forum Énergie Propre & Grand Inga
                </h3>
                <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                  Financement des infrastructures solaires et hydroélectriques pour la transition minière verte.
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] font-semibold text-slate-500">Pullman Karavia</span>
                <Link href="/events" className="text-xs font-bold text-[#007DC5] flex items-center gap-1">
                  <span>S'inscrire</span>
                  <ChevronRight className="h-3.5 w-3.5 icon-animate" />
                </Link>
              </div>
            </div>
          </div>

        </div>
      </section>


      {/* 9. SECTION 7 — FORMULAIRE D'ADHÉSION / CONTACT RAPIDE */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-[1400px] mx-auto">
        <div className="sovereign-card rounded-3xl p-8 sm:p-12 relative overflow-hidden border border-[#F7D618]/30 shadow-2xl">
          <div className="flag-stripe h-[3px]" aria-hidden="true" />

          <div className="max-w-3xl mx-auto text-center space-y-6">
            <div className="inline-flex items-center gap-2 rounded-full border border-amber-400/40 bg-amber-400/10 px-4 py-1.5 text-[11px] font-bold text-amber-400 uppercase tracking-wider">
              <ShieldCheck className="h-3.5 w-3.5" />
              <span>GUICHET UNIQUE D'ADHÉSION OFFICIELLE</span>
            </div>

            <h2 className="text-2xl sm:text-4xl font-extrabold text-white font-display leading-tight">
              Prêt à conquérir le marché congolais en toute sécurité juridique ?
            </h2>

            <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto font-light leading-relaxed">
              Rejoignez la CDCC dès aujourd'hui et accédez immédiatement aux appels d'offres prioritaires, au réseau diplomatique et à notre protection juridique.
            </p>

            {formSubmitted ? (
              <div className="rounded-2xl bg-emerald-500/20 border border-emerald-400/40 p-6 text-emerald-300 font-bold text-sm space-y-2">
                <CheckCircle2 className="h-8 w-8 mx-auto text-emerald-400" />
                <p>Votre demande d'adhésion a été transmise au Secrétariat Général CDCC.</p>
                <p className="text-xs text-slate-300 font-normal">Un conseiller consulaire vous contactera sous 24 heures ouvrées.</p>
              </div>
            ) : (
              <form onSubmit={handleQuickRegister} className="grid sm:grid-cols-2 gap-4 text-left pt-2">
                <div>
                  <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block mb-1">
                    Nom Complet ou Raison Sociale
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="ex: Congo Energy Solutions SARL"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full rounded-xl border border-slate-700 bg-slate-900/90 px-4 py-3 text-xs text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block mb-1">
                    Adresse Email Professionnelle
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="contact@entreprise.cd"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full rounded-xl border border-slate-700 bg-slate-900/90 px-4 py-3 text-xs text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block mb-1">
                    Secteur d'Activité
                  </label>
                  <select
                    value={formData.sector}
                    onChange={(e) => setFormData({ ...formData, sector: e.target.value })}
                    className="w-full rounded-xl border border-slate-700 bg-slate-900/90 px-4 py-3 text-xs text-white focus:border-amber-400 focus:outline-none"
                  >
                    <option value="">Sélectionner un secteur</option>
                    <option value="mines">Mines & Énergie</option>
                    <option value="agri">Agro-Industrie</option>
                    <option value="infra">Infrastructures & BTP</option>
                    <option value="tech">Numérique & Fintech</option>
                    <option value="services">Services & Logistique</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block mb-1">
                    Province / Région d'Implantation
                  </label>
                  <input
                    type="text"
                    placeholder="ex: Haut-Katanga / Kinshasa"
                    value={formData.province}
                    onChange={(e) => setFormData({ ...formData, province: e.target.value })}
                    className="w-full rounded-xl border border-slate-700 bg-slate-900/90 px-4 py-3 text-xs text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none"
                  />
                </div>

                <div className="sm:col-span-2 pt-2">
                  <button
                    type="submit"
                    className="w-full rounded-xl bg-gradient-to-r from-[#F7D618] via-[#FFD750] to-[#F59E0B] py-3.5 text-xs font-black text-slate-950 shadow-xl hover:brightness-105 transition-all flex items-center justify-center gap-2"
                  >
                    <Send className="h-4 w-4 icon-animate" />
                    <span>Soumettre ma demande de souscription →</span>
                  </button>
                </div>
              </form>
            )}

            <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center justify-center gap-6 text-[11px] text-slate-400 font-medium">
              <span className="flex items-center gap-1.5"><ShieldCheck className="h-3.5 w-3.5 text-amber-400" /> Membre Certifié Droit OHADA</span>
              <span className="flex items-center gap-1.5"><CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" /> Prise en charge sous 24h</span>
              <span className="flex items-center gap-1.5"><Globe2 className="h-3.5 w-3.5 text-sky-400" /> Secrétariat Kinshasa & Pretoria</span>
            </div>
          </div>
        </div>
      </section>

      {/* Lightbox & Event Registration Modals */}
      {selectedGallery && (
        <LightboxModal
          isOpen={lightboxOpen}
          onClose={() => setLightboxOpen(false)}
          photos={selectedGallery.photos}
          title={selectedGallery.title}
          date={selectedGallery.date}
        />
      )}

      {selectedEvent && (
        <EventRegisterModal
          isOpen={registerModalOpen}
          onClose={() => setRegisterModalOpen(false)}
          event={selectedEvent}
        />
      )}

    </div>
  );
}
