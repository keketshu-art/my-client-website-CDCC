'use client';

import React from 'react';
import Link from 'next/link';
import { useParams, notFound } from 'next/navigation';
import { useLanguage } from '@/context/LanguageContext';
import {
  Globe2,
  FileCheck,
  Award,
  TrendingUp,
  ShieldCheck,
  CheckCircle,
  ArrowRight,
} from 'lucide-react';

const serviceDataMap: Record<string, {
  icon: any;
  titleKey: string;
  descKey: string;
  detailsEn: string[];
  detailsFr: string[];
}> = {
  'diaspora-registration': {
    icon: Globe2,
    titleKey: 'service1Title',
    descKey: 'service1Desc',
    detailsEn: [
      'Dedicated Diaspora Concierge assisting overseas Congolese entrepreneurs.',
      'Specialized investment tax exemptions under ANAPI & CDCC framework.',
      'Direct matchmaking with verified local provincial businesses and land rights.',
      'Official Chamber Verification Seal for diaspora-owned international companies.',
    ],
    detailsFr: [
      'Service Concierge Diaspora dédié aux entrepreneurs congolais de l\'étranger.',
      'Exonérations fiscales d\'investissement spécifiques ANAPI & CDCC.',
      'Mise en relation directe avec les entreprises et opportunités foncières locales.',
      'Sceau de vérification officiel de la Chambre pour les entreprises de la diaspora.',
    ],
  },
  'trade-facilitation': {
    icon: FileCheck,
    titleKey: 'service2Title',
    descKey: 'service2Desc',
    detailsEn: [
      'Accelerated customs clearance guidance across Kinshasa, Matadi, and Lubumbashi.',
      'AfCFTA / ZLECAF export certification & origin verification.',
      'Bilateral trade mission organization with SADC, European Union, and Asian partners.',
      'Cross-border logistical dispute resolution and legal arbitration assistance.',
    ],
    detailsFr: [
      'Assistance douanière accélérée à Kinshasa, Matadi et Lubumbashi.',
      'Certification d\'exportation et vérification d\'origine ZLECAF / AfCFTA.',
      'Organisation de missions économiques bilatérales (SADC, UE, Asie).',
      'Assistance au règlement des différends logistiques transfrontaliers.',
    ],
  },
  'business-certification': {
    icon: Award,
    titleKey: 'service3Title',
    descKey: 'service3Desc',
    detailsEn: [
      'Issuance of official Certificates of Origin for Congolese goods.',
      'Corporate creditworthiness & Chamber Good Standing Certification.',
      'Notarized Chamber Seal for international tender submissions.',
      'Verified supplier status in the official CDCC National Enterprise Registry.',
    ],
    detailsFr: [
      'Délivrance des Certificats d\'Origine officiels pour les marchandises de RDC.',
      'Attestation de bonne conduite et solvabilité de la Chambre.',
      'Sceau légalisé de la Chambre pour les appels d\'offres internationaux.',
      'Statut de fournisseur vérifié dans l\'Annuaire National CDCC.',
    ],
  },
  'market-intelligence': {
    icon: TrendingUp,
    titleKey: 'service4Title',
    descKey: 'service4Desc',
    detailsEn: [
      'Custom economic sector profiles across all 26 DRC provinces.',
      'Real-time commodity price tracking (Copper, Cobalt, Gold, Coffee, Timber).',
      'Regulatory compliance briefs and provincial tax structure guides.',
      'Bespoke competitor analysis and feasibility studies.',
    ],
    detailsFr: [
      'Profils économiques sectoriels sur mesure dans les 26 provinces de RDC.',
      'Suivi des cours des matières premières (Cuivre, Cobalt, Or, Café, Bois).',
      'Synthèses de conformité réglementaire et guides fiscaux provinciaux.',
      'Études de faisabilité et analyses de marché sur mesure.',
    ],
  },
  'policy-advocacy': {
    icon: ShieldCheck,
    titleKey: 'service5Title',
    descKey: 'service5Desc',
    detailsEn: [
      'Direct representation of private sector priorities before DRC Ministries & Parliament.',
      'Participation in national tax reform committees and anti-red-tape initiatives.',
      'Quarterly Presidential Private Sector Economic Dialogue summit.',
      'Legal advocacy against arbitrary business fees and administrative delays.',
    ],
    detailsFr: [
      'Représentation directe du secteur privé auprès des Ministères et du Parlement.',
      'Participation aux commissions de réforme fiscale et de simplification administrative.',
      'Sommet trimestriel du Dialogue Économique Président - Secteur Privé.',
      'Défense juridique contre les tracas administratifs et taxes indues.',
    ],
  },
};

export default function ServiceDetailPage() {
  const params = useParams();
  const slug = params?.slug as string;
  const { lang, t } = useLanguage();

  const service = serviceDataMap[slug];

  if (!service) {
    return (
      <div className="pt-36 pb-24 text-center space-y-4">
        <h1 className="text-2xl font-bold text-white">Service Not Found</h1>
        <Link href="/" className="text-xs text-amber-400 underline">Return Home</Link>
      </div>
    );
  }

  const IconComp = service.icon;
  const title = t(service.titleKey as any);
  const desc = t(service.descKey as any);
  const details = lang === 'fr' ? service.detailsFr : service.detailsEn;

  return (
    <div className="pt-32 pb-24 space-y-16">
      <section className="px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto space-y-8">
        <div className="rounded-3xl border border-white/15 bg-[#06122A] p-8 sm:p-12 shadow-2xl space-y-8 relative overflow-hidden">
          <div className="flag-stripe h-[3px]" aria-hidden="true" />

          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-400/20 text-amber-400 border border-amber-400/30">
                <IconComp className="h-7 w-7" />
              </div>
              <div>
                <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest block font-display">
                  Official Chamber Service
                </span>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display">
                  {title}
                </h1>
              </div>
            </div>

            <Link
              href="/register"
              className="rounded-xl bg-amber-400 px-6 py-3 text-xs font-bold text-slate-950 font-display hover:brightness-110 transition-all shrink-0"
            >
              {t('navRegisterCTA')}
            </Link>
          </div>

          <p className="text-base text-slate-300 font-light leading-relaxed border-t border-white/10 pt-6">
            {desc}
          </p>

          <div className="space-y-4 pt-2">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-display">
              Key Service Capabilities
            </h3>
            <div className="grid gap-3 sm:grid-cols-2">
              {details.map((item, idx) => (
                <div key={idx} className="flex items-start gap-3 rounded-xl border border-white/10 bg-[#020914] p-4 text-xs text-slate-300">
                  <CheckCircle className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>

        </div>
      </section>
    </div>
  );
}
