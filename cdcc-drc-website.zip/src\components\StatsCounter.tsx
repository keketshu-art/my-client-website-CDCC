'use client';

import React, { useEffect, useState } from 'react';

interface StatsCounterProps {
  target: number;
  suffix?: string;
  className?: string;
}

export const StatsCounter: React.FC<StatsCounterProps> = ({ target, suffix = '', className = '' }) => {
  const [count, setCount] = useState<number>(0);

  useEffect(() => {
    let start = 0;
    const duration = 1200; // ms
    const increment = Math.max(1, Math.ceil(target / (duration / 16)));
    
    const timer = setInterval(() => {
      start += increment;
      if (start >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(start);
      }
    }, 16);

    return () => clearInterval(timer);
  }, [target]);

  return (
    <span className={className}>
      {count.toLocaleString()}{suffix}
    </span>
  );
};
