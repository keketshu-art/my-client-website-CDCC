'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useLanguage } from '@/context/LanguageContext';
import { Shield, Lock, Mail, CheckCircle2 } from 'lucide-react';

export default function AdminLoginPage() {
  const { t } = useLanguage();
  const router = useRouter();
  const [email, setEmail] = useState('admin@cdcc.africa');
  const [password, setPassword] = useState('admin123');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (email === 'admin@cdcc.africa' && password === 'admin123') {
      localStorage.setItem('cdcc_admin_authed', 'true');
      router.push('/admin');
    } else {
      setError('Invalid credentials. Demo credentials are admin@cdcc.africa / admin123');
    }
  };

  return (
    <div className="pt-36 pb-24 px-4 flex items-center justify-center min-h-[80vh]">
      <div className="w-full max-w-md rounded-3xl border border-white/15 bg-[#06122A] p-8 sm:p-10 shadow-2xl space-y-6 relative overflow-hidden">
        <div className="flag-stripe h-[3px]" aria-hidden="true" />

        <div className="text-center space-y-2">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-400/20 text-amber-400 border border-amber-400/30">
            <Shield className="h-7 w-7" />
          </div>
          <h1 className="text-2xl font-bold text-white font-display">
            {t('adminLoginTitle')}
          </h1>
          <p className="text-xs text-slate-400">
            {t('adminLoginSub')}
          </p>
        </div>

        {error && (
          <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-3 text-xs text-red-300 text-center font-medium">
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1 uppercase tracking-wider">
              {t('adminEmailLabel')}
            </label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-[#020914] pl-10 pr-4 py-3 text-xs text-white focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1 uppercase tracking-wider">
              {t('adminPasswordLabel')}
            </label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-[#020914] pl-10 pr-4 py-3 text-xs text-white focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full rounded-xl font-display py-3.5 text-xs font-bold text-slate-950 shadow-xl transition-all hover:brightness-110"
            style={{ background: 'linear-gradient(120deg, #F7D618 0%, #FFD750 55%, #F59E0B 100%)' }}
          >
            {t('adminLoginBtn')}
          </button>
        </form>

        <div className="border-t border-white/10 pt-4 text-center">
          <p className="text-[11px] text-slate-400 font-mono">
            Demo Credentials Pre-filled (admin@cdcc.africa / admin123)
          </p>
        </div>

      </div>
    </div>
  );
}
