'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useLanguage } from '@/context/LanguageContext';
import { Menu, X, User, MapPin, Shield } from 'lucide-react';

export const Header: React.FC = () => {
  const { lang, setLang, t } = useLanguage();
  const [mobileOpen, setMobileOpen] = useState(false);
  const pathname = usePathname();

  const navLinks = [
    { href: '/', label: t('navHome') },
    { href: '/membership', label: t('navMembership') },
    { href: '/events', label: t('navEvents') },
    { href: '/community', label: t('navCommunity') },
    { href: '/about', label: t('navAbout') },
    { href: '/contact', label: lang === 'fr' ? 'Contact' : 'Contact' },
  ];

  const isActive = (path: string) => {
    if (path === '/' && pathname === '/') return true;
    if (path !== '/' && pathname.startsWith(path)) return true;
    return false;
  };

  return (
    <>
      {/* Accessibility Skip Link */}
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:z-[200] focus:left-4 focus:top-4 focus:rounded-xl focus:bg-[#FED701] focus:px-4 focus:py-2.5 focus:font-bold focus:text-[#05005B] focus:shadow-2xl focus:outline-none"
      >
        {t('skipContent')}
      </a>

      {/* Midnight Navy Header */}
      <header className="fixed inset-x-0 top-0 z-50 bg-[#05005B] border-b border-blue-900/50 shadow-xl">
        {/* Top Flag Stripe Accent */}
        <div className="flag-stripe h-[3px]" aria-hidden="true" />

        <div className="mx-auto max-w-7xl px-4 py-2.5 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-4">

            {/* Brand Logo & Sovereign Tag */}
            <Link href="/" className="flex items-center gap-3 shrink-0 focus:outline-none group">
              <div className="flex items-center gap-2.5">
                <img
                  src="/images/cdcc-logo.png"
                  alt="CDCC — Chambre de Commerce R.D. Congo"
                  className="h-9 w-auto object-contain transition-transform group-hover:scale-105 brightness-125"
                  style={{ height: '36px', maxHeight: '36px', width: 'auto' }}
                />
                <div className="hidden sm:flex flex-col border-l border-blue-800/60 pl-2.5">
                  <span className="text-xs font-black tracking-tight text-white leading-none font-display">
                    CDCC <span className="text-[#CE1126]">RDC</span>
                  </span>
                  <span className="text-[9px] font-extrabold text-[#FED701] uppercase tracking-wider mt-0.5">
                    Home Portal
                  </span>
                </div>
              </div>
            </Link>

            {/* Desktop Navigation Links */}
            <ul className="hidden lg:flex items-center gap-6 text-[13px] font-semibold text-slate-200">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className={`nl transition-colors hover:text-white ${
                      isActive(link.href) ? 'active text-[#FED701] font-bold' : ''
                    }`}
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>

            {/* Right Desktop Controls */}
            <div className="hidden lg:flex items-center gap-3">
              {/* Language Switcher Pill */}
              <div
                className="flex items-center rounded-lg border border-blue-900/60 bg-[#00017A]/80 p-0.5"
                aria-label="Language Selector"
              >
                <button
                  type="button"
                  onClick={() => setLang('fr')}
                  className={`rounded-md px-2.5 py-1 text-[11px] font-bold transition-all flex items-center gap-1 ${
                    lang === 'fr'
                      ? 'bg-[#151EA6] text-white shadow-sm'
                      : 'text-slate-300 hover:text-white'
                  }`}
                  aria-pressed={lang === 'fr'}
                >
                  <span className="text-[9px] opacity-75">文A</span> FR
                </button>
                <button
                  type="button"
                  onClick={() => setLang('en')}
                  className={`rounded-md px-2.5 py-1 text-[11px] font-bold transition-all ${
                    lang === 'en'
                      ? 'bg-[#151EA6] text-white shadow-sm'
                      : 'text-slate-300 hover:text-white'
                  }`}
                  aria-pressed={lang === 'en'}
                >
                  EN
                </button>
              </div>

              {/* Territory Indicator Icon */}
              <div
                className="flex h-8 w-8 items-center justify-center rounded-lg border border-blue-900/60 bg-[#00017A]/80 text-slate-300"
                title="RDC · 26 Provinces"
              >
                <MapPin className="h-4 w-4 text-[#FED701]" />
              </div>

              {/* Admin / Portal Link */}
              <Link
                href="/admin/login"
                className="flex h-8 w-8 items-center justify-center rounded-lg border border-blue-900/60 bg-[#00017A]/80 text-slate-300 hover:text-white transition-colors"
                title="Consular Admin Portal"
              >
                <User className="h-4 w-4" />
              </Link>

              {/* Primary CTA Button (Palette Gold Gradient) */}
              <Link
                href="/register"
                className="font-display rounded-xl bg-gradient-to-r from-[#FED701] via-[#FEC203] to-[#FCB305] px-4 py-2 text-[12px] font-black text-[#05005B] transition-all shadow-md hover:brightness-105 active:scale-95 flex items-center gap-1.5"
              >
                <span>{t('navRegisterCTA')}</span>
              </Link>
            </div>

            {/* Mobile Actions & Hamburger */}
            <div className="flex lg:hidden items-center gap-2">
              <div className="flex items-center rounded-lg border border-blue-900/60 bg-[#00017A] p-0.5">
                <button
                  type="button"
                  onClick={() => setLang(lang === 'fr' ? 'en' : 'fr')}
                  className="rounded-md px-2 py-0.5 text-[10px] font-bold bg-[#151EA6] text-white"
                >
                  {lang.toUpperCase()}
                </button>
              </div>

              <Link
                href="/admin/login"
                className="flex h-8 w-8 items-center justify-center rounded-lg border border-blue-900/60 bg-[#00017A] text-slate-300"
              >
                <User className="h-4 w-4" />
              </Link>

              <button
                type="button"
                onClick={() => setMobileOpen(!mobileOpen)}
                className="rounded-lg border border-blue-900/60 p-2 text-slate-300 hover:bg-[#00017A] transition-colors focus:outline-none"
                aria-expanded={mobileOpen}
                aria-label="Toggle navigation menu"
              >
                {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </button>
            </div>
          </div>

          {/* Mobile Dark Menu Drawer */}
          {mobileOpen && (
            <div className="border-t border-blue-900/60 mt-3 pt-4 pb-5 lg:hidden bg-[#05005B] rounded-2xl shadow-2xl p-4 space-y-4">
              <ul className="space-y-1 text-sm font-semibold text-slate-300">
                {navLinks.map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      onClick={() => setMobileOpen(false)}
                      className={`block rounded-xl px-4 py-2.5 transition-colors ${
                        isActive(link.href)
                          ? 'bg-[#00017A] text-[#FED701] font-bold'
                          : 'hover:bg-[#00017A] hover:text-white'
                      }`}
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>

              <div className="pt-2 border-t border-blue-900/60 flex items-center justify-between text-xs text-slate-400">
                <span>Chambre Nationale RDC</span>
                <Link
                  href="/admin/login"
                  onClick={() => setMobileOpen(false)}
                  className="text-[#FED701] font-bold flex items-center gap-1"
                >
                  <Shield className="h-3.5 w-3.5" />
                  <span>Admin Login</span>
                </Link>
              </div>

              <Link
                href="/register"
                onClick={() => setMobileOpen(false)}
                className="block w-full text-center rounded-xl bg-gradient-to-r from-[#FED701] via-[#FEC203] to-[#FCB305] py-3 text-xs font-black text-[#05005B] shadow-md"
              >
                {t('navRegisterCTA')}
              </Link>
            </div>
          )}
        </div>
      </header>
    </>
  );
};
