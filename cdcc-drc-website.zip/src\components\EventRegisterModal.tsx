'use client';

import React, { useState } from 'react';
import { X, Calendar, MapPin, Tag, CheckCircle2 } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';
import { EventItem } from '@/lib/dataStore';

interface EventRegisterModalProps {
  isOpen: boolean;
  onClose: () => void;
  event: EventItem | null;
}

export const EventRegisterModal: React.FC<EventRegisterModalProps> = ({
  isOpen,
  onClose,
  event,
}) => {
  const { lang, t } = useLanguage();
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    company: '',
    sector: 'General',
    message: '',
  });
  const [loading, setLoading] = useState(false);
  const [successCode, setSuccessCode] = useState<string | null>(null);

  if (!isOpen || !event) return null;

  const title = lang === 'fr' ? event.titleFr : event.titleEn;
  const location = lang === 'fr' ? event.locationFr : event.locationEn;
  const description = lang === 'fr' ? event.descriptionFr : event.descriptionEn;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          message: `Event Registration for: ${event.titleEn} (${event.date}) - ${formData.message}`,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setSuccessCode(data.refCode);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const resetModal = () => {
    setSuccessCode(null);
    setFormData({ fullName: '', email: '', phone: '', company: '', sector: 'General', message: '' });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 sm:p-6 overflow-y-auto">
      <div className="relative w-full max-w-2xl overflow-hidden rounded-3xl border border-white/15 bg-[#03091A] shadow-2xl my-8">
        <div className="flag-stripe h-[3px]" />

        {/* Modal Header */}
        <div className="flex items-center justify-between p-6 border-b border-white/10 bg-[#06122A]">
          <div>
            <span className="text-[11px] font-bold tracking-widest text-amber-400 uppercase">
              {t('eventRegisterModalTitle')}
            </span>
            <h2 className="text-xl font-bold text-white font-display mt-1 line-clamp-1">
              {title}
            </h2>
          </div>
          <button
            onClick={resetModal}
            className="rounded-full border border-white/10 p-2 text-slate-400 hover:bg-white/10 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Event Quick Info */}
          <div className="rounded-2xl border border-white/10 bg-[#020914] p-4 flex flex-wrap items-center justify-between gap-4 text-xs">
            <div className="flex items-center gap-2 text-slate-300">
              <Calendar className="h-4 w-4 text-amber-400" />
              <span className="font-semibold text-white">{event.date}</span>
            </div>
            <div className="flex items-center gap-2 text-slate-300">
              <MapPin className="h-4 w-4 text-[#007DC5]" />
              <span>{location}</span>
            </div>
            <div className="flex items-center gap-2 text-slate-300">
              <Tag className="h-4 w-4 text-[#CE1126]" />
              <span className="rounded-full bg-white/5 px-2.5 py-0.5 border border-white/10 text-white">
                {event.type}
              </span>
            </div>
          </div>

          {successCode ? (
            <div className="py-8 text-center space-y-4">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <CheckCircle2 className="h-10 w-10" />
              </div>
              <h3 className="text-2xl font-bold text-white font-display">
                {t('registrationSuccessTitle')}
              </h3>
              <p className="text-sm text-slate-300 max-w-md mx-auto">
                {t('registrationSuccessSub')}{' '}
                <strong className="text-amber-400 font-mono text-base px-2 py-1 bg-white/5 rounded border border-amber-400/30">
                  {successCode}
                </strong>
              </p>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                {t('formSuccessMsg')}
              </p>
              <button
                onClick={resetModal}
                className="mt-4 rounded-xl bg-amber-400 px-6 py-2.5 text-xs font-bold text-slate-950 hover:brightness-110 transition-all"
              >
                Close Window
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('formFullName')} *
                </label>
                <input
                  type="text"
                  required
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  placeholder="e.g. Jean-Luc Tshisekedi"
                  className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3 text-sm text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {t('formEmail')} *
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="name@company.cd"
                    className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3 text-sm text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {t('formPhone')} *
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="+243 81 000 0000"
                    className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3 text-sm text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('formCompany')}
                </label>
                <input
                  type="text"
                  value={formData.company}
                  onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                  placeholder="e.g. Enterprise SARL"
                  className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3 text-sm text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('formMessage')}
                </label>
                <textarea
                  rows={3}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Special requests or dietary requirements..."
                  className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3 text-sm text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full rounded-xl font-display py-3.5 text-sm font-bold text-slate-950 transition-all hover:brightness-110 disabled:opacity-50"
                  style={{ background: 'linear-gradient(120deg, #F7D618 0%, #FFD750 55%, #F59E0B 100%)' }}
                >
                  {loading ? 'Processing...' : t('formSubmit')}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
