'use client';

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useLanguage } from '@/context/LanguageContext';
import { DataStore, EventItem, GalleryItem, MemberRegistration, StatsCounters } from '@/lib/dataStore';
import {
  ShieldCheck,
  LayoutDashboard,
  Calendar,
  Image as ImageIcon,
  Users,
  LogOut,
  Plus,
  Trash2,
  Upload,
  CheckCircle,
  RefreshCw,
} from 'lucide-react';

export default function AdminDashboardPage() {
  const { lang, t } = useLanguage();
  const router = useRouter();

  const [authed, setAuthed] = useState(false);
  const [activeTab, setActiveTab] = useState<'counters' | 'events' | 'gallery' | 'members'>('counters');

  // Full data store state
  const [dataStore, setDataStore] = useState<DataStore | null>(null);

  // Counter inputs
  const [statsForm, setStatsForm] = useState<StatsCounters>({
    members: 1450,
    provinces: 26,
    eventsPerYear: 32,
    registered: 3820,
    upcoming: 3,
    eventsTracked: 148,
    yearsOfService: 66,
  });

  // New Event Form
  const [newEvent, setNewEvent] = useState({
    titleEn: '',
    titleFr: '',
    date: new Date().toISOString().split('T')[0],
    locationEn: 'Kinshasa · DRC',
    locationFr: 'Kinshasa · RDC',
    province: 'Kinshasa',
    type: 'Summit',
    descriptionEn: '',
    descriptionFr: '',
    image: '/storage/events-gallery/UjJdNYotyXStP2wJgWpFkkGNHVmQxUaRGiqU11y9.jpg',
    isUpcoming: true,
  });

  // Upload Photo Form
  const [uploadTitleEn, setUploadTitleEn] = useState('');
  const [uploadTitleFr, setUploadTitleFr] = useState('');
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  const [message, setMessage] = useState('');

  useEffect(() => {
    const isAuthed = localStorage.getItem('cdcc_admin_authed');
    if (!isAuthed) {
      router.push('/admin/login');
    } else {
      setAuthed(true);
      fetchData();
    }
  }, [router]);

  const fetchData = () => {
    fetch('/api/data')
      .then((res) => res.json())
      .then((data: DataStore) => {
        setDataStore(data);
        if (data.stats) setStatsForm(data.stats);
      })
      .catch((err) => console.error(err));
  };

  const handleLogout = () => {
    localStorage.removeItem('cdcc_admin_authed');
    router.push('/admin/login');
  };

  // Update Dynamic Stats Counters
  const handleUpdateStats = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/data', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stats: statsForm }),
      });
      const data = await res.json();
      if (data.success) {
        setMessage('Dynamic counters updated successfully in database!');
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Create Event
  const handleCreateEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newEvent),
      });
      const data = await res.json();
      if (data.success) {
        setMessage('Event published successfully!');
        setNewEvent({
          titleEn: '',
          titleFr: '',
          date: new Date().toISOString().split('T')[0],
          locationEn: 'Kinshasa · DRC',
          locationFr: 'Kinshasa · RDC',
          province: 'Kinshasa',
          type: 'Summit',
          descriptionEn: '',
          descriptionFr: '',
          image: '/storage/events-gallery/UjJdNYotyXStP2wJgWpFkkGNHVmQxUaRGiqU11y9.jpg',
          isUpcoming: true,
        });
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Delete Event
  const handleDeleteEvent = async (id: string) => {
    if (!confirm('Are you sure you want to delete this event?')) return;
    try {
      const res = await fetch(`/api/events?id=${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        setMessage('Event deleted.');
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Upload Photo
  const handleUploadPhoto = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadFile) return;
    setUploading(true);

    try {
      const formData = new FormData();
      formData.append('file', uploadFile);
      formData.append('titleEn', uploadTitleEn || 'Chamber Event Photo');
      formData.append('titleFr', uploadTitleFr || 'Photo d\'événement de la Chambre');

      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      const data = await res.json();
      if (data.success) {
        setMessage('Photo uploaded to /storage/events-gallery/ and added to gallery!');
        setUploadFile(null);
        setUploadTitleEn('');
        setUploadTitleFr('');
        fetchData();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setUploading(false);
    }
  };

  if (!authed || !dataStore) {
    return (
      <div className="pt-36 text-center text-slate-400 font-mono">
        Loading Admin Dashboard...
      </div>
    );
  }

  return (
    <div className="pt-32 pb-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-6">
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-400/20 text-amber-400 border border-amber-400/30">
            <ShieldCheck className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white font-display">
              {t('adminDashboardTitle')}
            </h1>
            <p className="text-xs text-slate-400 font-mono">
              Authenticated Admin: admin@cdcc.africa
            </p>
          </div>
        </div>

        <button
          onClick={handleLogout}
          className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-4 py-2.5 text-xs font-bold text-slate-300 hover:bg-red-500/20 hover:text-red-300 hover:border-red-500/30 transition-all w-fit"
        >
          <LogOut className="h-4 w-4" />
          <span>{t('adminLogout')}</span>
        </button>
      </div>

      {message && (
        <div className="rounded-2xl border border-emerald-500/40 bg-emerald-500/10 p-4 text-xs font-bold text-emerald-300 flex items-center justify-between">
          <span>{message}</span>
          <button onClick={() => setMessage('')} className="text-white hover:underline">Dismiss</button>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-white/10 pb-2">
        <button
          onClick={() => setActiveTab('counters')}
          className={`flex items-center gap-2 rounded-xl px-5 py-2.5 text-xs font-bold transition-all ${
            activeTab === 'counters' ? 'bg-amber-400 text-slate-950 shadow-lg' : 'bg-white/5 text-slate-400 hover:text-white'
          }`}
        >
          <LayoutDashboard className="h-4 w-4" />
          <span>{t('adminTabOverview')}</span>
        </button>

        <button
          onClick={() => setActiveTab('events')}
          className={`flex items-center gap-2 rounded-xl px-5 py-2.5 text-xs font-bold transition-all ${
            activeTab === 'events' ? 'bg-amber-400 text-slate-950 shadow-lg' : 'bg-white/5 text-slate-400 hover:text-white'
          }`}
        >
          <Calendar className="h-4 w-4" />
          <span>{t('adminTabEvents')} ({dataStore.events.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('gallery')}
          className={`flex items-center gap-2 rounded-xl px-5 py-2.5 text-xs font-bold transition-all ${
            activeTab === 'gallery' ? 'bg-amber-400 text-slate-950 shadow-lg' : 'bg-white/5 text-slate-400 hover:text-white'
          }`}
        >
          <ImageIcon className="h-4 w-4" />
          <span>{t('adminTabGallery')} ({dataStore.gallery.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('members')}
          className={`flex items-center gap-2 rounded-xl px-5 py-2.5 text-xs font-bold transition-all ${
            activeTab === 'members' ? 'bg-amber-400 text-slate-950 shadow-lg' : 'bg-white/5 text-slate-400 hover:text-white'
          }`}
        >
          <Users className="h-4 w-4" />
          <span>{t('adminTabMembers')} ({dataStore.registrations.length})</span>
        </button>
      </div>

      {/* TAB 1: DYNAMIC STATS COUNTERS */}
      {activeTab === 'counters' && (
        <div className="rounded-3xl border border-white/15 bg-[#06122A] p-8 space-y-6 shadow-2xl">
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <h2 className="text-xl font-bold text-white font-display">
              Manage Dynamic Database Counters
            </h2>
            <p className="text-xs text-slate-400">
              Values set here dynamically drive all counters across Hero, About, and Footer!
            </p>
          </div>

          <form onSubmit={handleUpdateStats} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Total Members</label>
              <input
                type="number"
                value={statsForm.members}
                onChange={(e) => setStatsForm({ ...statsForm, members: parseInt(e.target.value) || 0 })}
                className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3 text-sm text-white focus:border-amber-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Registered Members</label>
              <input
                type="number"
                value={statsForm.registered}
                onChange={(e) => setStatsForm({ ...statsForm, registered: parseInt(e.target.value) || 0 })}
                className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3 text-sm text-white focus:border-amber-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Events Per Year</label>
              <input
                type="number"
                value={statsForm.eventsPerYear}
                onChange={(e) => setStatsForm({ ...statsForm, eventsPerYear: parseInt(e.target.value) || 0 })}
                className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3 text-sm text-white focus:border-amber-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Upcoming Events Count</label>
              <input
                type="number"
                value={statsForm.upcoming}
                onChange={(e) => setStatsForm({ ...statsForm, upcoming: parseInt(e.target.value) || 0 })}
                className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3 text-sm text-white focus:border-amber-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Events Tracked Count</label>
              <input
                type="number"
                value={statsForm.eventsTracked}
                onChange={(e) => setStatsForm({ ...statsForm, eventsTracked: parseInt(e.target.value) || 0 })}
                className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3 text-sm text-white focus:border-amber-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Provinces Count</label>
              <input
                type="number"
                value={statsForm.provinces}
                readOnly
                className="w-full rounded-xl border border-white/10 bg-[#020914]/50 px-4 py-3 text-sm text-slate-500"
              />
            </div>

            <div className="sm:col-span-2 lg:col-span-3 pt-2">
              <button
                type="submit"
                className="rounded-xl bg-amber-400 px-8 py-3.5 text-xs font-bold text-slate-950 font-display hover:brightness-110 transition-all shadow-lg"
              >
                {t('adminUpdateStatsBtn')}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB 2: MANAGE EVENTS */}
      {activeTab === 'events' && (
        <div className="space-y-8">
          {/* Create Event Form */}
          <div className="rounded-3xl border border-white/15 bg-[#06122A] p-8 space-y-6 shadow-2xl">
            <h2 className="text-xl font-bold text-white font-display">
              {t('adminAddEventBtn')}
            </h2>

            <form onSubmit={handleCreateEvent} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Title (English) *</label>
                  <input
                    type="text"
                    required
                    value={newEvent.titleEn}
                    onChange={(e) => setNewEvent({ ...newEvent, titleEn: e.target.value })}
                    placeholder="e.g. DRC Mining Forum 2026"
                    className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3 text-xs text-white focus:border-amber-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Title (French) *</label>
                  <input
                    type="text"
                    required
                    value={newEvent.titleFr}
                    onChange={(e) => setNewEvent({ ...newEvent, titleFr: e.target.value })}
                    placeholder="e.g. Forum Minier RDC 2026"
                    className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3 text-xs text-white focus:border-amber-400 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Date *</label>
                  <input
                    type="date"
                    required
                    value={newEvent.date}
                    onChange={(e) => setNewEvent({ ...newEvent, date: e.target.value })}
                    className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3 text-xs text-white focus:border-amber-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Province *</label>
                  <input
                    type="text"
                    required
                    value={newEvent.province}
                    onChange={(e) => setNewEvent({ ...newEvent, province: e.target.value })}
                    placeholder="Kinshasa / Haut-Katanga"
                    className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3 text-xs text-white focus:border-amber-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Event Type *</label>
                  <select
                    value={newEvent.type}
                    onChange={(e) => setNewEvent({ ...newEvent, type: e.target.value })}
                    className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3 text-xs text-white focus:border-amber-400 focus:outline-none"
                  >
                    <option value="Summit">Summit</option>
                    <option value="Trade Mission">Trade Mission</option>
                    <option value="Forum">Forum</option>
                    <option value="Workshop">Workshop</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Description (English)</label>
                  <textarea
                    rows={3}
                    value={newEvent.descriptionEn}
                    onChange={(e) => setNewEvent({ ...newEvent, descriptionEn: e.target.value })}
                    className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3 text-xs text-white focus:border-amber-400 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Description (French)</label>
                  <textarea
                    rows={3}
                    value={newEvent.descriptionFr}
                    onChange={(e) => setNewEvent({ ...newEvent, descriptionFr: e.target.value })}
                    className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3 text-xs text-white focus:border-amber-400 focus:outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="rounded-xl bg-amber-400 px-7 py-3 text-xs font-bold text-slate-950 font-display hover:brightness-110 transition-all"
              >
                Publish Event
              </button>
            </form>
          </div>

          {/* Existing Events List */}
          <div className="rounded-3xl border border-white/15 bg-[#06122A] p-8 space-y-4 shadow-2xl">
            <h3 className="text-lg font-bold text-white font-display">Published Events</h3>
            <div className="divide-y divide-white/10">
              {dataStore.events.map((evt) => (
                <div key={evt.id} className="py-4 flex items-center justify-between gap-4">
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold text-amber-400 font-mono">{evt.date} · {evt.province}</span>
                    <h4 className="text-sm font-bold text-white">{evt.titleEn}</h4>
                    <p className="text-xs text-slate-400">{evt.locationEn}</p>
                  </div>
                  <button
                    onClick={() => handleDeleteEvent(evt.id)}
                    className="rounded-lg border border-red-500/30 bg-red-500/10 p-2 text-red-400 hover:bg-red-500 hover:text-white transition-colors"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: MANAGE GALLERY */}
      {activeTab === 'gallery' && (
        <div className="space-y-8">
          <div className="rounded-3xl border border-white/15 bg-[#06122A] p-8 space-y-6 shadow-2xl">
            <h2 className="text-xl font-bold text-white font-display">
              {t('adminUploadPhotoBtn')}
            </h2>

            <form onSubmit={handleUploadPhoto} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Photo Title (English)</label>
                  <input
                    type="text"
                    required
                    value={uploadTitleEn}
                    onChange={(e) => setUploadTitleEn(e.target.value)}
                    placeholder="e.g. Chamber Assembly at Sky Hotel Sandton"
                    className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3 text-xs text-white focus:border-amber-400 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Photo Title (French)</label>
                  <input
                    type="text"
                    required
                    value={uploadTitleFr}
                    onChange={(e) => setUploadTitleFr(e.target.value)}
                    placeholder="e.g. Assemblée de la Chambre à l'Hôtel Sky Sandton"
                    className="w-full rounded-xl border border-white/10 bg-[#020914] px-4 py-3 text-xs text-white focus:border-amber-400 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Select Image File (Stored under /storage/events-gallery/)
                </label>
                <input
                  type="file"
                  accept="image/*"
                  required
                  onChange={(e) => setUploadFile(e.target.files?.[0] || null)}
                  className="w-full rounded-xl border border-white/10 bg-[#020914] p-3 text-xs text-white focus:border-amber-400 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={uploading}
                className="rounded-xl bg-amber-400 px-7 py-3 text-xs font-bold text-slate-950 font-display hover:brightness-110 transition-all disabled:opacity-50"
              >
                {uploading ? 'Uploading...' : 'Upload Photo'}
              </button>
            </form>
          </div>

          <div className="grid gap-4 sm:grid-cols-3">
            {dataStore.gallery.map((g) => (
              <div key={g.id} className="rounded-2xl border border-white/10 bg-[#06122A] overflow-hidden">
                <img src={g.photos[0]} alt={g.titleEn} className="h-40 w-full object-cover" />
                <div className="p-3">
                  <p className="text-[10px] text-amber-400 font-mono">{g.date}</p>
                  <p className="text-xs font-bold text-white line-clamp-2">{g.titleEn}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: MEMBER & DIASPORA REGISTRATIONS */}
      {activeTab === 'members' && (
        <div className="rounded-3xl border border-white/15 bg-[#06122A] p-8 space-y-6 shadow-2xl overflow-x-auto">
          <h2 className="text-xl font-bold text-white font-display">
            Member & Diaspora Registrations ({dataStore.registrations.length})
          </h2>

          <table className="w-full text-left text-xs text-slate-300 border-collapse">
            <thead>
              <tr className="border-b border-white/10 text-amber-400 uppercase tracking-wider font-mono">
                <th className="p-3">Ref ID</th>
                <th className="p-3">Full Name</th>
                <th className="p-3">Email & Phone</th>
                <th className="p-3">Country / Province</th>
                <th className="p-3">Sector</th>
                <th className="p-3">Type</th>
                <th className="p-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {dataStore.registrations.map((reg) => (
                <tr key={reg.id} className="hover:bg-white/5">
                  <td className="p-3 font-mono font-bold text-white">{reg.id}</td>
                  <td className="p-3 font-bold text-white">{reg.fullName}</td>
                  <td className="p-3">
                    <p>{reg.email}</p>
                    <p className="text-slate-500">{reg.phone}</p>
                  </td>
                  <td className="p-3">
                    <p>{reg.country}</p>
                    <p className="text-slate-500">{reg.province}</p>
                  </td>
                  <td className="p-3">{reg.sector}</td>
                  <td className="p-3">
                    <span className={`rounded-full px-2.5 py-0.5 text-[10px] font-bold ${
                      reg.type === 'diaspora' ? 'bg-amber-400/20 text-amber-400 border border-amber-400/30' : 'bg-blue-400/20 text-blue-300 border border-blue-400/30'
                    }`}>
                      {reg.type}
                    </span>
                  </td>
                  <td className="p-3">
                    <span className="rounded-full bg-emerald-500/20 text-emerald-300 px-2.5 py-0.5 text-[10px] font-bold border border-emerald-500/30">
                      {reg.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

    </div>
  );
}
