'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useLanguage } from '@/context/LanguageContext';
import { ProvinceMap } from '@/components/ProvinceMap';
import {
  Download,
  BookOpen,
  FileText,
  Users,
  GraduationCap,
  Globe2,
  Sparkles,
  Search,
  CheckCircle2,
  ArrowRight,
  Building2,
  MapPin,
  Share2,
  UserCheck,
  ShieldCheck,
  FileSpreadsheet,
} from 'lucide-react';

interface ChapterDetail {
  id: string;
  name: string;
  hubType: string;
  president: string;
  cadreFirms: string;
  address: string;
  pillars: string[];
}

const chaptersData: Record<string, ChapterDetail> = {
  kinshasa: {
    id: 'kinshasa',
    name: 'Kinshasa Chapter',
    hubType: 'METROPOLITAN HUB · CDCC OFFICIAL',
    president: 'Me. Dieudonné Bakole',
    cadreFirms: '1,420 Firms (Across 18 Sectors)',
    address: 'Immeuble BCDC, 4ème Étage, Boulevard du 30 Juin, Gombe, Kinshasa',
    pillars: ['Fintech', 'Hydrocarbons', 'FMCG', 'Bilateral Port Trade'],
  },
  'haut-katanga': {
    id: 'haut-katanga',
    name: 'Haut-Katanga Chapter',
    hubType: 'MINING & LOGISTICS HUB',
    president: 'Dr. Chantal Mukendi',
    cadreFirms: '980 Firms (Across 12 Sectors)',
    address: 'Avenue Kasavubu, Immeuble Karavia, Lubumbashi',
    pillars: ['Copper & Cobalt Logistics', 'Smelting', 'Agro-processing', 'Border Trade'],
  },
  lualaba: {
    id: 'lualaba',
    name: 'Lualaba Chapter',
    hubType: 'ENERGY & BATTERY HUB',
    president: 'Mr. Pravir Kumar (ArtSolar Liaison)',
    cadreFirms: '640 Firms (Across 9 Sectors)',
    address: 'Boulevard du 30 Juin, Kolwezi Industrial Zone',
    pillars: ['Solar Micro-grids', 'Lithium Extraction', 'Refining', 'Heavy Machinery'],
  },
  'kongo-central': {
    id: 'kongo-central',
    name: 'Kongo Central Chapter',
    hubType: 'MARITIME PORT HUB',
    president: 'Mme. Marie-Claire Kalala',
    cadreFirms: '720 Firms (Across 14 Sectors)',
    address: 'Port Gateway Avenue, Matadi Maritime Complex',
    pillars: ['Deep Sea Port Logistics', 'Customs Fast-Track', 'Agricultural Export', 'Shipping'],
  },
  'nord-kivu': {
    id: 'nord-kivu',
    name: 'Nord-Kivu Chapter',
    hubType: 'EASTERN TRADE GATEWAY',
    president: 'Me. Jean-Claude Paluku',
    cadreFirms: '580 Firms (Across 11 Sectors)',
    address: 'Commercial District, Avenue du Lac, Goma',
    pillars: ['Cross-Border EAC Trade', 'Digital Customs', 'Coffee Export', 'Hydropower'],
  },
};

export default function CommunityPage() {
  const { lang, t } = useLanguage();
  const [selectedProvinceKey, setSelectedProvinceKey] = useState<string>('kinshasa');
  const [mentorshipRequested, setMentorshipRequested] = useState<string | null>(null);

  const selectedChapter = chaptersData[selectedProvinceKey] || chaptersData.kinshasa;

  const mentors = [
    {
      id: 'm1',
      name: 'Hélène Kalala-Mwanza',
      roleEn: 'Senior Partner · Katanga Mineral Logistics',
      roleFr: 'Associée Principale · Logistique Minière du Katanga',
      former: 'Former VP, Central African Trade Corridor',
      bioEn: 'Specialized in supply chain de-bottlenecking via Lobito corridor, mineral freight customs, and ESG compliance with London Metal Exchange guidelines.',
      bioFr: 'Spécialisée dans la décongestion logistique via le corridor de Lobito et la conformité ESG selon les directives LME.',
      statusEn: '3 Spots Open',
      statusFr: '3 Places Disponibles',
      image: '/storage/events-gallery/7eFFWH6DdJSmT8zPqP9iZXz8IU7gaWt6ElJbkO2I.jpg',
    },
    {
      id: 'm2',
      name: 'Patrick Ilunga Tshibangu',
      roleEn: 'Managing Director · Congo AgroVenture Capital',
      roleFr: 'Directeur Général · Congo AgroVenture Capital',
      former: 'Diaspora Alum (Johannesburg / Kinshasa)',
      bioEn: 'Advising high-growth SMEs on cross-border debt syndication, SADC trade harmonization, and mobilizing diaspora co-investment vehicles.',
      bioFr: 'Conseil aux PME à forte croissance sur la syndication de dette transfrontalière et les véhicules de co-investissement diaspora.',
      statusEn: 'Available this Month',
      statusFr: 'Disponible ce Mois',
      image: '/storage/events-gallery/NJ4gwHinL7OG6yrNFR62Fc3I7Hn08sTGpQsKCk5d.jpg',
    },
  ];

  return (
    <div className="space-y-16 pb-12 pt-24 sm:pt-28">

      {/* 1. HERO HEADER */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 rounded-full border border-sky-300 bg-sky-50 px-3.5 py-1.5 text-[11px] font-bold text-[#007DC5] uppercase tracking-wider">
          <Sparkles className="h-3.5 w-3.5 text-[#007DC5]" />
          <span>ECOSYSTEM VISION · STRONGER TOGETHER</span>
        </div>

        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#07162C] font-display max-w-4xl leading-tight">
          Uniting 26 Provinces, 4,800+ Enterprises & Global Diaspora
        </h1>

        <p className="text-sm sm:text-base text-slate-600 max-w-3xl leading-relaxed">
          The institutional bridge interconnecting local industrial heartlands from Katanga to Kongo Central with pan-African corridors and sovereign diaspora capital.
        </p>

        {/* 3 Metric Chips Row */}
        <div className="grid grid-cols-3 gap-4 pt-4 max-w-2xl">
          <div className="executive-card rounded-2xl p-4 bg-white border border-slate-200">
            <p className="font-display text-2xl font-black text-[#007DC5]">26</p>
            <p className="text-xs font-bold text-[#07162C]">Provinces</p>
            <p className="text-[10px] text-slate-500">100% Chartered</p>
          </div>

          <div className="executive-card rounded-2xl p-4 bg-white border border-slate-200">
            <p className="font-display text-2xl font-black text-amber-600">4.8k+</p>
            <p className="text-xs font-bold text-[#07162C]">Enterprises</p>
            <p className="text-[10px] text-slate-500">Active Cadre</p>
          </div>

          <div className="executive-card rounded-2xl p-4 bg-white border border-slate-200">
            <p className="font-display text-2xl font-black text-emerald-600">42</p>
            <p className="text-xs font-bold text-[#07162C]">Consular Desks</p>
            <p className="text-[10px] text-slate-500">Global Reach</p>
          </div>
        </div>
      </section>


      {/* 2. DECENTRALIZED REGISTRY · PROVINCIAL CHAPTER DIRECTORY */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 border-b border-slate-200 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-amber-600 uppercase tracking-widest block font-display">
                ● DECENTRALIZED REGISTRY
              </span>
              <span className="rounded-full bg-sky-100 text-[#007DC5] font-bold text-[10px] px-2.5 py-0.5">
                Live Desks
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#07162C] font-display">
              Provincial Chapter Directory
            </h2>
          </div>
          <p className="text-xs text-slate-500 max-w-md">
            Select any Congolese province to inspect accredited presidency, sectoral leadership, and one-stop trade desk access.
          </p>
        </div>

        {/* Province Filter Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2">
          {Object.keys(chaptersData).map((key) => {
            const ch = chaptersData[key];
            const active = selectedProvinceKey === key;
            return (
              <button
                key={key}
                onClick={() => setSelectedProvinceKey(key)}
                className={`rounded-xl px-4 py-2 text-xs font-bold transition-all whitespace-nowrap ${
                  active
                    ? 'bg-[#07162C] text-white shadow-md'
                    : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                {ch.name.replace(' Chapter', '')}
              </button>
            );
          })}
        </div>

        {/* Selected Chapter Detail Card */}
        <div className="executive-card rounded-3xl p-6 sm:p-8 bg-white border-slate-200 space-y-6 shadow-lg">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <span className="text-[10px] font-bold text-[#007DC5] uppercase tracking-wider block">
                {selectedChapter.hubType}
              </span>
              <h3 className="text-2xl font-extrabold text-[#07162C] font-display">
                {selectedChapter.name}
              </h3>
              <p className="text-xs text-slate-500">Capital Territory & Financial District</p>
            </div>
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-sky-50 text-[#007DC5] shrink-0">
              <Building2 className="h-6 w-6" />
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-6">
            <div className="space-y-1 bg-slate-50 p-4 rounded-2xl border border-slate-200">
              <span className="text-[10px] font-bold text-slate-400 uppercase">CHAPTER PRESIDENT</span>
              <p className="text-sm font-extrabold text-[#07162C]">{selectedChapter.president}</p>
              <p className="text-[11px] text-slate-500">Appointed Council</p>
            </div>

            <div className="space-y-1 bg-slate-50 p-4 rounded-2xl border border-slate-200">
              <span className="text-[10px] font-bold text-slate-400 uppercase">REGISTERED CADRE</span>
              <p className="text-sm font-extrabold text-[#007DC5]">{selectedChapter.cadreFirms}</p>
              <p className="text-[11px] text-slate-500">Verified Enterprises</p>
            </div>
          </div>

          <div className="space-y-3 pt-2">
            <div className="flex items-start gap-2 text-xs text-slate-600">
              <MapPin className="h-4 w-4 text-[#007DC5] shrink-0 mt-0.5" />
              <span>{selectedChapter.address}</span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-slate-500">Pillars:</span>
              {selectedChapter.pillars.map((pil, idx) => (
                <span key={idx} className="rounded-full bg-slate-100 border border-slate-200 text-slate-700 text-[11px] font-semibold px-3 py-0.5">
                  {pil}
                </span>
              ))}
            </div>
          </div>

          <div className="pt-2 flex items-center gap-3">
            <Link
              href="/register"
              className="rounded-xl bg-[#07162C] hover:bg-[#0C2344] px-6 py-2.5 text-xs font-bold text-white transition-all flex items-center gap-2"
            >
              <Building2 className="h-4 w-4 text-amber-400" />
              <span>Contact Provincial Desk</span>
            </Link>

            <button
              onClick={() => alert(`Sharing ${selectedChapter.name} accreditation link.`)}
              className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100 transition-colors"
            >
              <Share2 className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Interactive Province Map Component */}
        <div className="pt-4">
          <ProvinceMap />
        </div>
      </section>


      {/* 3. FOUR STRATEGIC PILLARS — ARCHITECTURE OF NATIONAL PROGRESS */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-6">
        <div className="border-b border-slate-200 pb-3">
          <span className="text-[10px] font-bold text-[#007DC5] uppercase tracking-widest block font-display">
            ● FOUR STRATEGIC PILLARS
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-[#07162C] font-display">
            Architecture of National Progress
          </h2>
          <p className="text-xs text-slate-500">
            Structured initiatives driving trade decentralization, regulatory transparency, generational venture incubation, and diaspora capital repatriation.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">

          {/* Pillar 01 */}
          <div className="executive-card rounded-3xl p-6 bg-white border-slate-200 space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-sky-100 text-[#007DC5]">
                <Building2 className="h-5 w-5" />
              </div>
              <div>
                <span className="text-[10px] font-bold text-amber-600 uppercase tracking-wider block">PILLAR 01 · DÉCENTRALISATION</span>
                <h3 className="text-lg font-extrabold text-[#07162C] font-display">Regional Chapters & One-Stop Desks</h3>
              </div>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Providing local corporate leadership with direct access to expedited customs clearances, inter-provincial transit permits, and ministerial advocacy without traveling to Kinshasa.
            </p>
            <div className="flex flex-wrap gap-2 pt-1">
              <span className="rounded-lg bg-sky-50 text-[#007DC5] font-bold text-[10px] px-2.5 py-1">Expedited GUCE Clearance</span>
              <span className="rounded-lg bg-slate-100 text-slate-700 font-bold text-[10px] px-2.5 py-1">Arbitration Tribunal</span>
            </div>
          </div>

          {/* Pillar 02 — RESOURCE CENTER & OHADA WITH PDF DOWNLOADS */}
          <div className="executive-card rounded-3xl p-6 bg-white border-slate-200 space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-100 text-amber-700">
                <BookOpen className="h-5 w-5" />
              </div>
              <div>
                <span className="text-[10px] font-bold text-amber-600 uppercase tracking-wider block">PILLAR 02 · RÈGLEMENTS & SAVOIR</span>
                <h3 className="text-lg font-extrabold text-[#07162C] font-display">Official Resource Center & OHADA</h3>
              </div>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Download ratified institutional dossiers, OHADA legal compliance kits, the revised DRC Mining Code Digest, and AfCFTA preferential tariff tables.
            </p>

            {/* Downloadable PDF Cards */}
            <div className="space-y-2 pt-1">
              <a
                href="#"
                onClick={(e) => { e.preventDefault(); alert("Downloading Code_Minier_RDC_Revision_2024.pdf"); }}
                className="flex items-center justify-between p-3 rounded-xl bg-sky-50 hover:bg-sky-100 border border-sky-200 transition-colors"
              >
                <div className="flex items-center gap-2.5">
                  <FileText className="h-4 w-4 text-[#007DC5]" />
                  <div>
                    <p className="text-xs font-bold text-[#07162C]">Code_Minier_RDC_Revision_2024.pdf</p>
                    <p className="text-[10px] text-slate-500">Ministerial Digest · 4.8 MB</p>
                  </div>
                </div>
                <Download className="h-4 w-4 text-[#007DC5]" />
              </a>

              <a
                href="#"
                onClick={(e) => { e.preventDefault(); alert("Downloading OHADA_Corporate_Formation_Guide.pdf"); }}
                className="flex items-center justify-between p-3 rounded-xl bg-sky-50 hover:bg-sky-100 border border-sky-200 transition-colors"
              >
                <div className="flex items-center gap-2.5">
                  <FileSpreadsheet className="h-4 w-4 text-[#007DC5]" />
                  <div>
                    <p className="text-xs font-bold text-[#07162C]">OHADA_Corporate_Formation_Guide.pdf</p>
                    <p className="text-[10px] text-slate-500">Bilingual Template Pack · 2.1 MB</p>
                  </div>
                </div>
                <Download className="h-4 w-4 text-[#007DC5]" />
              </a>
            </div>
          </div>

          {/* Pillar 03 */}
          <div className="executive-card rounded-3xl p-6 bg-white border-slate-200 space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                <GraduationCap className="h-5 w-5" />
              </div>
              <div>
                <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider block">PILLAR 03 · NOUVELLE GÉNÉRATION</span>
                <h3 className="text-lg font-extrabold text-[#07162C] font-display">Youth Entrepreneurship & Pitch Fund</h3>
              </div>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              A $2.5M non-dilutive grant pipeline fueling Congolese tech founders, value-add agro-processors, and clean energy startups under age 35.
            </p>
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-[#07162C]">Next Demo Summit: Kinshasa 2026</p>
                <p className="text-[10px] text-slate-500">Application window opens Oct 15</p>
              </div>
              <button
                onClick={() => alert("Youth Pitch Fund portal opens Oct 15.")}
                className="rounded-lg bg-amber-500 hover:bg-amber-600 px-3 py-1.5 text-xs font-bold text-slate-950"
              >
                Apply Soon
              </button>
            </div>
          </div>

          {/* Pillar 04 */}
          <div className="executive-card rounded-3xl p-6 bg-white border-slate-200 space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-purple-100 text-purple-700">
                <Globe2 className="h-5 w-5" />
              </div>
              <div>
                <span className="text-[10px] font-bold text-purple-600 uppercase tracking-wider block">PILLAR 04 · DIASPORA SOUVERAINE</span>
                <h3 className="text-lg font-extrabold text-[#07162C] font-display">Global Diaspora Investment Desk</h3>
              </div>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Dedicated sovereign liaison for Congolese living in South Africa, Belgium, France, the USA, and Canada. Enjoy expedited land rights, 5-year capital equipment duty rebates, and direct consular channel access.
            </p>
            <div className="flex items-center gap-2 text-xs font-bold text-[#007DC5]">
              <MapPin className="h-4 w-4" />
              <span>Pretoria · Brussels · Paris · Washington Hubs</span>
            </div>
          </div>

        </div>
      </section>


      {/* 4. EXECUTIVE MATCHMAKING — 1:1 CADRE MENTORSHIP NETWORK */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 border-b border-slate-200 pb-3">
          <div>
            <span className="text-[10px] font-bold text-[#007DC5] uppercase tracking-widest block font-display">
              ● EXECUTIVE MATCHMAKING · 1:1 CADRE
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#07162C] font-display">
              Executive Mentorship Network
            </h2>
          </div>
          <p className="text-xs text-slate-500 max-w-md">
            Engage proven titans of Congolese industry for bilateral venture guidance, governance structuring, and global market penetration.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {mentors.map((m) => {
            const role = lang === 'fr' ? m.roleFr : m.roleEn;
            const bio = lang === 'fr' ? m.bioFr : m.bioEn;
            const status = lang === 'fr' ? m.statusFr : m.statusEn;

            return (
              <div key={m.id} className="executive-card rounded-3xl p-6 bg-white border-slate-200 space-y-4">
                <div className="flex items-center gap-4">
                  <img
                    src={m.image}
                    alt={m.name}
                    className="h-14 w-14 rounded-2xl object-cover border border-slate-200 shadow-sm"
                  />
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h3 className="text-base font-extrabold text-[#07162C] font-display">{m.name}</h3>
                      <CheckCircle2 className="h-4 w-4 text-[#007DC5]" />
                    </div>
                    <p className="text-xs font-bold text-amber-600">{role}</p>
                    <p className="text-[10px] text-slate-400">{m.former}</p>
                  </div>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed font-normal">
                  {bio}
                </p>

                <div className="pt-2 flex items-center justify-between border-t border-slate-100">
                  <span className="text-[11px] font-bold text-[#007DC5] flex items-center gap-1">
                    <span className="pulse-dot h-2 w-2 rounded-full bg-[#007DC5]" />
                    {status}
                  </span>

                  <button
                    onClick={() => {
                      setMentorshipRequested(m.id);
                      alert(`Mentorship request submitted for ${m.name}. Our secretariat will contact you.`);
                    }}
                    className="rounded-xl bg-sky-50 hover:bg-sky-100 text-[#007DC5] border border-sky-200 px-4 py-2 text-xs font-bold transition-all"
                  >
                    Request Mentorship
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>


      {/* 5. DARK SOVEREIGN CTA CARD */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="sovereign-card rounded-3xl p-8 sm:p-12 space-y-6 relative overflow-hidden">
          <div className="flag-stripe h-[3px]" aria-hidden="true" />

          <div className="inline-flex items-center gap-2 rounded-full border border-amber-400/40 bg-amber-400/10 px-4 py-1.5 text-[11px] font-bold text-amber-400 uppercase tracking-wider">
            <ShieldCheck className="h-3.5 w-3.5" />
            <span>OFFICIAL CHAMBER CREDENTIAL</span>
          </div>

          <div className="space-y-2 max-w-2xl">
            <h2 className="text-2xl sm:text-4xl font-extrabold text-white font-display leading-tight">
              Establish Your Enterprise in the National Chapter Network
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 font-light leading-relaxed">
              Gain full accreditation, participate in provincial governance votes, unlock cross-border trade corridors, and partner with the international diaspora.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <Link
              href="/register"
              className="font-display rounded-xl bg-gradient-to-r from-[#F7D618] via-[#FFD750] to-[#F59E0B] px-7 py-3.5 text-xs sm:text-sm font-bold text-slate-950 shadow-lg hover:brightness-105 active:scale-95 transition-all"
            >
              Register Provincial Business
            </Link>

            <Link
              href="/about"
              className="rounded-xl border border-slate-700 bg-white/10 hover:bg-white/20 px-6 py-3.5 text-xs sm:text-sm font-semibold text-white transition-all"
            >
              Contact National Secretariat
            </Link>
          </div>
        </div>
      </section>

    </div>
  );
}
