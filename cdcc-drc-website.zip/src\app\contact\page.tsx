'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useLanguage } from '@/context/LanguageContext';
import {
  MapPin,
  Mail,
  Phone,
  Clock,
  Send,
  CheckCircle2,
  Building2,
  Globe2,
  ShieldCheck,
  User,
  MessageSquare,
  Sparkles,
  ExternalLink,
  Copy,
} from 'lucide-react';

export default function ContactPage() {
  const { lang, t } = useLanguage();
  
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    company: '',
    inquiryType: 'General Inquiry',
    province: 'Kinshasa',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [copiedAddress, setCopiedAddress] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName: formData.fullName,
          email: formData.email,
          phone: formData.phone,
          company: formData.company,
          sector: formData.inquiryType,
          province: formData.province,
          country: 'Democratic Republic of the Congo',
          type: 'general',
          message: `Inquiry Type: ${formData.inquiryType}. Message: ${formData.message}`,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setSubmitted(true);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedAddress(label);
    setTimeout(() => setCopiedAddress(null), 2500);
  };

  const offices = [
    {
      id: 'kinshasa',
      cityEn: 'Kinshasa Headquarters',
      cityFr: 'Siège National de Kinshasa',
      countryEn: 'Democratic Republic of the Congo',
      countryFr: 'République Démocratique du Congo',
      addressEn: 'Immeuble BCDC, 4th Floor, Boulevard du 30 Juin, Gombe, Kinshasa, DRC',
      addressFr: 'Immeuble BCDC, 4ème Étage, Boulevard du 30 Juin, Gombe, Kinshasa, RDC',
      email: 'info@cdcc.africa',
      phone: '+243 810 000 000',
      hoursEn: 'Mon – Fri: 08:00 – 17:00 (WAT)',
      hoursFr: 'Lun – Ven: 08:00 – 17:00 (WAT)',
      badgeEn: 'Main National Secretariat',
      badgeFr: 'Secrétariat National Principal',
      isPrimary: true,
    },
    {
      id: 'pretoria',
      cityEn: 'Pretoria Liaison Office',
      cityFr: 'Bureau de Liaison de Pretoria',
      countryEn: 'South Africa',
      countryFr: 'Afrique du Sud',
      addressEn: '949 Pierneef Street, Villiera, Pretoria, 0186 · South Africa',
      addressFr: '949 Pierneef Street, Villiera, Pretoria, 0186 · Afrique du Sud',
      email: 'pretoria@cdcc.africa',
      phone: '+27 78 042 6523',
      hoursEn: 'Mon – Fri: 08:30 – 16:30 (SAST)',
      hoursFr: 'Lun – Ven: 08:30 – 16:30 (SAST)',
      badgeEn: 'SADC & Diaspora Desk',
      badgeFr: 'Guichet SADC & Diaspora',
      isPrimary: false,
    },
    {
      id: 'lubumbashi',
      cityEn: 'Haut-Katanga Chapter Desk',
      cityFr: 'Chapitre du Haut-Katanga',
      countryEn: 'Haut-Katanga, DRC',
      countryFr: 'Haut-Katanga, RDC',
      addressEn: 'Avenue Kasavubu, Karavia Building, Lubumbashi',
      addressFr: 'Avenue Kasavubu, Immeuble Karavia, Lubumbashi',
      email: 'katanga@cdcc.africa',
      phone: '+243 990 000 000',
      hoursEn: 'Mon – Fri: 08:00 – 17:00 (CAT)',
      hoursFr: 'Lun – Ven: 08:00 – 17:00 (CAT)',
      badgeEn: 'Mining & Logistics Corridor',
      badgeFr: 'Corridor Minier & Logistique',
      isPrimary: false,
    },
    {
      id: 'kolwezi',
      cityEn: 'Kolwezi Energy Desk',
      cityFr: 'Guichet Énergie de Kolwezi',
      countryEn: 'Lualaba, DRC',
      countryFr: 'Lualaba, RDC',
      addressEn: 'Boulevard du 30 Juin, Kolwezi Industrial Zone',
      addressFr: 'Boulevard du 30 Juin, Zone Industrielle de Kolwezi',
      email: 'lualaba@cdcc.africa',
      phone: '+243 820 000 000',
      hoursEn: 'Mon – Fri: 08:00 – 16:30 (CAT)',
      hoursFr: 'Lun – Ven: 08:00 – 16:30 (CAT)',
      badgeEn: 'Solar & Lithium Hub',
      badgeFr: 'Hub Solaire & Lithium',
      isPrimary: false,
    },
    {
      id: 'matadi',
      cityEn: 'Matadi Seaport Desk',
      cityFr: 'Antenne Portuaire de Matadi',
      countryEn: 'Kongo Central, DRC',
      countryFr: 'Kongo Central, RDC',
      addressEn: 'Port Gateway Avenue, Matadi Maritime Complex',
      addressFr: 'Avenue de la Porte Maritime, Complexe Portuaire de Matadi',
      email: 'matadi@cdcc.africa',
      phone: '+243 830 000 000',
      hoursEn: 'Mon – Fri: 08:00 – 17:00 (WAT)',
      hoursFr: 'Lun – Ven: 08:00 – 17:00 (WAT)',
      badgeEn: 'Maritime & Export Desk',
      badgeFr: 'Guichet Maritime & Export',
      isPrimary: false,
    },
    {
      id: 'goma',
      cityEn: 'Goma Cross-Border Desk',
      cityFr: 'Guichet Transfrontalier de Goma',
      countryEn: 'Nord-Kivu, DRC',
      countryFr: 'Nord-Kivu, RDC',
      addressEn: 'Commercial District, Avenue du Lac, Goma',
      addressFr: 'Quartier Commercial, Avenue du Lac, Goma',
      email: 'goma@cdcc.africa',
      phone: '+243 840 000 000',
      hoursEn: 'Mon – Fri: 08:00 – 17:00 (CAT)',
      hoursFr: 'Lun – Ven: 08:00 – 17:00 (CAT)',
      badgeEn: 'Eastern Trade Corridor',
      badgeFr: 'Corridor Commercial Est',
      isPrimary: false,
    },
  ];

  return (
    <div className="space-y-16 pb-12 pt-24 sm:pt-28 bg-[#F2F5FA]">

      {/* 1. HERO HEADER WITH BILINGUAL TRANSLATION */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-4 text-center sm:text-left">
        <div className="inline-flex items-center gap-2 rounded-full border border-sky-300 bg-sky-50 px-3.5 py-1.5 text-[11px] font-bold text-[#007DC5] uppercase tracking-wider">
          <Globe2 className="h-3.5 w-3.5 text-[#007DC5]" />
          <span>
            {lang === 'fr'
              ? 'DESKS DIPLOMATIQUES & CONSULAIRES OFFICIELS · RDC'
              : 'OFFICIAL DIPLOMATIC & CONSULAR DESKS · DRC'}
          </span>
        </div>

        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#07162C] font-display max-w-4xl leading-tight">
          {lang === 'fr' ? 'Contactez la Chambre de Commerce' : 'Contact the Chamber of Commerce'}
        </h1>

        <p className="text-sm sm:text-base text-slate-600 max-w-3xl leading-relaxed">
          {lang === 'fr'
            ? "Contactez notre secrétariat national principal à Kinshasa, notre bureau de liaison diplomatique sud-africain à Pretoria, nos guichets régionaux dans les 26 provinces, ou nos représentants bilatéraux internationaux."
            : "Reach out to our main national secretariat in Kinshasa, southern African diplomatic liaison in Pretoria, regional chapter desks across all 26 provinces, or international bilateral representatives."}
        </p>
      </section>


      {/* 2. OFFICES GRID WITH FULL BILINGUAL TRANSLATION */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-6">
        <div className="border-b border-slate-200 pb-3 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold text-[#007DC5] uppercase tracking-widest block font-display">
              ● {lang === 'fr' ? 'REPRÉSENTATIONS CONSULAIRES' : 'CONSULAR REPRESENTATIONS'}
            </span>
            <h2 className="text-2xl font-extrabold text-[#07162C] font-display">
              {lang === 'fr' ? 'Secrétariats & Guichets Régionaux' : 'Secretariats & Regional Desks'}
            </h2>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {offices.map((off) => {
            const badge = lang === 'fr' ? off.badgeFr : off.badgeEn;
            const city = lang === 'fr' ? off.cityFr : off.cityEn;
            const country = lang === 'fr' ? off.countryFr : off.countryEn;
            const address = lang === 'fr' ? off.addressFr : off.addressEn;
            const hours = lang === 'fr' ? off.hoursFr : off.hoursEn;

            return (
              <div
                key={off.id}
                className={`executive-card rounded-3xl p-6 bg-white space-y-5 border-slate-200 transition-all ${
                  off.isPrimary ? 'ring-2 ring-[#007DC5] shadow-lg' : 'shadow-sm'
                }`}
              >
                <div className="flex items-start justify-between gap-3 border-b border-slate-100 pb-4">
                  <div>
                    <span className="rounded-md bg-sky-100 text-[#007DC5] text-[10px] font-bold px-2.5 py-1 uppercase tracking-wider">
                      {badge}
                    </span>
                    <h3 className="text-lg font-extrabold text-[#07162C] font-display mt-2">
                      {city}
                    </h3>
                    <p className="text-xs font-semibold text-slate-500">{country}</p>
                  </div>

                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#07162C] text-amber-400 shrink-0">
                    <Building2 className="h-5 w-5 icon-animate" />
                  </div>
                </div>

                <div className="space-y-3 text-xs text-slate-600">
                  <div className="flex items-start gap-2.5">
                    <MapPin className="h-4 w-4 text-[#007DC5] shrink-0 mt-0.5" />
                    <span className="flex-1">{address}</span>
                    <button
                      onClick={() => copyToClipboard(address, off.id)}
                      className="text-slate-400 hover:text-[#007DC5] p-1"
                      title={lang === 'fr' ? "Copier l'adresse" : "Copy Address"}
                    >
                      <Copy className="h-3.5 w-3.5" />
                    </button>
                  </div>

                  <div className="flex items-center gap-2.5">
                    <Mail className="h-4 w-4 text-slate-400 shrink-0" />
                    <a href={`mailto:${off.email}`} className="font-semibold text-[#007DC5] hover:underline">
                      {off.email}
                    </a>
                  </div>

                  <div className="flex items-center gap-2.5">
                    <Phone className="h-4 w-4 text-slate-400 shrink-0" />
                    <a href={`tel:${off.phone}`} className="font-semibold text-slate-800 hover:underline">
                      {off.phone}
                    </a>
                  </div>

                  <div className="flex items-center gap-2.5 text-slate-500 pt-1">
                    <Clock className="h-4 w-4 text-slate-400 shrink-0" />
                    <span>{hours}</span>
                  </div>
                </div>

                {copiedAddress === off.id && (
                  <p className="text-[11px] font-bold text-emerald-600 bg-emerald-50 p-2 rounded-lg text-center animate-fadeIn">
                    {lang === 'fr' ? 'Adresse copiée dans le presse-papier !' : 'Address copied to clipboard!'}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </section>


      {/* 3. INTERACTIVE CONTACT & PROTOCOL INQUIRY FORM WITH BILINGUAL TRANSLATIONS */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <div className="executive-card rounded-3xl p-6 sm:p-10 bg-white border-slate-200 space-y-6 shadow-xl relative overflow-hidden">
          <div className="flag-stripe h-[3px]" aria-hidden="true" />

          <div>
            <span className="text-[10px] font-bold text-[#007DC5] uppercase tracking-widest block font-display">
              ● {lang === 'fr' ? 'COMMUNIQUÉ OFFICIEL & DEMANDES' : 'OFFICIAL COMMUNIQUE & INQUIRIES'}
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#07162C] font-display">
              {lang === 'fr' ? 'Envoyer une Demande Officielle' : 'Send an Official Inquiry'}
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              {lang === 'fr'
                ? "Envoi direct au Secrétariat National CDCC. Traitement prioritaire sous 24 heures ouvrées."
                : "Direct dispatch to the CDCC National Secretariat. Priority handling within 24 business hours."}
            </p>
          </div>

          {submitted ? (
            <div className="p-8 text-center space-y-4 bg-emerald-50 rounded-2xl border border-emerald-200">
              <CheckCircle2 className="h-12 w-12 text-emerald-600 mx-auto" />
              <h3 className="text-xl font-bold text-[#07162C]">
                {lang === 'fr' ? 'Demande Transmise avec Succès' : 'Inquiry Dispatched Successfully'}
              </h3>
              <p className="text-xs text-slate-600 max-w-md mx-auto">
                {lang === 'fr'
                  ? "Merci d'avoir contacté la Chambre de Commerce de la RDC. Un agent consulaire répondra à votre email professionnel."
                  : "Thank you for contacting the Chamber of Commerce of the DRC. A consular officer will respond to your corporate email."}
              </p>
              <button
                onClick={() => setSubmitted(false)}
                className="rounded-xl bg-[#07162C] text-white text-xs font-bold px-5 py-2.5"
              >
                {lang === 'fr' ? 'Envoyer une Autre Demande' : 'Send Another Inquiry'}
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              
              {/* Row 1 */}
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {lang === 'fr' ? 'Nom Légal Complet *' : 'Full Legal Name *'}
                  </label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <input
                      type="text"
                      required
                      placeholder={lang === 'fr' ? 'ex: Dieudonné Mwamba' : 'Ex: Dieudonné Mwamba'}
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 pl-10 pr-4 py-2.5 text-xs text-slate-900 focus:border-[#007DC5] focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {lang === 'fr' ? 'Email Professionnel *' : 'Corporate Email *'}
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <input
                      type="email"
                      required
                      placeholder="direction@enterprise.cd"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 pl-10 pr-4 py-2.5 text-xs text-slate-900 focus:border-[#007DC5] focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Row 2 */}
              <div className="grid sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {lang === 'fr' ? 'Téléphone / WhatsApp *' : 'Telephone / WhatsApp *'}
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <input
                      type="tel"
                      required
                      placeholder="+243 81 000 0000"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 pl-10 pr-4 py-2.5 text-xs text-slate-900 focus:border-[#007DC5] focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {lang === 'fr' ? 'Entreprise / Organisation' : 'Company / Organization'}
                  </label>
                  <input
                    type="text"
                    placeholder={lang === 'fr' ? 'Raison Sociale' : 'Company Entity Name'}
                    value={formData.company}
                    onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-xs text-slate-900 focus:border-[#007DC5] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {lang === 'fr' ? 'Type de Demande *' : 'Inquiry Type *'}
                  </label>
                  <select
                    value={formData.inquiryType}
                    onChange={(e) => setFormData({ ...formData, inquiryType: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-xs text-slate-900 focus:border-[#007DC5] focus:outline-none"
                  >
                    <option value="General Inquiry">
                      {lang === 'fr' ? 'Demande Générale' : 'General Inquiry'}
                    </option>
                    <option value="Membership & Accreditation">
                      {lang === 'fr' ? 'Adhésion & Accréditation' : 'Membership & Accreditation'}
                    </option>
                    <option value="Trade Facilitation & GUCE">
                      {lang === 'fr' ? 'Facilitation Commerciale & GUCE' : 'Trade Facilitation & GUCE'}
                    </option>
                    <option value="Diaspora Concierge">
                      {lang === 'fr' ? 'Conciergerie Diaspora' : 'Diaspora Concierge'}
                    </option>
                    <option value="Summit Delegation RSVP">
                      {lang === 'fr' ? 'RSVP Délégation Sommet' : 'Summit Delegation RSVP'}
                    </option>
                    <option value="Media & Press Protocol">
                      {lang === 'fr' ? 'Presse & Protocole Média' : 'Media & Press Protocol'}
                    </option>
                  </select>
                </div>
              </div>

              {/* Message */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'fr' ? 'Message Officiel / Détails de la Demande *' : 'Official Message / Inquiry Details *'}
                </label>
                <textarea
                  rows={4}
                  required
                  placeholder={
                    lang === 'fr'
                      ? 'Détaillez votre demande, l\'envergure du projet ou les conseils consulaires recherchés...'
                      : 'Detail your request, project scale, or specific consular guidance needed...'
                  }
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-xs text-slate-900 focus:border-[#007DC5] focus:outline-none"
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={loading}
                className="w-full rounded-xl bg-[#07162C] hover:bg-[#0C2344] py-3.5 text-xs font-bold text-white transition-all shadow-md flex items-center justify-center gap-2"
              >
                <Send className="h-4 w-4 text-amber-400 icon-animate" />
                <span>
                  {loading
                    ? (lang === 'fr' ? 'Envoi en cours...' : 'Dispatching Message...')
                    : (lang === 'fr' ? 'Envoyer le Message →' : 'Dispatch Message →')}
                </span>
              </button>
            </form>
          )}

        </div>
      </section>


      {/* 4. EMERGENCY CONSULAR & TRADE HOTLINE BANNER WITH BILINGUAL TRANSLATIONS */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="sovereign-card rounded-3xl p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-amber-400" />
              <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                {lang === 'fr' ? 'LIGNE DIRECTE DIPLOMATIQUE & CARGO 24/7' : '24/7 DIPLOMATIC & CARGO HOTLINE'}
              </span>
            </div>
            <h3 className="text-lg font-bold text-white font-display">
              {lang === 'fr'
                ? 'Résolution Rapide des Litiges & Protection Douanière Transfrontalière'
                : 'Fast-track Dispute Resolution & Cross-Border Customs Protection'}
            </h3>
            <p className="text-xs text-slate-300 max-w-xl">
              {lang === 'fr'
                ? "Les membres accrédités CDCC bénéficient d'une assistance juridique d'urgence et d'un plaidoyer douanier sur les points d'entrée de Matadi, Lubumbashi et Kinshasa."
                : "Accredited CDCC members receive emergency legal representation and customs clearance advocacy across Matadi, Lubumbashi, and Kinshasa entry points."}
            </p>
          </div>

          <a
            href="tel:+243810000000"
            className="font-display rounded-xl bg-gradient-to-r from-[#F7D618] via-[#FFD750] to-[#F59E0B] px-6 py-3 text-xs font-bold text-slate-950 shadow-md hover:brightness-105 transition-all shrink-0 flex items-center gap-2"
          >
            <Phone className="h-4 w-4 icon-animate" />
            <span>{lang === 'fr' ? 'Appeler la Ligne Consulaire' : 'Call Consular Hotline'}</span>
          </a>
        </div>
      </section>

    </div>
  );
}
